package com.purnadlc.combat;

import com.purnadlc.combat.aura.*;
import com.purnadlc.combat.aura.movefix.MoveFixController;
import com.purnadlc.combat.aura.state.RotationStateManager;
import net.minecraft.util.math.Vec2f;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AttackAuraTest {

    @Test
    void testYawNormalizationAndShortestPath() {
        assertEquals(0.0f, RotationMath.normalizeYaw(360.0f), 1e-4f);
        assertEquals(-170.0f, RotationMath.normalizeYaw(190.0f), 1e-4f);
        assertEquals(170.0f, RotationMath.normalizeYaw(-190.0f), 1e-4f);
        assertEquals(0.0f, RotationMath.normalizeYaw(Float.NaN), 1e-4f);
        assertEquals(20.0f, RotationMath.yawDifference(170.0f, -170.0f), 1e-4f);
        assertEquals(-20.0f, RotationMath.yawDifference(-170.0f, 170.0f), 1e-4f);
    }

    @Test
    void testPitchClamping() {
        assertEquals(90.0f, RotationMath.clampPitch(145.0f), 1e-4f);
        assertEquals(-90.0f, RotationMath.clampPitch(-120.0f), 1e-4f);
        assertEquals(85.0f, RotationMath.clampPitch(89.5f, 85.0f), 1e-4f);
        assertEquals(0.0f, RotationMath.clampPitch(Float.POSITIVE_INFINITY), 1e-4f);
    }

    @Test
    void testRotationInterpolationAndDistinctProfiles() {
        AttackAuraSettings settings = new AttackAuraSettings(null);
        RotationStateManager stateManager = new RotationStateManager();
        RotationController controller = new RotationController(stateManager);

        settings.rotationMode.setValue(AttackAuraSettings.RotationMode.SMOOTH);
        var smooth = controller.computeStepForAngles(0.0f, 0.0f, 60.0f, 25.0f, 2.5, false, 0.5, settings);

        settings.rotationMode.setValue(AttackAuraSettings.RotationMode.FUNTIME);
        var funtime = controller.computeStepForAngles(0.0f, 0.0f, 60.0f, 25.0f, 2.5, false, 0.5, settings);

        settings.rotationMode.setValue(AttackAuraSettings.RotationMode.SPOOKYTIME);
        var spookyClose = controller.computeStepForAngles(0.0f, 0.0f, 60.0f, 25.0f, 1.4, false, 0.5, settings);
        controller.reset();
        var spookyFar = controller.computeStepForAngles(0.0f, 0.0f, 60.0f, 25.0f, 5.2, false, 0.5, settings);

        settings.rotationMode.setValue(AttackAuraSettings.RotationMode.MATRIX);
        var matrix = controller.computeStepForAngles(0.0f, 0.0f, 60.0f, 25.0f, 2.5, false, 0.5, settings);

        assertTrue(smooth.yaw() > 0.0f && smooth.yaw() <= 60.0f);
        assertTrue(funtime.yaw() > 0.0f && funtime.yaw() <= 60.0f);
        assertTrue(spookyClose.yaw() > spookyFar.yaw());
        assertTrue(matrix.yaw() > 0.0f && matrix.yaw() <= 60.0f);
        assertNotEquals(smooth.yaw(), funtime.yaw(), 1e-3f);
        assertNotEquals(funtime.yaw(), spookyClose.yaw(), 1e-3f);
        assertNotEquals(smooth.yaw(), matrix.yaw(), 1e-3f);
    }

    @Test
    void testFovCalculations() {
        FOVCalculator calc = new FOVCalculator();
        assertTrue(calc.evaluateAngles(0.0f, 0.0f, 20.0f, 10.0f, 2.8, 3.2, 90.0, 90.0, 60.0, true).isValid(true, true));
        assertFalse(calc.evaluateAngles(0.0f, 0.0f, 70.0f, 0.0f, 2.5, 3.2, 180.0, 90.0, 90.0, true).isValid(true, true));
        assertTrue(calc.evaluateAngles(0.0f, 0.0f, 179.0f, 0.0f, 2.5, 3.2, 360.0, 360.0, 180.0, true).isValid(true, true));
    }

    @Test
    void testTargetSwitchingAndPriority() {
        TargetSelector selector = new TargetSelector();
        List<TargetSelector.TargetCandidate<String>> list = new ArrayList<>();
        list.add(new TargetSelector.TargetCandidate<>("FarLowHP", 1, 4.0, 4.0f, 35.0f, 100));
        list.add(new TargetSelector.TargetCandidate<>("CloseFullHP", 2, 1.8, 20.0f, 15.0f, 60));
        list.add(new TargetSelector.TargetCandidate<>("MidSmallRot", 3, 2.7, 14.0f, 3.0f, 20));

        assertEquals(2, selector.select(new ArrayList<>(list), AttackAuraSettings.TargetMode.SWITCH,
            AttackAuraSettings.TargetPriority.CLOSEST_DISTANCE, false, 0L).id());
        assertEquals(1, selector.select(new ArrayList<>(list), AttackAuraSettings.TargetMode.SWITCH,
            AttackAuraSettings.TargetPriority.LOWEST_HEALTH, false, 0L).id());
        assertEquals(3, selector.select(new ArrayList<>(list), AttackAuraSettings.TargetMode.SWITCH,
            AttackAuraSettings.TargetPriority.SMALLEST_ROTATION_DIFFERENCE, false, 0L).id());
        assertNull(selector.select(new ArrayList<>(), AttackAuraSettings.TargetMode.SINGLE,
            AttackAuraSettings.TargetPriority.CLOSEST_DISTANCE, false, 0L));
    }

    @Test
    void testCriticalConditionDetection() {
        AttackAuraSettings settings = new AttackAuraSettings(null);
        settings.onlyCrit.setValue(true);
        settings.criticalDelay.setValue(0.0);
        CriticalManager crit = new CriticalManager();

        var validFall = new CriticalManager.PlayerMovementSnapshot(
            false, 0.25, -0.15, false, false, false, false, false, false, false, 1.0f
        );
        assertEquals(CriticalManager.CriticalVerdict.READY, crit.evaluateSnapshot(validFall, settings));

        var grounded = new CriticalManager.PlayerMovementSnapshot(
            true, 0.0, 0.0, false, false, false, false, false, false, false, 1.0f
        );
        assertEquals(CriticalManager.CriticalVerdict.WAIT_FOR_AIRBORNE_FALL, crit.evaluateSnapshot(grounded, settings));

        var climbing = new CriticalManager.PlayerMovementSnapshot(
            false, 0.3, -0.1, true, false, false, false, false, false, false, 1.0f
        );
        assertEquals(CriticalManager.CriticalVerdict.BLOCKED_BY_ENVIRONMENT, crit.evaluateSnapshot(climbing, settings));
    }

    @Test
    void testShieldStateTransitions() {
        ShieldBreaker sb = new ShieldBreaker();
        assertEquals(ShieldBreaker.ShieldState.IDLE, sb.getState());
        assertEquals(ShieldBreaker.ShieldState.AXE_EQUIPPED,
            sb.simulateTransition(true, true, true, 0, 2, true, false));
        assertEquals(0, sb.getSavedSlot());
        assertEquals(ShieldBreaker.ShieldState.IDLE,
            sb.simulateTransition(true, true, true, 0, 2, true, true));
        assertEquals(-1, sb.getSavedSlot());
    }

    @Test
    void testAttackCooldownAndDuplicatePrevention() {
        AttackController controller = new AttackController(
            new CriticalManager(), new ShieldBreaker(), new TargetManager(new FOVCalculator(), new TargetSelector())
        );
        assertTrue(controller.canProceedWithCycle(10L, 0.95f, 0.92f, 50L, 60L));
        assertFalse(controller.canProceedWithCycle(10L, 0.70f, 0.92f, 50L, 60L));
        controller.markSimulatedAttack(10L);
        assertFalse(controller.canProceedWithCycle(10L, 1.0f, 0.92f, 0L, 100L));
        assertTrue(controller.canProceedWithCycle(11L, 1.0f, 0.92f, 0L, 100L));
    }

    @Test
    void testMoveFixDirectionalCorrection() {
        RotationStateManager rsm = new RotationStateManager();
        MoveFixController moveFix = new MoveFixController(rsm);

        // Moving visually forward (y=1, x=0) at cameraYaw=0 while combatYaw=+90 must remap to sideways=+1, forward=0
        Vec2f remapped = moveFix.correctMovementInput(new Vec2f(0.0f, 1.0f), 0.0f, 90.0f, AttackAuraSettings.MoveFixMode.SILENT);
        assertEquals(1.0f, remapped.x, 1e-4f);
        assertEquals(0.0f, remapped.y, 1e-4f);

        Vec2f unchanged = moveFix.correctMovementInput(new Vec2f(0.0f, 1.0f), 0.0f, 90.0f, AttackAuraSettings.MoveFixMode.OFF);
        assertEquals(0.0f, unchanged.x, 1e-4f);
        assertEquals(1.0f, unchanged.y, 1e-4f);
    }

    @Test
    void testRotationStateSeparationAndReset() {
        RotationStateManager rsm = new RotationStateManager();
        rsm.beginTickManual(15.0f, 5.0f);
        rsm.commitCombatRotation(120.0f, -12.0f, false, null);
        assertEquals(15.0f, rsm.getCameraRotation().getYaw(), 1e-4f);
        assertEquals(120.0f, rsm.getCombatRotation().getYaw(), 1e-4f);
        assertTrue(rsm.isCombatRotationActive());

        rsm.reset();
        assertFalse(rsm.isCombatRotationActive());
        assertFalse(rsm.getServerState().isSynchronized());
    }
}
