package com.purnadlc.movement;

import com.purnadlc.module.impl.movement.ElytraHelperModule;
import net.minecraft.util.math.Vec3d;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ElytraHelperTest {

    @Test
    void testPredictiveHitTimingClosingTarget() {
        // Player at origin moving +1.4 blocks/tick along +Z toward target at Z=4.8 (stationary)
        // After 2 ticks player is at Z=2.8 -> distance = 2.0 <= 3.1 -> imminent!
        assertTrue(ElytraHelperModule.isHitImminent(
            new Vec3d(0.0, 64.0, 0.0),
            new Vec3d(0.0, 0.0, 1.4),
            new Vec3d(0.0, 64.0, 4.8),
            Vec3d.ZERO,
            3.1,
            2
        ));
    }

    @Test
    void testPredictiveHitTimingFarAwayTarget() {
        // Target 15 blocks away while moving 1 block/tick -> not imminent within 2 ticks
        assertFalse(ElytraHelperModule.isHitImminent(
            new Vec3d(0.0, 64.0, 0.0),
            new Vec3d(0.0, 0.0, 1.0),
            new Vec3d(0.0, 64.0, 15.0),
            Vec3d.ZERO,
            3.1,
            2
        ));
    }

    @Test
    void testPredictiveHitTimingAlreadyInRange() {
        assertTrue(ElytraHelperModule.isHitImminent(
            new Vec3d(0.0, 64.0, 0.0),
            Vec3d.ZERO,
            new Vec3d(0.0, 64.0, 2.8),
            Vec3d.ZERO,
            3.1,
            1
        ));
    }
}
