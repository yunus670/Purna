package com.purnadlc.visual;

import com.purnadlc.PurnaDLC;
import com.purnadlc.module.impl.visual.AspectRatioModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Method;

public final class WorldProjection {
    private static boolean cameraMethodResolved = false;
    private static Method cameraPosMethod = null;

    private Vec3d camPos = Vec3d.ZERO;
    private double forwardX, forwardY, forwardZ;
    private double rightX, rightY, rightZ;
    private double upX, upY, upZ;
    private double tanHalfFovY = 1.0;
    private double aspect = 16.0 / 9.0;
    private int screenW = 1;
    private int screenH = 1;
    private boolean valid = false;

    public record ScreenPoint(float x, float y, float depth, boolean visible) {}

    public boolean beginFrame(MinecraftClient mc) {
        valid = false;
        if (mc == null || mc.player == null || mc.world == null || mc.getWindow() == null || mc.gameRenderer == null) {
            return false;
        }
        screenW = Math.max(1, mc.getWindow().getScaledWidth());
        screenH = Math.max(1, mc.getWindow().getScaledHeight());

        Camera camera = mc.gameRenderer.getCamera();
        float yawDeg = camera != null ? camera.getYaw() : mc.player.getYaw();
        float pitchDeg = camera != null ? camera.getPitch() : mc.player.getPitch();

        Vec3d resolvedCamPos = resolveCameraPos(camera, mc);
        this.camPos = resolvedCamPos != null ? resolvedCamPos : mc.player.getEyePos();

        double yawRad = Math.toRadians(yawDeg);
        double pitchRad = Math.toRadians(pitchDeg);
        double cosPitch = Math.cos(pitchRad);

        forwardX = -Math.sin(yawRad) * cosPitch;
        forwardY = -Math.sin(pitchRad);
        forwardZ = Math.cos(yawRad) * cosPitch;

        double rx = -forwardZ, ry = 0.0, rz = forwardX;
        double rLen = Math.hypot(rx, rz);
        if (rLen < 1.0e-6) {
            rx = Math.cos(yawRad);
            rz = Math.sin(yawRad);
            rLen = 1.0;
        }
        rightX = rx / rLen;
        rightY = ry;
        rightZ = rz / rLen;

        upX = rightY * forwardZ - rightZ * forwardY;
        upY = rightZ * forwardX - rightX * forwardZ;
        upZ = rightX * forwardY - rightY * forwardX;

        double fovDeg = mc.options != null ? mc.options.getFov().getValue() : 70.0;
        tanHalfFovY = Math.tan(Math.toRadians(Math.max(20.0, Math.min(150.0, fovDeg)) * 0.5));

        double baseAspect = (double) screenW / screenH;
        PurnaDLC client = PurnaDLC.getInstance();
        if (client != null) {
            AspectRatioModule ar = client.getModuleManager().getModule(AspectRatioModule.class);
            if (ar != null && ar.isEnabled()) {
                baseAspect = Math.max(0.5, ar.ratio.getValue());
            }
        }
        aspect = baseAspect;
        valid = true;
        return true;
    }

    public ScreenPoint project(double wx, double wy, double wz) {
        if (!valid) return new ScreenPoint(-9999f, -9999f, -1f, false);
        double dx = wx - camPos.x;
        double dy = wy - camPos.y;
        double dz = wz - camPos.z;

        double z = dx * forwardX + dy * forwardY + dz * forwardZ;
        if (z <= 0.05) return new ScreenPoint(-9999f, -9999f, (float) z, false);

        double x = dx * rightX + dy * rightY + dz * rightZ;
        double y = dx * upX + dy * upY + dz * upZ;

        double ndcX = x / (z * tanHalfFovY * aspect);
        double ndcY = y / (z * tanHalfFovY);

        float sx = (float) ((ndcX + 1.0) * 0.5 * screenW);
        float sy = (float) ((1.0 - ndcY) * 0.5 * screenH);
        boolean onScreen = sx >= -120 && sx <= screenW + 120 && sy >= -120 && sy <= screenH + 120;
        return new ScreenPoint(sx, sy, (float) z, onScreen);
    }

    public ScreenPoint project(Vec3d pos) { return project(pos.x, pos.y, pos.z); }
    public Vec3d getCameraPos() { return camPos; }
    public int getScreenW() { return screenW; }
    public int getScreenH() { return screenH; }

    private static Vec3d resolveCameraPos(Camera camera, MinecraftClient mc) {
        if (camera != null) {
            if (!cameraMethodResolved) {
                cameraMethodResolved = true;
                for (String name : new String[]{"getCameraPos", "getPos"}) {
                    try {
                        Method m = Camera.class.getMethod(name);
                        if (Vec3d.class.isAssignableFrom(m.getReturnType())) {
                            cameraPosMethod = m;
                            break;
                        }
                    } catch (Throwable ignored) {}
                }
            }
            if (cameraPosMethod != null) {
                try {
                    Object res = cameraPosMethod.invoke(camera);
                    if (res instanceof Vec3d v) return v;
                } catch (Throwable ignored) {}
            }
        }
        if (mc.player != null && mc.options != null && mc.options.getPerspective() != Perspective.FIRST_PERSON) {
            double sign = mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT ? 4.0 : -4.0;
            return mc.player.getEyePos().add(mc.player.getRotationVector().multiply(sign));
        }
        return mc.player != null ? mc.player.getEyePos() : Vec3d.ZERO;
    }
}
