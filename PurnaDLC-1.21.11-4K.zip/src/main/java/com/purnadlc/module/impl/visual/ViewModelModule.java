package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.NumberSetting;

public class ViewModelModule extends Module {
    public final NumberSetting mainX = addSetting(new NumberSetting("Main X", "Main hand horizontal offset", 0.0, -1.5, 1.5, 0.05));
    public final NumberSetting mainY = addSetting(new NumberSetting("Main Y", "Main hand vertical offset", 0.0, -1.5, 1.5, 0.05));
    public final NumberSetting mainZ = addSetting(new NumberSetting("Main Z", "Main hand depth offset", 0.0, -1.5, 1.5, 0.05));
    public final NumberSetting scale = addSetting(new NumberSetting("Scale", "Held item scale", 1.0, 0.3, 1.8, 0.05));

    public ViewModelModule() {
        super("ViewModel", "Adjusts first-person hand position and scale", Category.VISUALS, ModuleSection.VIEW);
    }
}
