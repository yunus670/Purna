package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class ItemRendererModule extends Module {
    public final BooleanSetting flatPhysics = addSetting(new BooleanSetting("Physics", "Dropped items rest flat on ground", true));
    public final NumberSetting itemScale = addSetting(new NumberSetting("Scale", "Dropped item scale", 1.0, 0.5, 2.0, 0.1));

    public ItemRendererModule() {
        super("Item Renderer", "Enhances dropped item visuals and scale", Category.VISUALS, ModuleSection.RENDER);
    }
}
