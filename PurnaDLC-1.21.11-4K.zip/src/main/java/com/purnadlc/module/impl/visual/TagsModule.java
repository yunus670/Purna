package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class TagsModule extends Module {
    public final BooleanSetting showHealth = addSetting(new BooleanSetting("Health", "Display entity health in tag", true));
    public final BooleanSetting showArmor = addSetting(new BooleanSetting("Armor", "Display equipped armor icons", true));
    public final BooleanSetting showDistance = addSetting(new BooleanSetting("Distance", "Display distance in blocks", true));
    public final NumberSetting scale = addSetting(new NumberSetting("Scale", "Nametag size multiplier", 1.0, 0.6, 2.0, 0.1));

    public TagsModule() {
        super("Tags", "Renders clean high-contrast entity nametags", Category.VISUALS, ModuleSection.OVERLAY);
    }
}
