package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.NumberSetting;

public class ArrowsModule extends Module {
    public final NumberSetting radius = addSetting(new NumberSetting("Radius", "Distance from screen center", 56, 24, 140, 2));
    public final BooleanSetting playersOnly = addSetting(new BooleanSetting("Players Only", "Track players exclusively", true));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "Directional arrow color", 0xFFB45AE8));

    public ArrowsModule() {
        super("Arrows", "Displays off-screen directional entity indicators", Category.VISUALS, ModuleSection.OVERLAY);
    }
}
