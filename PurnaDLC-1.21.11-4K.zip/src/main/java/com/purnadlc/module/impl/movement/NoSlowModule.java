package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.MultiModeSetting;

import java.util.List;

public class NoSlowModule extends Module {
    public final MultiModeSetting sources = addSetting(new MultiModeSetting("Sources", "Slowdown sources to mitigate", List.of("Items", "Webs"), "Items", "Webs", "SoulSand", "BerryBush"));

    public NoSlowModule() {
        super("NoSlow", "Reduces movement penalties while eating or crossing obstacles", Category.MOVEMENT, ModuleSection.GROUND);
    }
}
