package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.NumberSetting;

public class ChinaHatModule extends Module {
    public final NumberSetting radius = addSetting(new NumberSetting("Radius", "Hat cone radius", 0.58, 0.3, 1.0, 0.02));
    public final NumberSetting height = addSetting(new NumberSetting("Height", "Hat cone height", 0.30, 0.1, 0.6, 0.02));
    public final ColorSetting topColor = addSetting(new ColorSetting("Top Color", "Primary cone gradient color", 0xFFB45AE8));
    public final ColorSetting rimColor = addSetting(new ColorSetting("Rim Color", "Outer rim gradient color", 0xFF8DADDE));

    public ChinaHatModule() {
        super("ChinaHat", "Renders a gradient halo cone above the player", Category.VISUALS, ModuleSection.VIEW);
    }
}
