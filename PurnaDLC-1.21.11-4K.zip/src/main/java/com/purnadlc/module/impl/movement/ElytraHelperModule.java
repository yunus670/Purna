package com.purnadlc.module.impl.movement;

import com.purnadlc.PurnaDLC;
import com.purnadlc.combat.aura.AttackAura;
import com.purnadlc.combat.aura.CombatTimer;
import com.purnadlc.combat.aura.RotationMath;
import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BindSetting;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import com.purnadlc.platform.MobilePlatform;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * ElytraHelper — Fast Chestplate/Elytra swap and dual-mode (Legit / Normal) Firework controller
 * for Minecraft 1.21.11 Fabric.
 */
public final class ElytraHelperModule extends Module {
    private static final int CHEST_ARMOR_CONTAINER_SLOT = 6;

    public enum FireworkPhase {
        IDLE,
        NORMAL_PULL_PENDING,
        NORMAL_FIRE_PENDING,
        NORMAL_RESTORE_PENDING,
        LEGIT_WAIT_FOR_HIT,
        LEGIT_EQUIPPED_FIREWORK,
        LEGIT_POST_FIRE_HOLD
    }

    // Core requested keybinds & mode settings
    public final BindSetting swapButton = addSetting(
        new BindSetting("Swap Button", "Instantly swap between Chestplate and Elytra", BindSetting.UNBOUND)
    );
    public final BindSetting fireworkButton = addSetting(
        new BindSetting("Firework Button", "Trigger firework boost in selected mode", BindSetting.UNBOUND)
    );
    public final ModeSetting fireworkMode = addSetting(
        new ModeSetting("Firework Mode", "Legit (hotbar swap + hit timing) or Normal (silent packet)", "Legit", "Legit", "Normal")
    );

    // Operational tuning settings
    public final BooleanSetting onlyWhileGliding = addSetting(
        new BooleanSetting("Only Gliding", "Only fire rockets while actively gliding with elytra", true)
    );
    public final BooleanSetting autoGlideAfterSwap = addSetting(
        new BooleanSetting("Auto Glide", "Start gliding automatically when airborne after equipping elytra", true)
    );
    public final NumberSetting swapCooldownMs = addSetting(
        new NumberSetting("Swap Delay (ms)", "Minimum delay between armor swaps", 120, 40, 500, 10)
    );
    public final NumberSetting fireworkCooldownMs = addSetting(
        new NumberSetting("Firework Delay (ms)", "Minimum cooldown between firework uses", 350, 100, 1500, 50)
    );
    public final NumberSetting normalPacingTicks = addSetting(
        new NumberSetting("Normal Pacing", "Tick spacing for silent inventory firework transfer", 1, 0, 4, 1)
    );
    public final NumberSetting legitHitLeadTicks = addSetting(
        new NumberSetting("Hit Lead (ticks)", "Ticks before enemy impact to swap back to weapon in Legit mode", 2, 1, 5, 1)
    );
    public final BooleanSetting legitAutoHit = addSetting(
        new BooleanSetting("Legit Auto Hit", "Land melee hit automatically when weapon returns in range", true)
    );

    private final CombatTimer swapTimer = new CombatTimer();
    private final CombatTimer fireworkTimer = new CombatTimer();

    private boolean swapKeyWasDown = false;
    private boolean fireworkKeyWasDown = false;

    private FireworkPhase phase = FireworkPhase.IDLE;
    private int phaseTicksRemaining = 0;

    // Saved slot state for Normal & Legit modes
    private int savedMainSlot = -1;
    private int activeFireworkHotbarSlot = -1;
    private int pulledFromInventorySlot = -1;
    private boolean queuedLegitFirework = false;
    private long lastWorldHash = 0L;

    public ElytraHelperModule() {
        super(
            "ElytraHelper",
            "Fast Chestplate/Elytra swapper and Legit/Normal firework boost manager",
            Category.MOVEMENT,
            ModuleSection.AIR_UTILITY
        );
    }

    @Override
    public void onEnable() {
        resetState(false);
    }

    @Override
    public void onDisable() {
        resetState(true);
    }

    public void resetState(boolean restoreSlot) {
        if (restoreSlot && mc != null && mc.player != null) {
            restoreLegitOrNormalSlots(mc.player);
        }
        phase = FireworkPhase.IDLE;
        phaseTicksRemaining = 0;
        savedMainSlot = -1;
        activeFireworkHotbarSlot = -1;
        pulledFromInventorySlot = -1;
        queuedLegitFirework = false;
        swapKeyWasDown = false;
        fireworkKeyWasDown = false;
    }

    @Override
    public void onTick() {
        if (mc == null || mc.player == null || mc.world == null || mc.getWindow() == null) {
            resetState(false);
            return;
        }

        long worldHash = System.identityHashCode(mc.world);
        if (worldHash != lastWorldHash || !mc.player.isAlive()) {
            resetState(false);
            lastWorldHash = worldHash;
            return;
        }

        // Advance any active multi-tick firework state machine first
        tickFireworkStateMachine(mc.player);

        // Ignore key triggers while GUI/chat/inventory is open
        if (mc.currentScreen != null) {
            swapKeyWasDown = false;
            fireworkKeyWasDown = false;
            return;
        }

        // 1. Poll Swap Button (rising edge)
        if (swapButton.isBound()) {
            boolean down = MobilePlatform.isKeyPressedSafe(mc.getWindow(), swapButton.getKeyCode());
            if (down && !swapKeyWasDown) {
                executeChestElytraSwap(mc.player);
            }
            swapKeyWasDown = down;
        } else {
            swapKeyWasDown = false;
        }

        // 2. Poll Firework Button (rising edge)
        if (fireworkButton.isBound()) {
            boolean down = MobilePlatform.isKeyPressedSafe(mc.getWindow(), fireworkButton.getKeyCode());
            if (down && !fireworkKeyWasDown) {
                triggerFirework(mc.player);
            }
            fireworkKeyWasDown = down;
        } else {
            fireworkKeyWasDown = false;
        }
    }

    // =========================================================================
    // CHESTPLATE <-> ELYTRA INSTANT SWAP
    // =========================================================================

    public boolean executeChestElytraSwap(ClientPlayerEntity player) {
        if (player == null || mc == null || mc.interactionManager == null) {
            return false;
        }
        if (!swapTimer.hasElapsed(swapCooldownMs.getInt())) {
            return false;
        }
        // Never manipulate container slots while cursor already holds an item
        if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
            return false;
        }

        ItemStack equippedChest = player.getEquippedStack(EquipmentSlot.CHEST);
        boolean wearingElytra = isElytra(equippedChest);
        int targetContainerSlot = wearingElytra
            ? findBestChestplateContainerSlot(player)
            : findElytraContainerSlot(player);

        if (targetContainerSlot < 0) {
            return false;
        }

        int syncId = player.playerScreenHandler.syncId;
        boolean swapped = false;

        // If item is in hotbar (container slots 36..44), a single SWAP action moves it in 1 packet with zero cursor residue
        if (targetContainerSlot >= 36 && targetContainerSlot <= 44) {
            int hotbarIndex = targetContainerSlot - 36;
            mc.interactionManager.clickSlot(syncId, CHEST_ARMOR_CONTAINER_SLOT, hotbarIndex, SlotActionType.SWAP, player);
            swapped = true;
        } else {
            // Main inventory (container slots 9..35): clean 3-click PICKUP sequence + inventory close sync
            mc.interactionManager.clickSlot(syncId, targetContainerSlot, 0, SlotActionType.PICKUP, player);
            mc.interactionManager.clickSlot(syncId, CHEST_ARMOR_CONTAINER_SLOT, 0, SlotActionType.PICKUP, player);
            if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
                mc.interactionManager.clickSlot(syncId, targetContainerSlot, 0, SlotActionType.PICKUP, player);
            }
            if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(syncId));
            }
            swapped = true;
        }

        if (swapped) {
            swapTimer.reset();
            // If we just equipped an elytra while airborne, trigger fall-flying immediately when enabled
            if (!wearingElytra && autoGlideAfterSwap.isEnabled()
                && !player.isOnGround() && !player.isGliding() && !player.isTouchingWater()
                && mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(
                    new ClientCommandC2SPacket(player, ClientCommandC2SPacket.Mode.START_FALL_FLYING)
                );
            }
        }
        return swapped;
    }

    // =========================================================================
    // FIREWORK DISPATCHER (LEGIT MODE & NORMAL MODE)
    // =========================================================================

    public boolean triggerFirework(ClientPlayerEntity player) {
        if (player == null || mc == null || mc.interactionManager == null) {
            return false;
        }
        if (phase != FireworkPhase.IDLE) {
            return false;
        }
        if (!fireworkTimer.hasElapsed(fireworkCooldownMs.getInt())) {
            return false;
        }
        if (onlyWhileGliding.isEnabled() && !player.isGliding()) {
            return false;
        }

        if ("Normal".equalsIgnoreCase(fireworkMode.getValue())) {
            return beginNormalSilentFirework(player);
        } else {
            return beginLegitFirework(player);
        }
    }

    // -------------------------------------------------------------------------
    // NORMAL MODE: Silent Packet-Synced Firework + Inventory Pull & Restore
    // -------------------------------------------------------------------------

    private boolean beginNormalSilentFirework(ClientPlayerEntity player) {
        int hotbarFw = findHotbarFireworkSlot(player);
        savedMainSlot = player.getInventory().getSelectedSlot();

        if (hotbarFw >= 0) {
            activeFireworkHotbarSlot = hotbarFw;
            pulledFromInventorySlot = -1;
            performSilentFireworkPacketCycle(player, savedMainSlot, activeFireworkHotbarSlot);
            fireworkTimer.reset();
            resetTransientSlots();
            return true;
        }

        // No firework in hotbar: pull cleanly from main inventory into a safe hotbar slot using SWAP
        int invFw = findMainInventoryFireworkSlot(player);
        if (invFw < 0 || !player.playerScreenHandler.getCursorStack().isEmpty()) {
            resetTransientSlots();
            return false;
        }

        int targetHotbarSlot = pickSafeTransferHotbarSlot(player, savedMainSlot);
        pulledFromInventorySlot = invFw;
        activeFireworkHotbarSlot = targetHotbarSlot;

        int syncId = player.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(syncId, pulledFromInventorySlot, activeFireworkHotbarSlot, SlotActionType.SWAP, player);
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(syncId));
        }

        int pacing = normalPacingTicks.getInt();
        if (pacing <= 0) {
            performSilentFireworkPacketCycle(player, savedMainSlot, activeFireworkHotbarSlot);
            restorePulledInventorySlot(player);
            fireworkTimer.reset();
            resetTransientSlots();
        } else {
            phase = FireworkPhase.NORMAL_FIRE_PENDING;
            phaseTicksRemaining = pacing;
        }
        return true;
    }

    private void performSilentFireworkPacketCycle(ClientPlayerEntity player, int originalSlot, int fireworkSlot) {
        if (mc == null || mc.interactionManager == null || mc.getNetworkHandler() == null) {
            return;
        }
        if (fireworkSlot < 0 || fireworkSlot > 8 || originalSlot < 0 || originalSlot > 8) {
            return;
        }
        if (!isFirework(player.getInventory().getStack(fireworkSlot))) {
            return;
        }

        boolean needSlotSwitch = (fireworkSlot != originalSlot);
        // Only transmit UpdateSelectedSlotC2SPacket when slot actually differs (avoids duplicate-slot flags)
        if (needSlotSwitch) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(fireworkSlot));
            player.getInventory().setSelectedSlot(fireworkSlot);
        }

        // Use Minecraft's sequenced interactItem so server-side prediction sequence IDs stay strictly aligned
        mc.interactionManager.interactItem(player, Hand.MAIN_HAND);

        if (needSlotSwitch) {
            player.getInventory().setSelectedSlot(originalSlot);
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(originalSlot));
        }
    }

    private void restorePulledInventorySlot(ClientPlayerEntity player) {
        if (pulledFromInventorySlot >= 9 && pulledFromInventorySlot <= 35
            && activeFireworkHotbarSlot >= 0 && activeFireworkHotbarSlot <= 8
            && mc != null && mc.interactionManager != null) {
            int syncId = player.playerScreenHandler.syncId;
            mc.interactionManager.clickSlot(syncId, pulledFromInventorySlot, activeFireworkHotbarSlot, SlotActionType.SWAP, player);
            if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(syncId));
            }
        }
    }

    // -------------------------------------------------------------------------
    // LEGIT MODE: Hotbar-Only Visible Swap + Predictive Hit-Window Protection
    // -------------------------------------------------------------------------

    private boolean beginLegitFirework(ClientPlayerEntity player) {
        // Legit Mode STRICTLY uses hotbar fireworks only (slots 0..8)
        int hotbarFw = findHotbarFireworkSlot(player);
        if (hotbarFw < 0) {
            return false;
        }

        savedMainSlot = player.getInventory().getSelectedSlot();
        activeFireworkHotbarSlot = hotbarFw;
        pulledFromInventorySlot = -1;

        // If an enemy hit window is happening RIGHT NOW, land the hit first and fire immediately on next tick
        LivingEntity imminentTarget = findImminentCombatTarget(player, legitHitLeadTicks.getInt());
        if (imminentTarget != null && isWeaponCooldownReady(player, 0.88f)) {
            queuedLegitFirework = true;
            phase = FireworkPhase.LEGIT_WAIT_FOR_HIT;
            phaseTicksRemaining = Math.max(1, legitHitLeadTicks.getInt() + 1);
            tryLandLegitHit(player, imminentTarget);
            return true;
        }

        equipLegitFireworkSlot(player);
        return true;
    }

    private void equipLegitFireworkSlot(ClientPlayerEntity player) {
        if (activeFireworkHotbarSlot < 0 || activeFireworkHotbarSlot > 8) {
            resetTransientSlots();
            return;
        }
        // Visible mainhand hotbar swap (standard vanilla slot selection)
        if (player.getInventory().getSelectedSlot() != activeFireworkHotbarSlot) {
            player.getInventory().setSelectedSlot(activeFireworkHotbarSlot);
        }
        phase = FireworkPhase.LEGIT_EQUIPPED_FIREWORK;
        // 1-tick settle window so client & server hotbar state match organically before right-clicking
        phaseTicksRemaining = 1;
    }

    private void tickFireworkStateMachine(ClientPlayerEntity player) {
        if (phase == FireworkPhase.IDLE) {
            return;
        }

        switch (phase) {
            case NORMAL_FIRE_PENDING -> {
                if (--phaseTicksRemaining <= 0) {
                    performSilentFireworkPacketCycle(player, savedMainSlot, activeFireworkHotbarSlot);
                    fireworkTimer.reset();
                    int pacing = normalPacingTicks.getInt();
                    if (pacing <= 0) {
                        restorePulledInventorySlot(player);
                        resetTransientSlots();
                    } else {
                        phase = FireworkPhase.NORMAL_RESTORE_PENDING;
                        phaseTicksRemaining = pacing;
                    }
                }
            }
            case NORMAL_RESTORE_PENDING -> {
                if (--phaseTicksRemaining <= 0) {
                    restorePulledInventorySlot(player);
                    resetTransientSlots();
                }
            }
            case LEGIT_WAIT_FOR_HIT -> {
                LivingEntity target = findImminentCombatTarget(player, legitHitLeadTicks.getInt());
                if (target != null && isWeaponCooldownReady(player, 0.88f)) {
                    boolean struck = tryLandLegitHit(player, target);
                    if (struck) {
                        // Hit landed cleanly; immediately proceed to firework swap
                        equipLegitFireworkSlot(player);
                        return;
                    }
                }
                if (--phaseTicksRemaining <= 0 || target == null || !isWeaponCooldownReady(player, 0.70f)) {
                    if (queuedLegitFirework) {
                        queuedLegitFirework = false;
                        equipLegitFireworkSlot(player);
                    } else {
                        resetTransientSlots();
                    }
                }
            }
            case LEGIT_EQUIPPED_FIREWORK -> {
                // Abort firework hold immediately if enemy entered imminent strike window so we NEVER miss a hit
                LivingEntity urgentTarget = findImminentCombatTarget(player, legitHitLeadTicks.getInt());
                if (urgentTarget != null && isWeaponCooldownReady(player, 0.85f)) {
                    restoreMainHandWeapon(player);
                    tryLandLegitHit(player, urgentTarget);
                    // Re-queue firework right after strike finishes
                    queuedLegitFirework = true;
                    phase = FireworkPhase.LEGIT_WAIT_FOR_HIT;
                    phaseTicksRemaining = 2;
                    return;
                }

                if (--phaseTicksRemaining <= 0) {
                    if (mc != null && mc.interactionManager != null
                        && player.getInventory().getSelectedSlot() == activeFireworkHotbarSlot
                        && isFirework(player.getMainHandStack())) {
                        mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
                        player.swingHand(Hand.MAIN_HAND);
                        fireworkTimer.reset();
                    }
                    // Keep firework equipped for 1 tick unless enemy impact requires instant weapon swap
                    phase = FireworkPhase.LEGIT_POST_FIRE_HOLD;
                    phaseTicksRemaining = 1;
                }
            }
            case LEGIT_POST_FIRE_HOLD -> {
                LivingEntity target = findImminentCombatTarget(player, legitHitLeadTicks.getInt());
                if (target != null || --phaseTicksRemaining <= 0) {
                    restoreMainHandWeapon(player);
                    if (target != null && isWeaponCooldownReady(player, 0.88f)) {
                        tryLandLegitHit(player, target);
                    }
                    resetTransientSlots();
                }
            }
            default -> resetTransientSlots();
        }
    }

    private void restoreMainHandWeapon(ClientPlayerEntity player) {
        if (player != null && savedMainSlot >= 0 && savedMainSlot <= 8) {
            if (player.getInventory().getSelectedSlot() != savedMainSlot) {
                player.getInventory().setSelectedSlot(savedMainSlot);
            }
        }
    }

    private void restoreLegitOrNormalSlots(ClientPlayerEntity player) {
        restoreMainHandWeapon(player);
        if (pulledFromInventorySlot >= 9) {
            restorePulledInventorySlot(player);
        }
    }

    private void resetTransientSlots() {
        phase = FireworkPhase.IDLE;
        phaseTicksRemaining = 0;
        savedMainSlot = -1;
        activeFireworkHotbarSlot = -1;
        pulledFromInventorySlot = -1;
        queuedLegitFirework = false;
    }

    // =========================================================================
    // PREDICTIVE HIT-TIMING CALCULATOR (LEGIT MODE)
    // =========================================================================

    /**
     * Pure physics predictor: returns true if the player will be within melee reach of the target
     * now or within {@code leadTicks} based on relative closing velocity.
     */
    public static boolean isHitImminent(Vec3d playerEyePos, Vec3d playerVel,
                                        Vec3d targetCenterPos, Vec3d targetVel,
                                        double attackRange, int leadTicks) {
        if (playerEyePos == null || targetCenterPos == null) {
            return false;
        }
        double currentDist = playerEyePos.distanceTo(targetCenterPos);
        if (currentDist <= attackRange + 0.35) {
            return true;
        }
        int clampedLead = Math.max(1, Math.min(8, leadTicks));
        Vec3d pVel = playerVel != null ? playerVel : Vec3d.ZERO;
        Vec3d tVel = targetVel != null ? targetVel : Vec3d.ZERO;

        for (int t = 1; t <= clampedLead; t++) {
            Vec3d predPlayer = playerEyePos.add(pVel.multiply(t));
            Vec3d predTarget = targetCenterPos.add(tVel.multiply(t));
            if (predPlayer.distanceTo(predTarget) <= attackRange + 0.25) {
                return true;
            }
        }
        return false;
    }

    private LivingEntity findImminentCombatTarget(ClientPlayerEntity player, int leadTicks) {
        if (mc == null || mc.world == null || player == null) {
            return null;
        }
        double reach = 3.1;
        PurnaDLC client = PurnaDLC.getInstance();
        AttackAura aura = client != null ? client.getModuleManager().getModule(AttackAura.class) : null;
        if (aura != null) {
            reach = aura.getSettingsBundle().attackRange.getValue();
            LivingEntity auraTarget = aura.getCombatState().getPrimaryTarget();
            if (auraTarget != null && auraTarget.isAlive() && !auraTarget.isRemoved()) {
                Vec3d aim = RotationMath.getOptimalAimPoint(player.getEyePos(), auraTarget);
                if (isHitImminent(player.getEyePos(), player.getVelocity(), aim, auraTarget.getVelocity(), reach, leadTicks)) {
                    return auraTarget;
                }
            }
        }

        // Fallback scan: nearest valid living player/mob within predicted closing window
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity living) || living == player) continue;
            if (!living.isAlive() || living.isRemoved() || living.getHealth() <= 0.0f) continue;
            if (living instanceof PlayerEntity p && (p.isCreative() || p.isSpectator())) continue;

            double dist = RotationMath.distanceToBox(player.getEyePos(), living.getBoundingBox());
            if (dist > reach + 6.0) continue;

            Vec3d aim = RotationMath.getOptimalAimPoint(player.getEyePos(), living);
            if (isHitImminent(player.getEyePos(), player.getVelocity(), aim, living.getVelocity(), reach, leadTicks)) {
                if (dist < bestDist) {
                    bestDist = dist;
                    best = living;
                }
            }
        }
        return best;
    }

    private boolean tryLandLegitHit(ClientPlayerEntity player, LivingEntity target) {
        if (!legitAutoHit.isEnabled() || mc == null || mc.interactionManager == null || player == null || target == null) {
            return false;
        }
        double reach = 3.1;
        PurnaDLC client = PurnaDLC.getInstance();
        AttackAura aura = client != null ? client.getModuleManager().getModule(AttackAura.class) : null;
        if (aura != null) {
            reach = aura.getSettingsBundle().attackRange.getValue();
            if (aura.getCombatState().hasAttackedThisTick()) {
                return true;
            }
        }

        double dist = RotationMath.distanceToBox(player.getEyePos(), target.getBoundingBox());
        if (dist > reach) {
            return false;
        }
        if (!isWeaponCooldownReady(player, 0.88f)) {
            return false;
        }

        // Guarantee mainhand weapon is equipped before attacking
        restoreMainHandWeapon(player);
        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private static boolean isWeaponCooldownReady(ClientPlayerEntity player, float threshold) {
        return player != null && player.getAttackCooldownProgress(0.5f) >= threshold;
    }

    // =========================================================================
    // INVENTORY SEARCH HELPERS
    // =========================================================================

    public int findHotbarFireworkSlot(ClientPlayerEntity player) {
        if (player == null) return -1;
        for (int i = 0; i < 9; i++) {
            if (isFirework(player.getInventory().getStack(i))) {
                return i;
            }
        }
        return -1;
    }

    public int findMainInventoryFireworkSlot(ClientPlayerEntity player) {
        if (player == null) return -1;
        for (int i = 9; i < 36; i++) {
            if (isFirework(player.getInventory().getStack(i))) {
                return i;
            }
        }
        return -1;
    }

    public int findElytraContainerSlot(ClientPlayerEntity player) {
        if (player == null) return -1;
        // Prefer hotbar first (1-packet SWAP)
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (isUsableElytra(stack)) {
                return 36 + i;
            }
        }
        // Main inventory (container slots 9..35)
        for (int i = 9; i < 36; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (isUsableElytra(stack)) {
                return i;
            }
        }
        return -1;
    }

    public int findBestChestplateContainerSlot(ClientPlayerEntity player) {
        if (player == null) return -1;
        int bestContainerSlot = -1;
        int bestTier = -1;

        for (int i = 0; i < 9; i++) {
            int tier = chestplateTier(player.getInventory().getStack(i));
            if (tier > bestTier) {
                bestTier = tier;
                bestContainerSlot = 36 + i;
            }
        }
        for (int i = 9; i < 36; i++) {
            int tier = chestplateTier(player.getInventory().getStack(i));
            if (tier > bestTier) {
                bestTier = tier;
                bestContainerSlot = i;
            }
        }
        return bestContainerSlot;
    }

    private int pickSafeTransferHotbarSlot(ClientPlayerEntity player, int currentSlot) {
        // Prefer an empty hotbar slot first so we don't disturb weapons
        for (int i = 0; i < 9; i++) {
            if (i != currentSlot && player.getInventory().getStack(i).isEmpty()) {
                return i;
            }
        }
        // Otherwise pick the rightmost slot that isn't the currently held weapon
        for (int i = 8; i >= 0; i--) {
            if (i != currentSlot) {
                return i;
            }
        }
        return Math.max(0, Math.min(8, currentSlot));
    }

    public static boolean isFirework(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.isOf(Items.FIREWORK_ROCKET);
    }

    public static boolean isElytra(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.isOf(Items.ELYTRA);
    }

    public static boolean isUsableElytra(ItemStack stack) {
        if (!isElytra(stack)) return false;
        // Skip completely broken elytras (1 durability remaining)
        return stack.getMaxDamage() <= 0 || (stack.getMaxDamage() - stack.getDamage()) > 1;
    }

    public static int chestplateTier(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return -1;
        Item item = stack.getItem();
        if (item == Items.NETHERITE_CHESTPLATE) return 6;
        if (item == Items.DIAMOND_CHESTPLATE) return 5;
        if (item == Items.IRON_CHESTPLATE) return 4;
        if (item == Items.CHAINMAIL_CHESTPLATE) return 3;
        if (item == Items.GOLDEN_CHESTPLATE) return 2;
        if (item == Items.LEATHER_CHESTPLATE) return 1;
        return -1;
    }

    public FireworkPhase getPhase() {
        return phase;
    }
}
