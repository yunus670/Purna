package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.ModeSetting;

public class ShaderSkyModule extends Module {
    public final ModeSetting preset = addSetting(new ModeSetting("Preset", "Sky shader atmosphere", "Aurora", "Aurora", "Nebula", "Midnight", "Dusk"));
    public final BooleanSetting stars = addSetting(new BooleanSetting("Enhanced Stars", "Increase starfield clarity", true));
    public final ColorSetting tint = addSetting(new ColorSetting("Tint", "Primary sky gradient tint", 0xFFB45AE8));

    public ShaderSkyModule() {
        super("ShaderSky", "Renders stylized aurora and nebula skies", Category.VISUALS, ModuleSection.WORLD);
    }
}
