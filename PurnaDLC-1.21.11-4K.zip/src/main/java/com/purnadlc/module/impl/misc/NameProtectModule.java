package com.purnadlc.module.impl.misc;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.StringSetting;

public class NameProtectModule extends Module {
    public final StringSetting alias = addSetting(new StringSetting("Alias", "Replacement username shown in HUD/GUI", "PurnaUser", 24));
    public final BooleanSetting hideInHud = addSetting(new BooleanSetting("Apply to HUD", "Replace username on PurnaDLC HUD", true));

    public NameProtectModule() {
        super("NameProtect", "Replaces your username locally across client UI", Category.MISC, ModuleSection.CLIENT, true);
    }

    public String getDisplayUsername(String realName) {
        if (isEnabled() && hideInHud.isEnabled()) {
            String custom = alias.getValue();
            return (custom == null || custom.isBlank()) ? "PurnaUser" : custom;
        }
        return realName;
    }
}
