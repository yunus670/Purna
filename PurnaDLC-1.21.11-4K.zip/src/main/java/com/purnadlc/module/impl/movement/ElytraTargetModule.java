package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class ElytraTargetModule extends Module {
    public final NumberSetting range = addSetting(new NumberSetting("Range", "Aerial lock-on range", 36, 10, 80, 2));
    public final BooleanSetting autoFirework = addSetting(new BooleanSetting("Auto Firework", "Use fireworks to sustain speed", true));

    public ElytraTargetModule() {
        super("ElytraTarget", "Tracks airborne targets during elytra flight", Category.MOVEMENT, ModuleSection.AIR_UTILITY);
    }
}
