package com.purnadlc.module.impl.combat;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class VelocityModule extends Module {
    public final ModeSetting mode = addSetting(new ModeSetting("Mode", "Knockback reduction strategy", "Percentage", "Percentage", "Cancel", "Grim"));
    public final NumberSetting horizontal = addSetting(new NumberSetting("Horizontal %", "Horizontal knockback scale", 50, 0, 100, 5));
    public final NumberSetting vertical = addSetting(new NumberSetting("Vertical %", "Vertical knockback scale", 100, 0, 100, 5));

    public VelocityModule() {
        super("Velocity", "Modifies incoming knockback impulses", Category.COMBAT, ModuleSection.COMBAT_UTILITY);
    }
}
