package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class WingsModule extends Module {
    public final ModeSetting style = addSetting(new ModeSetting("Style", "Wing silhouette", "Angel", "Angel", "Dragon", "Neon"));
    public final NumberSetting scale = addSetting(new NumberSetting("Scale", "Wing span scale", 1.0, 0.5, 1.8, 0.05));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "Wing glow color", 0xFFE6E6EB));

    public WingsModule() {
        super("Wings", "Renders animated cosmetic wings on the player", Category.VISUALS, ModuleSection.VIEW);
    }
}
