package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.MultiModeSetting;
import com.purnadlc.setting.NumberSetting;

import java.util.List;

public class ChamsModule extends Module {
    public final MultiModeSetting targets = addSetting(new MultiModeSetting("Targets", "Entities to render with chams", List.of("Players"), "Players", "Hostiles", "Passives", "Crystals"));
    public final ColorSetting visibleColor = addSetting(new ColorSetting("Visible Color", "Color when in line of sight", 0xFFB45AE8));
    public final ColorSetting hiddenColor = addSetting(new ColorSetting("Hidden Color", "Color behind walls", 0xFF8C6BEA));
    public final NumberSetting alpha = addSetting(new NumberSetting("Opacity", "Chams opacity", 0.65, 0.1, 1.0, 0.05));

    public ChamsModule() {
        super("Chams", "Highlights entity models through terrain", Category.VISUALS, ModuleSection.VIEW);
    }
}
