package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.NumberSetting;

public class HitPointModule extends Module {
    public final NumberSetting duration = addSetting(new NumberSetting("Duration", "Marker lifetime in seconds", 1.2, 0.3, 4.0, 0.1));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "Impact point marker color", 0xFFB45AE8));

    public HitPointModule() {
        super("HitPoint", "Marks exact impact positions on entity hits", Category.VISUALS, ModuleSection.WORLD);
    }
}
