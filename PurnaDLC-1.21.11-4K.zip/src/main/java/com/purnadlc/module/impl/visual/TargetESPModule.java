package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class TargetESPModule extends Module {
    public final ModeSetting style = addSetting(new ModeSetting("Style", "Target marker animation", "Orbit", "Orbit", "Square", "Ring", "Particles"));
    public final NumberSetting speed = addSetting(new NumberSetting("Speed", "Rotation speed", 1.4, 0.3, 3.5, 0.1));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "Target marker color", 0xFFB45AE8));

    public TargetESPModule() {
        super("TargetESP", "Highlights the active combat target in 3D space", Category.VISUALS, ModuleSection.WORLD);
    }
}
