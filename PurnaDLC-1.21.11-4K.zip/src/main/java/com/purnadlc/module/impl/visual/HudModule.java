package com.purnadlc.module.impl.visual;

import com.purnadlc.PurnaDLC;
import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.*;

import java.util.List;

public class HudModule extends Module {
    public final BooleanSetting crisp4k = addSetting(new BooleanSetting("4K Crisp HUD", "High-DPI crisp HUD with 512px logo", true));
    public final BooleanSetting watermark = addSetting(new BooleanSetting("Watermark", "Show top-left PurnaDLC info bar", true));
    public final BooleanSetting coordinates = addSetting(new BooleanSetting("Coordinates", "Show XYZ coordinates and BPS bar", true));
    public final BooleanSetting arrayList = addSetting(new BooleanSetting("ArrayList", "Show enabled modules in top-right", true));

    public final BooleanSetting photos = addSetting(new BooleanSetting("Photos", "Display draggable gallery photo frame on HUD", true));
    public final NumberSetting photoX = addSetting(new NumberSetting("Photo X", "Photo horizontal screen position", 12, 0, 1920, 1));
    public final NumberSetting photoY = addSetting(new NumberSetting("Photo Y", "Photo vertical screen position", 64, 0, 1080, 1));
    public final NumberSetting photoWidth = addSetting(new NumberSetting("Photo Width", "Photo frame width", 104, 36, 420, 2));
    public final NumberSetting photoHeight = addSetting(new NumberSetting("Photo Height", "Photo frame height", 104, 36, 420, 2));
    public final NumberSetting photoOpacity = addSetting(new NumberSetting("Photo Opacity", "Photo display opacity", 1.0, 0.2, 1.0, 0.05));
    public final BooleanSetting photoRounded = addSetting(new BooleanSetting("Photo Border", "Draw purple frame border around photo", true));
    public final StringSetting photoPath = addSetting(new StringSetting("Photo Path", "Selected gallery image file path", "", 260));

    public final MultiModeSetting infoItems = addSetting(new MultiModeSetting(
        "Info Items", "Metrics displayed in top bar",
        List.of("FPS", "Ping", "Time", "TPS"),
        "FPS", "Ping", "Time", "TPS"
    ));
    public final NumberSetting hudOpacity = addSetting(new NumberSetting("Opacity", "HUD panel background opacity", 0.80, 0.2, 1.0, 0.05));
    public final ColorSetting accentColor = addSetting(new ColorSetting("Accent", "HUD highlight color", 0xFFB45AE8));

    public HudModule() {
        super("Hud", "4K PurnaDLC overlay HUD with draggable gallery Photos widget", Category.VISUALS, ModuleSection.INTERFACE, true);
        photoPath.onChange(path -> {
            if (PurnaDLC.getInstance() != null && PurnaDLC.getInstance().getPhotoManager() != null) {
                PurnaDLC.getInstance().getPhotoManager().loadPhoto(path);
            }
        });
    }
}
