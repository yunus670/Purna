package com.purnadlc.module.impl.combat;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ModeSetting;

public class CriticalsModule extends Module {
    public final ModeSetting mode = addSetting(new ModeSetting("Mode", "Critical strike method", "Packet", "Packet", "MiniJump", "Strict"));

    public CriticalsModule() {
        super("Criticals", "Forces critical strikes on melee attacks", Category.COMBAT, ModuleSection.ATTACK);
    }
}
