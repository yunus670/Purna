package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.NumberSetting;

public class SeeInvisibleModule extends Module {
    public final NumberSetting opacity = addSetting(new NumberSetting("Opacity", "Translucent alpha for invisible entities", 0.45, 0.1, 1.0, 0.05));

    public SeeInvisibleModule() {
        super("SeeInvisible", "Reveals entities with invisibility status", Category.VISUALS, ModuleSection.WORLD);
    }
}
