package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class AmbienceModule extends Module {
    public final NumberSetting worldTime = addSetting(new NumberSetting("Time", "Client-side world time of day", 18000, 0, 24000, 500));
    public final ModeSetting weather = addSetting(new ModeSetting("Weather", "Client weather override", "Clear", "Clear", "Rain", "Thunder"));
    public final ColorSetting fogColor = addSetting(new ColorSetting("Fog Tint", "Ambient sky and fog tint", 0xFF8C6BEA));

    public AmbienceModule() {
        super("Ambience", "Controls client-side time, weather, and fog tint", Category.VISUALS, ModuleSection.WORLD);
    }
}
