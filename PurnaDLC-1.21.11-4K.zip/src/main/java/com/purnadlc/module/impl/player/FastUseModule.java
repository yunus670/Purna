package com.purnadlc.module.impl.player;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.MultiModeSetting;
import com.purnadlc.setting.NumberSetting;

import java.util.List;

public class FastUseModule extends Module {
    public final NumberSetting delay = addSetting(new NumberSetting("Tick Delay", "Ticks between right-click uses", 1, 0, 4, 1));
    public final MultiModeSetting items = addSetting(new MultiModeSetting("Items", "Allowed fast-use items", List.of("XP", "Blocks"), "XP", "Blocks", "Crystals", "Snowballs"));

    public FastUseModule() {
        super("FastUse", "Reduces right-click cooldown for selected items", Category.PLAYER, ModuleSection.INVENTORY);
    }
}
