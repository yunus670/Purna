package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.NumberSetting;

public class RoolsModule extends Module {
    public final NumberSetting length = addSetting(new NumberSetting("Length", "Trail ribbon length in blocks", 5.0, 1.0, 12.0, 0.5));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "Ribbon color", 0xFFB45AE8));

    public RoolsModule() {
        super("Rools", "Renders smooth cosmetic movement ribbons", Category.VISUALS, ModuleSection.VIEW);
    }
}
