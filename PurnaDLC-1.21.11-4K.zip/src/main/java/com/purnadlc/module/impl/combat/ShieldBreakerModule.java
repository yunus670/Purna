package com.purnadlc.module.impl.combat;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class ShieldBreakerModule extends Module {
    public final BooleanSetting swapBack = addSetting(new BooleanSetting("Swap Back", "Return to previous hotbar slot", true));
    public final NumberSetting delay = addSetting(new NumberSetting("Swap Delay", "Delay before axe strike (ms)", 30, 0, 150, 5));

    public ShieldBreakerModule() {
        super("ShieldBreaker", "Swaps to an axe to disable blocking shields", Category.COMBAT, ModuleSection.COMBAT_UTILITY);
    }
}
