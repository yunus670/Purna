package com.purnadlc.module.impl.misc;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.NumberSetting;

public class AutoRespawnModule extends Module {
    public final NumberSetting delayTicks = addSetting(new NumberSetting("Delay (ticks)", "Ticks to wait before respawning", 10, 0, 60, 2));

    public AutoRespawnModule() {
        super("AutoRespawn", "Automatically respawns after death", Category.MISC, ModuleSection.MISC_UTILITY);
    }
}
