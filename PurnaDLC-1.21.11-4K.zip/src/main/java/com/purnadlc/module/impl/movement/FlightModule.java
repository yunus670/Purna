package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class FlightModule extends Module {
    public final NumberSetting speed = addSetting(new NumberSetting("Speed", "Flight speed", 1.2, 0.2, 4.0, 0.1));
    public final BooleanSetting antiKick = addSetting(new BooleanSetting("Anti-Kick", "Apply micro-descent intervals", true));

    public FlightModule() {
        super("Flight", "Enables free-form aerial movement", Category.MOVEMENT, ModuleSection.AIR_UTILITY);
    }
}
