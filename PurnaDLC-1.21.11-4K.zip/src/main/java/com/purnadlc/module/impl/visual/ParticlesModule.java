package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class ParticlesModule extends Module {
    public final ModeSetting shape = addSetting(new ModeSetting("Shape", "Custom hit/world particle shape", "Star", "Star", "Heart", "Spark", "Orb"));
    public final NumberSetting count = addSetting(new NumberSetting("Count", "Particles spawned per event", 12, 4, 32, 1));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "Particle tint", 0xFFB45AE8));

    public ParticlesModule() {
        super("Particles", "Spawns stylized combat and movement particles", Category.VISUALS, ModuleSection.WORLD);
    }
}
