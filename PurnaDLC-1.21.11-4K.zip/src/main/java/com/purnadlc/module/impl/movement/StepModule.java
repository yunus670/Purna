package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.NumberSetting;

public class StepModule extends Module {
    public final NumberSetting height = addSetting(new NumberSetting("Height", "Maximum step-up height", 1.0, 0.6, 2.5, 0.1));

    public StepModule() {
        super("Step", "Allows stepping up full blocks without jumping", Category.MOVEMENT, ModuleSection.GROUND);
    }
}
