package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class SpeedModule extends Module {
    public final ModeSetting mode = addSetting(new ModeSetting("Mode", "Speed movement profile", "Strafe", "Strafe", "Vanilla", "LowHop"));
    public final NumberSetting multiplier = addSetting(new NumberSetting("Speed", "Movement speed multiplier", 1.25, 1.0, 2.5, 0.05));

    public SpeedModule() {
        super("Speed", "Increases horizontal ground movement velocity", Category.MOVEMENT, ModuleSection.GROUND);
    }
}
