package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class SwingAnimationModule extends Module {
    public final ModeSetting style = addSetting(new ModeSetting("Style", "Swing motion preset", "Smooth", "Smooth", "Swipe", "Block", "Drop"));
    public final NumberSetting speed = addSetting(new NumberSetting("Speed", "Swing duration multiplier", 1.0, 0.4, 2.5, 0.1));
    public final NumberSetting angle = addSetting(new NumberSetting("Angle", "Swipe rotation angle", 45.0, 10.0, 90.0, 1.0));

    public SwingAnimationModule() {
        super("SwingAnimation", "Customizes first-person weapon swing animations", Category.VISUALS, ModuleSection.VIEW);
    }
}
