package com.purnadlc.module;

public enum ModuleSection {
    // Visuals (Exact match to reference screenshot columns)
    INTERFACE("Interface", ColumnSide.LEFT, 0),
    VIEW("View", ColumnSide.LEFT, 1),
    RENDER("Render", ColumnSide.LEFT, 2),
    WORLD("World", ColumnSide.RIGHT, 0),
    OVERLAY("Overlay", ColumnSide.RIGHT, 1),

    // Combat
    ATTACK("Attack", ColumnSide.LEFT, 0),
    COMBAT_UTILITY("Utility", ColumnSide.RIGHT, 0),

    // Movement
    GROUND("Ground", ColumnSide.LEFT, 0),
    AIR_UTILITY("Air & Utility", ColumnSide.RIGHT, 0),

    // Player
    INVENTORY("Inventory", ColumnSide.LEFT, 0),
    ACTIONS("Actions", ColumnSide.RIGHT, 0),

    // Misc
    CLIENT("Client", ColumnSide.LEFT, 0),
    MISC_UTILITY("Utility", ColumnSide.RIGHT, 0);

    public enum ColumnSide {
        LEFT,
        RIGHT
    }

    private final String title;
    private final ColumnSide columnSide;
    private final int order;

    ModuleSection(String title, ColumnSide columnSide, int order) {
        this.title = title;
        this.columnSide = columnSide;
        this.order = order;
    }

    public String getTitle() {
        return title;
    }

    public ColumnSide getColumnSide() {
        return columnSide;
    }

    public int getOrder() {
        return order;
    }
}
