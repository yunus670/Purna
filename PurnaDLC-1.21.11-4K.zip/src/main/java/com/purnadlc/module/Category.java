package com.purnadlc.module;

public enum Category {
    COMBAT("Combat", SidebarGroup.MAIN, "combat"),
    MOVEMENT("Movement", SidebarGroup.MAIN, "movement"),
    PLAYER("Player", SidebarGroup.MAIN, "player"),
    VISUALS("Visuals", SidebarGroup.MAIN, "visuals"),
    MISC("Misc", SidebarGroup.MAIN, "misc"),
    THEME("Theme", SidebarGroup.OTHER, "theme"),
    IRC("IRC", SidebarGroup.OTHER, "irc");

    public enum SidebarGroup {
        MAIN("MAIN"),
        OTHER("OTHER");

        private final String header;

        SidebarGroup(String header) {
            this.header = header;
        }

        public String getHeader() {
            return header;
        }
    }

    private final String displayName;
    private final SidebarGroup group;
    private final String iconId;

    Category(String displayName, SidebarGroup group, String iconId) {
        this.displayName = displayName;
        this.group = group;
        this.iconId = iconId;
    }

    public String getDisplayName() {
        return displayName;
    }

    public SidebarGroup getGroup() {
        return group;
    }

    public String getIconId() {
        return iconId;
    }
}
