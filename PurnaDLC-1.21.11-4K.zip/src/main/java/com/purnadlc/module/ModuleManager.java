package com.purnadlc.module;

import com.purnadlc.combat.aura.AttackAura;
import com.purnadlc.module.impl.combat.*;
import com.purnadlc.module.impl.misc.*;
import com.purnadlc.module.impl.movement.*;
import com.purnadlc.module.impl.player.*;
import com.purnadlc.module.impl.visual.*;

import java.util.*;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<String, Module> byName = new LinkedHashMap<>();

    public ModuleManager() {
        // VISUALS — Left Column (Interface, View, Render) matching reference screenshot
        register(new HudModule());
        register(new AspectRatioModule());
        register(new ViewModelModule());
        register(new ShaderHandsModule());
        register(new CustomModelsModule());
        register(new ChamsModule());
        register(new SwingAnimationModule());
        register(new ChinaHatModule());
        register(new WingsModule());
        register(new RoolsModule());
        register(new BoxModule());
        register(new ItemRendererModule());

        // VISUALS — Right Column (World, Overlay) matching reference screenshot
        register(new AmbienceModule());
        register(new ShaderSkyModule());
        register(new ParticlesModule());
        register(new TargetESPModule());
        register(new BlockOverlayModule());
        register(new HitPointModule());
        register(new SeeInvisibleModule());
        register(new NoRenderModule());
        register(new TagsModule());
        register(new ArrowsModule());
        register(new PredictionModule());
        register(new ShulkerPreviewModule());

        // COMBAT
        register(new AttackAura());
        register(new AutoCrystalModule());
        register(new CriticalsModule());
        register(new TriggerBotModule());
        register(new ShieldBreakerModule());
        register(new VelocityModule());
        register(new AutoTotemModule());
        register(new AimAssistModule());

        // MOVEMENT
        register(new SprintModule());
        register(new SpeedModule());
        register(new NoSlowModule());
        register(new StepModule());
        register(new FlightModule());
        register(new ElytraTargetModule());
        register(new ElytraHelperModule());
        register(new ScaffoldModule());
        register(new SafeWalkModule());

        // PLAYER
        register(new AutoArmorModule());
        register(new ChestStealerModule());
        register(new FastUseModule());
        register(new NoFallModule());
        register(new AutoToolModule());
        register(new AntiAFKModule());

        // MISC
        register(new NameProtectModule());
        register(new ClickGuiModule());
        register(new NotificationsModule());
        register(new AutoRespawnModule());
    }

    private void register(Module module) {
        modules.add(module);
        byName.put(module.getName().toLowerCase(Locale.ROOT), module);
    }

    public List<Module> getAllModules() {
        return Collections.unmodifiableList(modules);
    }

    public Module getByName(String name) {
        if (name == null) return null;
        return byName.get(name.toLowerCase(Locale.ROOT));
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module m : modules) {
            if (clazz.isInstance(m)) {
                return (T) m;
            }
        }
        return null;
    }

    public List<Module> getByCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) {
                result.add(m);
            }
        }
        return result;
    }

    public Map<ModuleSection, List<Module>> getSectionsForColumn(Category category, ModuleSection.ColumnSide side) {
        Map<ModuleSection, List<Module>> grouped = new LinkedHashMap<>();
        List<ModuleSection> orderedSections = new ArrayList<>();
        for (ModuleSection sec : ModuleSection.values()) {
            if (sec.getColumnSide() == side) {
                orderedSections.add(sec);
            }
        }
        orderedSections.sort(Comparator.comparingInt(ModuleSection::getOrder));

        for (ModuleSection sec : orderedSections) {
            List<Module> list = new ArrayList<>();
            for (Module m : modules) {
                if (m.getCategory() == category && m.getSection() == sec) {
                    list.add(m);
                }
            }
            if (!list.isEmpty()) {
                grouped.put(sec, list);
            }
        }
        return grouped;
    }

    public List<Module> search(String query) {
        if (query == null || query.trim().isEmpty()) {
            return Collections.emptyList();
        }
        String needle = query.trim().toLowerCase(Locale.ROOT);
        List<Module> startsWith = new ArrayList<>();
        List<Module> contains = new ArrayList<>();
        for (Module m : modules) {
            String lower = m.getName().toLowerCase(Locale.ROOT);
            if (lower.startsWith(needle)) {
                startsWith.add(m);
            } else if (lower.contains(needle) || m.getSection().getTitle().toLowerCase(Locale.ROOT).contains(needle)) {
                contains.add(m);
            }
        }
        startsWith.addAll(contains);
        return startsWith;
    }

    public List<Module> getEnabledModules() {
        List<Module> active = new ArrayList<>();
        for (Module m : modules) {
            if (m.isEnabled()) {
                active.add(m);
            }
        }
        return active;
    }

    public void onClientTick() {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onTick();
            }
        }
    }
}
