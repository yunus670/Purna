package com.purnadlc.combat.aura;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;

public final class ShieldBreaker {
    public enum ShieldState { IDLE, AXE_EQUIPPED, AWAITING_RESTORE }

    private ShieldState state = ShieldState.IDLE;
    private int savedSlot = -1;
    private int activeAxeSlot = -1;
    private final CombatTimer breakTimer = new CombatTimer();

    public boolean isTargetBlocking(LivingEntity target, AttackAuraSettings settings) {
        if (target == null || !target.isAlive() || !settings.shieldDetection.isEnabled()) return false;
        return target.isBlocking();
    }

    public int findHotbarAxeSlot(ClientPlayerEntity player) {
        if (player == null) return -1;
        for (int slot = 0; slot < 9; slot++) {
            if (isAxeStack(player.getInventory().getStack(slot))) return slot;
        }
        return -1;
    }

    public boolean isHoldingAxe(ClientPlayerEntity player) {
        if (player == null) return false;
        int current = player.getInventory().getSelectedSlot();
        return current >= 0 && current < 9 && isAxeStack(player.getInventory().getStack(current));
    }

    public boolean prepareIfNeeded(ClientPlayerEntity player, LivingEntity target, AttackAuraSettings settings) {
        if (player == null || !settings.shieldBreaker.isEnabled() || !isTargetBlocking(target, settings)) {
            restoreSlotIfNeeded(player, settings);
            return false;
        }
        if (!breakTimer.hasElapsed(settings.shieldBreakDelay.getInt())) return false;

        if (isHoldingAxe(player)) {
            state = ShieldState.AXE_EQUIPPED;
            return true;
        }
        if (!settings.autoAxe.isEnabled()) return false;

        int axeSlot = findHotbarAxeSlot(player);
        if (axeSlot < 0 || axeSlot >= 9) return false;

        int currentSlot = player.getInventory().getSelectedSlot();
        if (currentSlot >= 0 && currentSlot < 9 && savedSlot == -1) {
            savedSlot = currentSlot;
        }
        player.getInventory().setSelectedSlot(axeSlot);
        activeAxeSlot = axeSlot;
        state = ShieldState.AXE_EQUIPPED;
        return true;
    }

    public void onShieldStrikeExecuted(ClientPlayerEntity player, AttackAuraSettings settings) {
        if (state == ShieldState.AXE_EQUIPPED) {
            breakTimer.reset();
            state = ShieldState.AWAITING_RESTORE;
            if (settings.restorePreviousSlot.isEnabled()) {
                restoreSlotIfNeeded(player, settings);
            } else {
                savedSlot = -1;
                activeAxeSlot = -1;
                state = ShieldState.IDLE;
            }
        }
    }

    public void restoreSlotIfNeeded(ClientPlayerEntity player, AttackAuraSettings settings) {
        if (savedSlot >= 0 && savedSlot < 9 && player != null && settings != null && settings.restorePreviousSlot.isEnabled()) {
            player.getInventory().setSelectedSlot(savedSlot);
        }
        savedSlot = -1;
        activeAxeSlot = -1;
        state = ShieldState.IDLE;
    }

    public ShieldState getState() { return state; }
    public int getSavedSlot() { return savedSlot; }
    public int getActiveAxeSlot() { return activeAxeSlot; }

    public ShieldState simulateTransition(boolean shieldBreakerEnabled, boolean targetBlocking,
                                          boolean hasAxe, int currentSlot, int axeSlot,
                                          boolean restoreSlot, boolean strikeExecuted) {
        if (!shieldBreakerEnabled || !targetBlocking) {
            savedSlot = -1;
            activeAxeSlot = -1;
            state = ShieldState.IDLE;
            return state;
        }
        if (state == ShieldState.IDLE && hasAxe && axeSlot >= 0 && axeSlot < 9) {
            savedSlot = currentSlot;
            activeAxeSlot = axeSlot;
            state = ShieldState.AXE_EQUIPPED;
        }
        if (strikeExecuted && state == ShieldState.AXE_EQUIPPED) {
            state = restoreSlot ? ShieldState.IDLE : ShieldState.AWAITING_RESTORE;
            if (restoreSlot) {
                savedSlot = -1;
                activeAxeSlot = -1;
            }
        }
        return state;
    }

    public void reset(ClientPlayerEntity player, AttackAuraSettings settings) {
        restoreSlotIfNeeded(player, settings);
        breakTimer.reset();
    }

    private static boolean isAxeStack(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.isIn(ItemTags.AXES);
    }
}
