package com.purnadlc.combat.aura.rotation;

import com.purnadlc.combat.aura.AttackAuraSettings;
import com.purnadlc.combat.aura.RotationMath;
import com.purnadlc.combat.aura.RotationProfile;

public final class FuntimeRotationProfile implements RotationProfile {
    private float lastYawDelta = 0.0f;
    private float lastPitchDelta = 0.0f;
    private int transitionTicks = 0;
    private int phaseTick = 0;

    @Override
    public String getName() { return "Funtime"; }

    @Override
    public RotationResult computeNext(RotationInput input, AttackAuraSettings settings) {
        phaseTick++;
        if (input.targetSwitched()) onTargetChanged();

        float pitchLimit = settings.pitchLimit.getFloat();
        float currentYaw = validateAngle(input.currentYaw(), 0.0f);
        float currentPitch = RotationMath.clampPitch(validateAngle(input.currentPitch(), 0.0f), pitchLimit);
        float targetYaw = RotationMath.normalizeYaw(validateAngle(input.targetYaw(), currentYaw));
        float targetPitch = RotationMath.clampPitch(validateAngle(input.targetPitch(), currentPitch), pitchLimit);

        float yawDiff = RotationMath.yawDifference(currentYaw, targetYaw);
        float pitchDiff = targetPitch - currentPitch;

        float settleScale = 1.0f;
        if (transitionTicks > 0) {
            settleScale = 0.45f + 0.11f * (5 - transitionTicks);
            transitionTicks--;
        }

        float maxGlobal = settings.maxRotationSpeed.getFloat();
        float interp = settings.interpolation.getFloat();
        float smooth = settings.smoothness.getFloat();

        float absYaw = Math.abs(yawDiff);
        float yawResponseCurve = (float) (0.30 + 0.70 * Math.tanh(absYaw / 32.0));
        float yawStepLimit = Math.min(maxGlobal, settings.horizontalSpeed.getFloat()) * settleScale;
        float rawYawStep = yawDiff * Math.min(1.0f, interp * (0.65f + 0.55f * yawResponseCurve));
        float yawStep = rawYawStep * (1.0f - smooth * 0.40f) + lastYawDelta * (smooth * 0.40f);
        if (absYaw > 4.0f) {
            float wave = (float) Math.sin(phaseTick * 0.55) * Math.min(1.1f, absYaw * 0.03f);
            yawStep += wave;
        }
        yawStep = clamp(yawStep, -yawStepLimit, yawStepLimit);
        if (absYaw < 0.25f) yawStep = 0.0f;
        else if (Math.abs(yawStep) > absYaw) yawStep = yawDiff;

        float absPitch = Math.abs(pitchDiff);
        float pitchResponseCurve = (float) (0.25 + 0.75 * (1.0 - Math.exp(-absPitch / 22.0)));
        float pitchStepLimit = Math.min(maxGlobal * 0.75f, settings.verticalSpeed.getFloat()) * settleScale;
        float rawPitchStep = pitchDiff * Math.min(1.0f, interp * 0.80f * pitchResponseCurve);
        float pitchStep = rawPitchStep * (1.0f - smooth * 0.50f) + lastPitchDelta * (smooth * 0.50f);
        pitchStep = clamp(pitchStep, -pitchStepLimit, pitchStepLimit);
        if (absPitch < 0.30f) pitchStep = 0.0f;
        else if (Math.abs(pitchStep) > absPitch) pitchStep = pitchDiff;

        lastYawDelta = yawStep;
        lastPitchDelta = pitchStep;

        return new RotationResult(
            RotationMath.normalizeYaw(currentYaw + yawStep),
            RotationMath.clampPitch(currentPitch + pitchStep, pitchLimit)
        );
    }

    @Override
    public void onTargetChanged() {
        this.transitionTicks = 5;
        this.lastYawDelta *= 0.3f;
        this.lastPitchDelta *= 0.3f;
    }

    @Override
    public void reset() {
        this.lastYawDelta = 0.0f;
        this.lastPitchDelta = 0.0f;
        this.transitionTicks = 0;
        this.phaseTick = 0;
    }

    private static float validateAngle(float candidate, float fallback) {
        return Float.isFinite(candidate) ? candidate : fallback;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
