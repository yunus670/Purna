package com.purnadlc.combat.aura.state;

import com.purnadlc.combat.aura.RotationMath;

public final class ServerRotationState {
    private float syncedYaw;
    private float syncedPitch;
    private long lastSyncTick;
    private boolean synchronizedState;

    public void recordSync(float yaw, float pitch, long tick) {
        this.syncedYaw = RotationMath.normalizeYaw(yaw);
        this.syncedPitch = RotationMath.clampPitch(pitch);
        this.lastSyncTick = tick;
        this.synchronizedState = true;
    }

    public float getSyncedYaw() { return syncedYaw; }
    public float getSyncedPitch() { return syncedPitch; }
    public long getLastSyncTick() { return lastSyncTick; }
    public boolean isSynchronized() { return synchronizedState; }

    public boolean isStale(long currentTick, long maxAgeTicks) {
        return !synchronizedState || (currentTick - lastSyncTick) > maxAgeTicks;
    }

    public void reset() {
        this.syncedYaw = 0.0f;
        this.syncedPitch = 0.0f;
        this.lastSyncTick = 0L;
        this.synchronizedState = false;
    }
}
