package com.purnadlc.combat.aura.state;

import com.purnadlc.combat.aura.RotationMath;

public final class CameraRotation {
    private float yaw;
    private float pitch;
    private boolean initialized;

    public CameraRotation() {
        this(0.0f, 0.0f);
        this.initialized = false;
    }

    public CameraRotation(float yaw, float pitch) {
        this.yaw = RotationMath.normalizeYaw(yaw);
        this.pitch = RotationMath.clampPitch(pitch);
        this.initialized = true;
    }

    public void updateFromPlayer(float playerYaw, float playerPitch) {
        this.yaw = RotationMath.normalizeYaw(playerYaw);
        this.pitch = RotationMath.clampPitch(playerPitch);
        this.initialized = true;
    }

    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    public boolean isInitialized() { return initialized; }

    public void reset() {
        this.yaw = 0.0f;
        this.pitch = 0.0f;
        this.initialized = false;
    }
}
