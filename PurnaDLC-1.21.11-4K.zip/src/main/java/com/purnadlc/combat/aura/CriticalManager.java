package com.purnadlc.combat.aura;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

public final class CriticalManager {
    public record PlayerMovementSnapshot(
        boolean onGround,
        double fallDistance,
        double velocityY,
        boolean climbing,
        boolean swimming,
        boolean inWater,
        boolean riding,
        boolean blinded,
        boolean slowFalling,
        boolean gliding,
        float attackCooldownProgress
    ) {}

    public enum CriticalVerdict {
        NOT_REQUIRED, READY, WAIT_FOR_AIRBORNE_FALL, BLOCKED_BY_ENVIRONMENT, WAIT_FOR_COOLDOWN, WAIT_FOR_DELAY
    }

    private final CombatTimer critTimer = new CombatTimer();

    public CriticalVerdict evaluate(ClientPlayerEntity player, AttackAuraSettings settings) {
        if (player == null) return CriticalVerdict.BLOCKED_BY_ENVIRONMENT;
        PlayerMovementSnapshot snapshot = new PlayerMovementSnapshot(
            player.isOnGround(),
            player.fallDistance,
            player.getVelocity().y,
            player.isClimbing(),
            player.isSwimming(),
            player.isTouchingWater() || player.isSubmergedInWater(),
            player.hasVehicle(),
            player.hasStatusEffect(StatusEffects.BLINDNESS),
            player.hasStatusEffect(StatusEffects.SLOW_FALLING),
            player.isGliding(),
            player.getAttackCooldownProgress(0.5f)
        );
        return evaluateSnapshot(snapshot, settings);
    }

    public CriticalVerdict evaluateSnapshot(PlayerMovementSnapshot s, AttackAuraSettings settings) {
        if (!settings.onlyCrit.isEnabled()) return CriticalVerdict.NOT_REQUIRED;
        if (s == null) return CriticalVerdict.BLOCKED_BY_ENVIRONMENT;

        if (s.climbing() || s.swimming() || s.inWater() || s.riding() || s.blinded() || s.slowFalling() || s.gliding()) {
            return CriticalVerdict.BLOCKED_BY_ENVIRONMENT;
        }
        if (settings.fullCooldownRequirement.isEnabled() && s.attackCooldownProgress() <= 0.90f) {
            return CriticalVerdict.WAIT_FOR_COOLDOWN;
        }
        if (settings.groundCheck.isEnabled() && s.onGround()) {
            return CriticalVerdict.WAIT_FOR_AIRBORNE_FALL;
        }
        if (settings.airborneCheck.isEnabled() && !(s.fallDistance() > 0.0 && s.velocityY() < 0.0)) {
            return CriticalVerdict.WAIT_FOR_AIRBORNE_FALL;
        }
        if (!critTimer.hasElapsed(settings.criticalDelay.getInt())) {
            return CriticalVerdict.WAIT_FOR_DELAY;
        }
        return CriticalVerdict.READY;
    }

    public boolean canAttackNow(ClientPlayerEntity player, AttackAuraSettings settings) {
        CriticalVerdict v = evaluate(player, settings);
        return v == CriticalVerdict.NOT_REQUIRED || v == CriticalVerdict.READY;
    }

    public void recordCriticalAttack() { critTimer.reset(); }
    public void reset() { critTimer.reset(); }
}
