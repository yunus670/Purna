package com.purnadlc.combat.aura.movefix;

import com.purnadlc.combat.aura.AttackAuraSettings;
import com.purnadlc.combat.aura.RotationMath;
import com.purnadlc.combat.aura.state.RotationStateManager;
import net.minecraft.util.math.Vec2f;

public final class MoveFixController {
    private final RotationStateManager stateManager;

    public MoveFixController(RotationStateManager stateManager) {
        this.stateManager = stateManager;
    }

    public boolean isMoveFixActive(AttackAuraSettings settings) {
        return settings != null
            && stateManager.isCombatRotationActive()
            && settings.moveFixMode.getValue() != AttackAuraSettings.MoveFixMode.OFF;
    }

    public boolean shouldFixStrafe(AttackAuraSettings settings) {
        return isMoveFixActive(settings) && settings.strafeFix.isEnabled();
    }

    public boolean shouldFixJump(AttackAuraSettings settings) {
        return isMoveFixActive(settings) && settings.jumpFix.isEnabled();
    }

    public float getMovementYaw(float fallbackYaw, AttackAuraSettings settings) {
        return isMoveFixActive(settings) ? stateManager.getCombatRotation().getYaw() : fallbackYaw;
    }

    public Vec2f correctMovementInput(Vec2f rawInput, float cameraYaw, float combatYaw,
                                      AttackAuraSettings.MoveFixMode mode) {
        if (rawInput == null || mode == null || mode == AttackAuraSettings.MoveFixMode.OFF) {
            return rawInput != null ? rawInput : Vec2f.ZERO;
        }
        if (mode == AttackAuraSettings.MoveFixMode.FOCUSED) {
            return rawInput;
        }

        float sideways = rawInput.x;
        float forward = rawInput.y;
        if (Math.abs(forward) < 1.0e-4f && Math.abs(sideways) < 1.0e-4f) {
            return rawInput;
        }

        // Exact inverse rotation matching Minecraft's Entity.movementInputToVelocity
        float deltaDeg = RotationMath.yawDifference(combatYaw, cameraYaw);
        double rad = Math.toRadians(deltaDeg);
        double cos = Math.cos(rad);
        double sin = Math.sin(rad);

        double rotatedForward = forward * cos + sideways * sin;
        double rotatedSideways = sideways * cos - forward * sin;

        float snappedForward = Math.round((float) rotatedForward);
        float snappedSideways = Math.round((float) rotatedSideways);

        float rawLen = (float) Math.hypot(sideways, forward);
        float snappedLen = (float) Math.hypot(snappedSideways, snappedForward);
        if (snappedLen > 1.0e-4f && rawLen < 0.99f) {
            float scale = rawLen / snappedLen;
            snappedSideways *= scale;
            snappedForward *= scale;
        }

        return new Vec2f(snappedSideways, snappedForward);
    }
}
