package com.purnadlc.combat.aura;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Stateless, allocation-minimal rotation mathematics utilities for PurnaDLC AttackAura.
 * All angles are expressed in Minecraft degrees (yaw: -180..180, pitch: -90..90).
 */
public final class RotationMath {
    public static final float MIN_PITCH = -90.0f;
    public static final float MAX_PITCH = 90.0f;
    private static final double EPSILON = 1.0e-7;

    private RotationMath() {}

    public static float calculateTargetYaw(double fromX, double fromZ, double toX, double toZ) {
        double dx = toX - fromX;
        double dz = toZ - fromZ;
        if (Math.abs(dx) < EPSILON && Math.abs(dz) < EPSILON) {
            return 0.0f;
        }
        double angleDeg = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        return normalizeYaw((float) angleDeg);
    }

    public static float calculateTargetYaw(Vec3d eyePos, Vec3d targetPos) {
        if (eyePos == null || targetPos == null) {
            return 0.0f;
        }
        return calculateTargetYaw(eyePos.x, eyePos.z, targetPos.x, targetPos.z);
    }

    public static float calculateTargetPitch(double fromX, double fromY, double fromZ,
                                             double toX, double toY, double toZ) {
        double dx = toX - fromX;
        double dy = toY - fromY;
        double dz = toZ - fromZ;
        double horizontalDist = Math.hypot(dx, dz);
        if (horizontalDist < EPSILON) {
            if (Math.abs(dy) < EPSILON) {
                return 0.0f;
            }
            return dy > 0.0 ? MIN_PITCH : MAX_PITCH;
        }
        double pitchDeg = -Math.toDegrees(Math.atan2(dy, horizontalDist));
        return clampPitch((float) pitchDeg);
    }

    public static float calculateTargetPitch(Vec3d eyePos, Vec3d targetPos) {
        if (eyePos == null || targetPos == null) {
            return 0.0f;
        }
        return calculateTargetPitch(eyePos.x, eyePos.y, eyePos.z, targetPos.x, targetPos.y, targetPos.z);
    }

    public static float normalizeYaw(float yaw) {
        if (!Float.isFinite(yaw)) {
            return 0.0f;
        }
        float wrapped = yaw % 360.0f;
        if (wrapped > 180.0f) {
            wrapped -= 360.0f;
        } else if (wrapped < -180.0f) {
            wrapped += 360.0f;
        }
        return wrapped;
    }

    public static float yawDifference(float currentYaw, float targetYaw) {
        if (!Float.isFinite(currentYaw) || !Float.isFinite(targetYaw)) {
            return 0.0f;
        }
        return normalizeYaw(targetYaw - currentYaw);
    }

    public static float pitchDifference(float currentPitch, float targetPitch) {
        if (!Float.isFinite(currentPitch) || !Float.isFinite(targetPitch)) {
            return 0.0f;
        }
        return clampPitch(targetPitch) - clampPitch(currentPitch);
    }

    public static float clampPitch(float pitch) {
        return clampPitch(pitch, MAX_PITCH);
    }

    public static float clampPitch(float pitch, float limit) {
        if (!Float.isFinite(pitch)) {
            return 0.0f;
        }
        float safeLimit = Float.isFinite(limit) ? Math.max(1.0f, Math.min(MAX_PITCH, Math.abs(limit))) : MAX_PITCH;
        return Math.max(-safeLimit, Math.min(safeLimit, pitch));
    }

    public static float interpolateAngle(float current, float delta, float factor, float maxStep) {
        if (!Float.isFinite(current) || !Float.isFinite(delta)) {
            return 0.0f;
        }
        float safeFactor = Math.max(0.0f, Math.min(1.0f, Float.isFinite(factor) ? factor : 0.0f));
        float safeMax = Math.max(0.0f, Float.isFinite(maxStep) ? maxStep : 180.0f);
        float step = delta * safeFactor;
        if (step > safeMax) {
            step = safeMax;
        } else if (step < -safeMax) {
            step = -safeMax;
        }
        return current + step;
    }

    public static float interpolateYaw(float currentYaw, float targetYaw, float factor, float maxStep) {
        float diff = yawDifference(currentYaw, targetYaw);
        return normalizeYaw(interpolateAngle(currentYaw, diff, factor, maxStep));
    }

    public static float interpolatePitch(float currentPitch, float targetPitch, float factor, float maxStep, float pitchLimit) {
        float clampedTarget = clampPitch(targetPitch, pitchLimit);
        float diff = clampedTarget - clampPitch(currentPitch, pitchLimit);
        return clampPitch(interpolateAngle(currentPitch, diff, factor, maxStep), pitchLimit);
    }

    public static float transitionEase(float progress) {
        float t = Math.max(0.0f, Math.min(1.0f, Float.isFinite(progress) ? progress : 1.0f));
        float inv = 1.0f - t;
        return 1.0f - inv * inv * inv;
    }

    public static float computeGcdStep(double mouseSensitivity) {
        double sens = Math.max(0.05, Math.min(1.0, Double.isFinite(mouseSensitivity) ? mouseSensitivity : 0.5));
        double f = sens * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }

    public static float snapToGcd(float delta, float gcdStep) {
        if (!Float.isFinite(delta) || !Float.isFinite(gcdStep) || gcdStep <= 1.0e-5f) {
            return delta;
        }
        return Math.round(delta / gcdStep) * gcdStep;
    }

    public static Vec3d getOptimalAimPoint(Vec3d eyePos, Entity target) {
        if (eyePos == null || target == null) {
            return Vec3d.ZERO;
        }
        Box box = target.getBoundingBox();
        double minY = box.minY + (box.maxY - box.minY) * 0.20;
        double maxY = box.minY + (box.maxY - box.minY) * 0.85;
        double aimX = MathHelper.clamp(eyePos.x, box.minX + 0.05, box.maxX - 0.05);
        double aimY = MathHelper.clamp(eyePos.y, minY, maxY);
        double aimZ = MathHelper.clamp(eyePos.z, box.minZ + 0.05, box.maxZ - 0.05);
        return new Vec3d(aimX, aimY, aimZ);
    }

    public static double distanceToBox(Vec3d eyePos, Box box) {
        if (eyePos == null || box == null) {
            return Double.MAX_VALUE;
        }
        double cx = MathHelper.clamp(eyePos.x, box.minX, box.maxX);
        double cy = MathHelper.clamp(eyePos.y, box.minY, box.maxY);
        double cz = MathHelper.clamp(eyePos.z, box.minZ, box.maxZ);
        double dx = eyePos.x - cx;
        double dy = eyePos.y - cy;
        double dz = eyePos.z - cz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
