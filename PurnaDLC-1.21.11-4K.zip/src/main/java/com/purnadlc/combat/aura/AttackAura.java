package com.purnadlc.combat.aura;

import com.purnadlc.combat.aura.movefix.MoveFixController;
import com.purnadlc.combat.aura.state.RotationStateManager;
import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import net.minecraft.entity.LivingEntity;

public final class AttackAura extends Module {
    private final AttackAuraSettings settings;
    private final CombatState combatState;
    private final RotationStateManager rotationStateManager;
    private final RotationController rotationController;
    private final FOVCalculator fovCalculator;
    private final TargetSelector targetSelector;
    private final TargetManager targetManager;
    private final CriticalManager criticalManager;
    private final ShieldBreaker shieldBreaker;
    private final AttackController attackController;
    private final MoveFixController moveFixController;

    public AttackAura() {
        super("AttackAura", "Modular combat engine with 4 rotation profiles, MoveFix, Only Crit, ShieldBreaker, and FOV targeting",
            Category.COMBAT, ModuleSection.ATTACK);

        this.settings = new AttackAuraSettings(this::addSetting);
        this.combatState = new CombatState();
        this.rotationStateManager = new RotationStateManager();
        this.rotationController = new RotationController(rotationStateManager);
        this.fovCalculator = new FOVCalculator();
        this.targetSelector = new TargetSelector();
        this.targetManager = new TargetManager(fovCalculator, targetSelector);
        this.criticalManager = new CriticalManager();
        this.shieldBreaker = new ShieldBreaker();
        this.attackController = new AttackController(criticalManager, shieldBreaker, targetManager);
        this.moveFixController = new MoveFixController(rotationStateManager);
    }

    @Override
    public void onEnable() { resetAllState(); }

    @Override
    public void onDisable() { resetAllState(); }

    public void resetAllState() {
        combatState.reset();
        rotationController.reset();
        targetManager.reset();
        attackController.reset(mc != null ? mc.player : null, settings);
    }

    @Override
    public void onTick() {
        if (mc == null || mc.player == null || mc.world == null) {
            resetAllState();
            return;
        }

        long worldHash = System.identityHashCode(mc.world);
        if (worldHash != combatState.getActiveWorldIdentityHash() || !mc.player.isAlive()) {
            resetAllState();
            combatState.setActiveWorldIdentityHash(worldHash);
            return;
        }

        if (mc.currentScreen != null) {
            rotationController.onTargetLost();
            shieldBreaker.restoreSlotIfNeeded(mc.player, settings);
            return;
        }

        combatState.beginTick();
        rotationStateManager.beginTick(mc.player);

        float cameraYaw = rotationStateManager.getCameraRotation().getYaw();
        float cameraPitch = rotationStateManager.getCameraRotation().getPitch();
        LivingEntity target = targetManager.acquireTarget(
            mc.world, mc.player, cameraYaw, cameraPitch, settings, combatState
        );

        if (target == null) {
            rotationController.onTargetLost();
            shieldBreaker.restoreSlotIfNeeded(mc.player, settings);
            return;
        }

        RotationProfile.RotationResult nextRot = rotationController.updateForTarget(
            mc, mc.player, target, combatState.didTargetSwitchThisTick(), settings
        );

        attackController.tryAttack(
            mc, mc.world, mc.player, target,
            nextRot.yaw(), nextRot.pitch(),
            rotationStateManager.getTickCounter(),
            settings, combatState
        );
    }

    public AttackAuraSettings getSettingsBundle() { return settings; }
    public CombatState getCombatState() { return combatState; }
    public RotationStateManager getRotationStateManager() { return rotationStateManager; }
    public RotationController getRotationController() { return rotationController; }
    public FOVCalculator getFovCalculator() { return fovCalculator; }
    public TargetManager getTargetManager() { return targetManager; }
    public CriticalManager getCriticalManager() { return criticalManager; }
    public ShieldBreaker getShieldBreaker() { return shieldBreaker; }
    public AttackController getAttackController() { return attackController; }
    public MoveFixController getMoveFixController() { return moveFixController; }
}
