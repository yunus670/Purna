package com.purnadlc.combat.aura.rotation;

import com.purnadlc.combat.aura.AttackAuraSettings;
import com.purnadlc.combat.aura.RotationMath;
import com.purnadlc.combat.aura.RotationProfile;

public final class MatrixRotationProfile implements RotationProfile {
    private float prevAppliedYawStep = 0.0f;
    private float prevAppliedPitchStep = 0.0f;
    private int handoffTicks = 0;

    @Override
    public String getName() { return "Matrix"; }

    @Override
    public RotationResult computeNext(RotationInput input, AttackAuraSettings settings) {
        if (input.targetSwitched()) onTargetChanged();

        float pitchLimit = settings.pitchLimit.getFloat();
        float currentYaw = RotationMath.normalizeYaw(input.currentYaw());
        float currentPitch = RotationMath.clampPitch(input.currentPitch(), pitchLimit);
        float yawDiff = RotationMath.yawDifference(currentYaw, input.targetYaw());
        float pitchDiff = RotationMath.pitchDifference(currentPitch, RotationMath.clampPitch(input.targetPitch(), pitchLimit));

        float handoffScale = 1.0f;
        if (handoffTicks > 0) {
            handoffScale = 0.55f + 0.15f * (3 - handoffTicks);
            handoffTicks--;
        }

        float maxGlobal = settings.maxRotationSpeed.getFloat();
        float hCap = Math.min(maxGlobal, settings.horizontalSpeed.getFloat()) * handoffScale;
        float vCap = Math.min(maxGlobal, settings.verticalSpeed.getFloat()) * handoffScale;
        float accel = Math.max(2.0f, settings.acceleration.getFloat());
        float interp = settings.interpolation.getFloat();
        float smoothing = settings.smoothness.getFloat();

        float rawYawStep = clamp(yawDiff * Math.min(1.0f, interp * (1.05f - smoothing * 0.55f)), -hCap, hCap);
        float rawPitchStep = clamp(pitchDiff * Math.min(1.0f, interp * (0.90f - smoothing * 0.50f)), -vCap, vCap);

        float consistentYaw = clampDelta(prevAppliedYawStep, rawYawStep, accel);
        float consistentPitch = clampDelta(prevAppliedPitchStep, rawPitchStep, accel * 0.80f);

        float gcd = RotationMath.computeGcdStep(input.mouseSensitivity());
        float snappedYaw = RotationMath.snapToGcd(consistentYaw, gcd);
        float snappedPitch = RotationMath.snapToGcd(consistentPitch, gcd);

        if (Math.signum(snappedYaw) != Math.signum(yawDiff) && Math.abs(yawDiff) < gcd) snappedYaw = 0.0f;
        if (Math.signum(snappedPitch) != Math.signum(pitchDiff) && Math.abs(pitchDiff) < gcd) snappedPitch = 0.0f;

        prevAppliedYawStep = snappedYaw;
        prevAppliedPitchStep = snappedPitch;

        return new RotationResult(
            RotationMath.normalizeYaw(currentYaw + snappedYaw),
            RotationMath.clampPitch(currentPitch + snappedPitch, pitchLimit)
        );
    }

    @Override
    public void onTargetChanged() {
        this.handoffTicks = 3;
        this.prevAppliedYawStep *= 0.35f;
        this.prevAppliedPitchStep *= 0.35f;
    }

    @Override
    public void reset() {
        this.prevAppliedYawStep = 0.0f;
        this.prevAppliedPitchStep = 0.0f;
        this.handoffTicks = 0;
    }

    private static float clampDelta(float prev, float desired, float maxChange) {
        float change = desired - prev;
        if (change > maxChange) return prev + maxChange;
        if (change < -maxChange) return prev - maxChange;
        return desired;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
