package com.purnadlc.combat.aura;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

public final class FOVCalculator {
    public record FovEvaluation(
        boolean inRange,
        boolean inHorizontalFov,
        boolean inVerticalFov,
        boolean inCombinedFov,
        boolean visible,
        double distance,
        float yawDifference,
        float pitchDifference,
        float combinedAngle
    ) {
        public boolean isValid(boolean requireFov, boolean requireVisibility) {
            if (!inRange) return false;
            if (requireFov && (!inHorizontalFov || !inVerticalFov || !inCombinedFov)) return false;
            return !requireVisibility || visible;
        }
    }

    public FovEvaluation evaluateAngles(float viewerYaw, float viewerPitch,
                                        float targetYaw, float targetPitch,
                                        double distance, double maxRange,
                                        double overallFovDeg, double horizontalFov, double verticalFov,
                                        boolean visible) {
        double safeDist = Double.isFinite(distance) ? Math.max(0.0, distance) : Double.MAX_VALUE;
        boolean inRange = safeDist <= Math.max(0.1, maxRange);

        float yawDiff = Math.abs(RotationMath.yawDifference(viewerYaw, targetYaw));
        float pitchDiff = Math.abs(RotationMath.pitchDifference(viewerPitch, targetPitch));
        float combined = (float) Math.hypot(yawDiff, pitchDiff);

        double halfOverall = Math.max(0.5, Math.min(180.0, overallFovDeg * 0.5));
        double halfHoriz = Math.max(0.5, Math.min(180.0, horizontalFov * 0.5));
        double halfVert = Math.max(0.5, Math.min(90.0, verticalFov * 0.5));

        boolean inCombined = overallFovDeg >= 360.0 || combined <= halfOverall;
        boolean inHoriz = horizontalFov >= 360.0 || yawDiff <= halfHoriz;
        boolean inVert = verticalFov >= 180.0 || pitchDiff <= halfVert;

        return new FovEvaluation(inRange, inHoriz, inVert, inCombined, visible, safeDist, yawDiff, pitchDiff, combined);
    }

    public FovEvaluation evaluateEntity(ClientPlayerEntity player, World world,
                                        float viewerYaw, float viewerPitch,
                                        Entity target, AttackAuraSettings settings) {
        if (player == null || target == null) {
            return new FovEvaluation(false, false, false, false, false, Double.MAX_VALUE, 180.0f, 90.0f, 180.0f);
        }
        Vec3d eyePos = player.getEyePos();
        Vec3d aimPoint = RotationMath.getOptimalAimPoint(eyePos, target);
        double distance = RotationMath.distanceToBox(eyePos, target.getBoundingBox());

        float targetYaw = RotationMath.calculateTargetYaw(eyePos, aimPoint);
        float targetPitch = RotationMath.calculateTargetPitch(eyePos, aimPoint);

        boolean visible = true;
        if (settings.visibilityCheck.isEnabled() && world != null) {
            visible = hasLineOfSight(world, player, eyePos, aimPoint);
        }

        return evaluateAngles(
            viewerYaw, viewerPitch, targetYaw, targetPitch,
            distance, settings.attackRange.getValue(),
            settings.fov.getValue(), settings.horizontalFov.getValue(), settings.verticalFov.getValue(),
            visible
        );
    }

    public boolean hasLineOfSight(World world, Entity viewer, Vec3d eyePos, Vec3d aimPoint) {
        if (world == null || viewer == null || eyePos == null || aimPoint == null) return false;
        RaycastContext context = new RaycastContext(
            eyePos, aimPoint,
            RaycastContext.ShapeType.COLLIDER,
            RaycastContext.FluidHandling.NONE,
            viewer
        );
        BlockHitResult result = world.raycast(context);
        return result == null || result.getType() == HitResult.Type.MISS;
    }
}
