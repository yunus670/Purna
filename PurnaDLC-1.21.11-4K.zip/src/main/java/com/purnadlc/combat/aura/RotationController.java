package com.purnadlc.combat.aura;

import com.purnadlc.combat.aura.rotation.FuntimeRotationProfile;
import com.purnadlc.combat.aura.rotation.MatrixRotationProfile;
import com.purnadlc.combat.aura.rotation.SmoothRotationProfile;
import com.purnadlc.combat.aura.rotation.SpookyTimeRotationProfile;
import com.purnadlc.combat.aura.state.RotationStateManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.EnumMap;
import java.util.Map;

public final class RotationController {
    private final Map<AttackAuraSettings.RotationMode, RotationProfile> profiles = new EnumMap<>(AttackAuraSettings.RotationMode.class);
    private final RotationStateManager stateManager;
    private AttackAuraSettings.RotationMode lastMode;

    public RotationController(RotationStateManager stateManager) {
        this.stateManager = stateManager;
        this.profiles.put(AttackAuraSettings.RotationMode.SMOOTH, new SmoothRotationProfile());
        this.profiles.put(AttackAuraSettings.RotationMode.FUNTIME, new FuntimeRotationProfile());
        this.profiles.put(AttackAuraSettings.RotationMode.SPOOKYTIME, new SpookyTimeRotationProfile());
        this.profiles.put(AttackAuraSettings.RotationMode.MATRIX, new MatrixRotationProfile());
        this.lastMode = AttackAuraSettings.RotationMode.SMOOTH;
    }

    public RotationProfile getProfile(AttackAuraSettings.RotationMode mode) {
        RotationProfile profile = profiles.get(mode);
        return profile != null ? profile : profiles.get(AttackAuraSettings.RotationMode.SMOOTH);
    }

    public RotationProfile.RotationResult updateForTarget(MinecraftClient mc, ClientPlayerEntity player,
                                                          LivingEntity target, boolean targetSwitched,
                                                          AttackAuraSettings settings) {
        if (player == null || target == null || !target.isAlive() || target.isRemoved()) {
            onTargetLost();
            return new RotationProfile.RotationResult(stateManager.getEffectiveYaw(), stateManager.getEffectivePitch());
        }

        AttackAuraSettings.RotationMode mode = settings.rotationMode.getValue();
        if (mode != lastMode) {
            getProfile(lastMode).reset();
            lastMode = mode;
        }

        Vec3d eyePos = player.getEyePos();
        Vec3d aimPoint = RotationMath.getOptimalAimPoint(eyePos, target);
        double distance = RotationMath.distanceToBox(eyePos, target.getBoundingBox());

        float desiredYaw = RotationMath.calculateTargetYaw(eyePos, aimPoint);
        float desiredPitch = RotationMath.calculateTargetPitch(eyePos, aimPoint);
        double sensitivity = (mc != null && mc.options != null) ? mc.options.getMouseSensitivity().getValue() : 0.5;

        RotationProfile.RotationInput input = new RotationProfile.RotationInput(
            stateManager.getEffectiveYaw(),
            stateManager.getEffectivePitch(),
            desiredYaw,
            desiredPitch,
            distance,
            targetSwitched,
            sensitivity
        );

        RotationProfile.RotationResult result = getProfile(mode).computeNext(input, settings);
        stateManager.commitCombatRotation(result.yaw(), result.pitch(), settings.isDirectCameraSync(), player);
        return result;
    }

    public RotationProfile.RotationResult computeStepForAngles(float currentYaw, float currentPitch,
                                                               float targetYaw, float targetPitch,
                                                               double targetDistance, boolean targetSwitched,
                                                               double mouseSensitivity,
                                                               AttackAuraSettings settings) {
        AttackAuraSettings.RotationMode mode = settings.rotationMode.getValue();
        if (mode != lastMode) {
            getProfile(lastMode).reset();
            lastMode = mode;
        }
        RotationProfile.RotationInput input = new RotationProfile.RotationInput(
            currentYaw, currentPitch, targetYaw, targetPitch, targetDistance, targetSwitched, mouseSensitivity
        );
        return getProfile(mode).computeNext(input, settings);
    }

    public void onTargetLost() {
        stateManager.onTargetLost();
        for (RotationProfile p : profiles.values()) p.reset();
    }

    public void reset() {
        stateManager.reset();
        for (RotationProfile p : profiles.values()) p.reset();
    }

    public RotationStateManager getStateManager() { return stateManager; }
}
