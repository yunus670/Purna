package com.purnadlc.combat.aura;

public interface RotationProfile {
    record RotationInput(
        float currentYaw,
        float currentPitch,
        float targetYaw,
        float targetPitch,
        double targetDistance,
        boolean targetSwitched,
        double mouseSensitivity
    ) {}

    record RotationResult(float yaw, float pitch) {}

    String getName();
    RotationResult computeNext(RotationInput input, AttackAuraSettings settings);
    void onTargetChanged();
    void reset();
}
