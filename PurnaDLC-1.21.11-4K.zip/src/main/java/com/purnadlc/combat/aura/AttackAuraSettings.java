package com.purnadlc.combat.aura;

import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.EnumSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;
import com.purnadlc.setting.Setting;

import java.util.function.Consumer;

public final class AttackAuraSettings {
    public enum TargetMode { SINGLE, SWITCH, MULTI }
    public enum TargetPriority { CLOSEST_DISTANCE, LOWEST_HEALTH, SMALLEST_ROTATION_DIFFERENCE, HIGHEST_PRIORITY }
    public enum RotationMode { SMOOTH, FUNTIME, SPOOKYTIME, MATRIX }
    public enum MoveFixMode { OFF, SILENT, FOCUSED }

    public final NumberSetting attackRange;
    public final EnumSetting<TargetMode> targetMode;
    public final EnumSetting<TargetPriority> targetPriority;
    public final BooleanSetting multiTarget;
    public final BooleanSetting players;
    public final BooleanSetting hostileMobs;
    public final BooleanSetting passiveMobs;
    public final BooleanSetting invisibleEntities;

    public final EnumSetting<MoveFixMode> moveFixMode;
    public final BooleanSetting strafeFix;
    public final BooleanSetting jumpFix;

    public final EnumSetting<RotationMode> rotationMode;
    public final ModeSetting rotationSync;
    public final NumberSetting horizontalSpeed;
    public final NumberSetting verticalSpeed;
    public final NumberSetting smoothness;
    public final NumberSetting acceleration;
    public final NumberSetting maxRotationSpeed;
    public final NumberSetting rotationSmoothing;
    public final NumberSetting interpolation;
    public final NumberSetting pitchLimit;

    public final BooleanSetting onlyCrit;
    public final NumberSetting criticalDelay;
    public final BooleanSetting groundCheck;
    public final BooleanSetting airborneCheck;
    public final BooleanSetting fullCooldownRequirement;

    public final BooleanSetting shieldBreaker;
    public final BooleanSetting autoAxe;
    public final BooleanSetting restorePreviousSlot;
    public final BooleanSetting shieldDetection;
    public final NumberSetting shieldBreakDelay;

    public final NumberSetting fov;
    public final NumberSetting horizontalFov;
    public final NumberSetting verticalFov;
    public final BooleanSetting fovCheck;

    public final NumberSetting attackDelay;
    public final NumberSetting attackCooldown;
    public final NumberSetting targetSwitching;
    public final BooleanSetting visibilityCheck;
    public final BooleanSetting rangeValidation;

    public AttackAuraSettings(Consumer<Setting<?>> registrar) {
        this.attackRange = reg(registrar, new NumberSetting("Attack Range", "Maximum melee attack reach in blocks", 3.1, 2.0, 6.0, 0.1));
        this.targetMode = reg(registrar, new EnumSetting<>("Target Mode", "Target engagement mode", TargetMode.SINGLE));
        this.targetPriority = reg(registrar, new EnumSetting<>("Target Priority", "Deterministic target scoring rule", TargetPriority.CLOSEST_DISTANCE));
        this.multiTarget = reg(registrar, new BooleanSetting("Multi Target", "Cycle across multiple valid targets", false));
        this.players = reg(registrar, new BooleanSetting("Players", "Target player entities", true));
        this.hostileMobs = reg(registrar, new BooleanSetting("Hostile Mobs", "Target hostile monster entities", true));
        this.passiveMobs = reg(registrar, new BooleanSetting("Passive Mobs", "Target passive animal entities", false));
        this.invisibleEntities = reg(registrar, new BooleanSetting("Invisible Entities", "Allow targeting invisible entities", false));

        this.moveFixMode = reg(registrar, new EnumSetting<>("MoveFix", "Directional movement alignment mode", MoveFixMode.SILENT));
        this.strafeFix = reg(registrar, new BooleanSetting("Strafe Fix", "Align strafe velocity vector to combat yaw", true));
        this.jumpFix = reg(registrar, new BooleanSetting("Jump Fix", "Align sprint-jump impulse to combat yaw", true));

        this.rotationMode = reg(registrar, new EnumSetting<>("Rotation Mode", "Active independent rotation profile", RotationMode.SMOOTH));
        this.rotationSync = reg(registrar, new ModeSetting("Rotation Sync", "Keep camera independent or apply directly", "Silent State", "Silent State", "Camera Direct"));
        this.horizontalSpeed = reg(registrar, new NumberSetting("Horizontal Speed", "Yaw tracking speed (deg/tick)", 28.0, 2.0, 90.0, 1.0));
        this.verticalSpeed = reg(registrar, new NumberSetting("Vertical Speed", "Pitch tracking speed (deg/tick)", 18.0, 2.0, 90.0, 1.0));
        this.smoothness = reg(registrar, new NumberSetting("Smoothness", "Damping strength for rotation profiles", 0.45, 0.05, 0.95, 0.05));
        this.acceleration = reg(registrar, new NumberSetting("Acceleration", "Angular acceleration limit (deg/tick^2)", 14.0, 1.0, 45.0, 1.0));
        this.maxRotationSpeed = reg(registrar, new NumberSetting("Max Rotation Speed", "Hard angular speed cap per tick", 42.0, 5.0, 120.0, 1.0));
        this.rotationSmoothing = reg(registrar, new NumberSetting("Rotation Smoothing", "Secondary output smoothing factor", 0.35, 0.0, 0.90, 0.05));
        this.interpolation = reg(registrar, new NumberSetting("Interpolation", "Base interpolation gain per tick", 0.50, 0.05, 1.00, 0.05));
        this.pitchLimit = reg(registrar, new NumberSetting("Pitch Limit", "Maximum absolute pitch boundary", 89.0, 30.0, 90.0, 1.0));

        this.onlyCrit = reg(registrar, new BooleanSetting("Only Crit", "Only attack when Minecraft critical-hit conditions are met", true));
        this.criticalDelay = reg(registrar, new NumberSetting("Critical Delay", "Minimum delay (ms) between critical attacks", 50.0, 0.0, 300.0, 10.0));
        this.groundCheck = reg(registrar, new BooleanSetting("Ground Check", "Require player to be off the ground for crits", true));
        this.airborneCheck = reg(registrar, new BooleanSetting("Airborne Check", "Require downward falling motion for crits", true));
        this.fullCooldownRequirement = reg(registrar, new BooleanSetting("Full Cooldown", "Require full attack cooldown (>0.90) for crits", true));

        this.shieldBreaker = reg(registrar, new BooleanSetting("Shield Breaker", "Disable blocking shields using an axe", true));
        this.autoAxe = reg(registrar, new BooleanSetting("Auto Axe", "Automatically select a hotbar axe to break shields", true));
        this.restorePreviousSlot = reg(registrar, new BooleanSetting("Restore Slot", "Restore previous hotbar slot after shield break", true));
        this.shieldDetection = reg(registrar, new BooleanSetting("Shield Detection", "Verify target is actively blocking before breaking", true));
        this.shieldBreakDelay = reg(registrar, new NumberSetting("Shield Delay", "Cooldown (ms) between shield-break actions", 180.0, 50.0, 600.0, 10.0));

        this.fov = reg(registrar, new NumberSetting("FOV", "Overall angular FOV limit (degrees)", 180.0, 1.0, 360.0, 1.0));
        this.horizontalFov = reg(registrar, new NumberSetting("Horizontal FOV", "Horizontal yaw cone limit (degrees)", 180.0, 1.0, 360.0, 1.0));
        this.verticalFov = reg(registrar, new NumberSetting("Vertical FOV", "Vertical pitch cone limit (degrees)", 120.0, 1.0, 180.0, 1.0));
        this.fovCheck = reg(registrar, new BooleanSetting("FOV Check", "Ignore targets outside configured FOV", true));

        this.attackDelay = reg(registrar, new NumberSetting("Attack Delay", "Minimum time (ms) between consecutive attacks", 60.0, 0.0, 500.0, 10.0));
        this.attackCooldown = reg(registrar, new NumberSetting("Attack Cooldown", "Minimum Minecraft attack cooldown ratio", 0.92, 0.10, 1.00, 0.02));
        this.targetSwitching = reg(registrar, new NumberSetting("Target Switch Delay", "Minimum time (ms) before switching targets", 150.0, 0.0, 1000.0, 25.0));
        this.visibilityCheck = reg(registrar, new BooleanSetting("Visibility Check", "Require unobstructed line-of-sight to target", true));
        this.rangeValidation = reg(registrar, new BooleanSetting("Range Validation", "Re-verify bounding-box reach before attacking", true));
    }

    private static <S extends Setting<?>> S reg(Consumer<Setting<?>> registrar, S setting) {
        if (registrar != null) registrar.accept(setting);
        return setting;
    }

    public boolean isDirectCameraSync() {
        return "Camera Direct".equalsIgnoreCase(rotationSync.getValue());
    }
}
