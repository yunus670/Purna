package com.purnadlc.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ModeSetting extends Setting<String> {
    private final List<String> modes;

    public ModeSetting(String name, String description, String defaultMode, String... modes) {
        super(name, description, defaultMode);
        this.modes = Collections.unmodifiableList(Arrays.asList(modes));
        this.value = validate(defaultMode);
    }

    @Override
    protected String validate(String candidate) {
        if (candidate != null) {
            for (String m : modes) {
                if (m.equalsIgnoreCase(candidate)) {
                    return m;
                }
            }
        }
        return modes.isEmpty() ? "" : modes.get(0);
    }

    public List<String> getModes() {
        return modes;
    }

    public void cycleNext() {
        if (modes.isEmpty()) return;
        int idx = modes.indexOf(value);
        setValue(modes.get((idx + 1) % modes.size()));
    }

    public void cyclePrevious() {
        if (modes.isEmpty()) return;
        int idx = modes.indexOf(value);
        setValue(modes.get((idx - 1 + modes.size()) % modes.size()));
    }

    public boolean is(String mode) {
        return value != null && value.equalsIgnoreCase(mode);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            setValue(element.getAsString());
        }
    }
}
