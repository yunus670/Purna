package com.purnadlc.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;
    private final int decimals;

    public NumberSetting(String name, String description, double defaultValue, double min, double max, double step) {
        super(name, description, defaultValue);
        this.min = Math.min(min, max);
        this.max = Math.max(min, max);
        this.step = step > 0.0 ? step : 0.1;
        this.decimals = computeDecimals(this.step);
        this.value = validate(defaultValue);
    }

    private static int computeDecimals(double step) {
        if (step >= 1.0 && Math.floor(step) == step) {
            return 0;
        }
        String text = String.format(Locale.US, "%.4f", step).replaceAll("0+$", "");
        int dot = text.indexOf('.');
        return dot < 0 ? 0 : Math.min(3, text.length() - dot - 1);
    }

    @Override
    protected Double validate(Double candidate) {
        if (candidate == null || Double.isNaN(candidate) || Double.isInfinite(candidate)) {
            return getDefaultValue();
        }
        double clamped = Math.max(min, Math.min(max, candidate));
        double snapped = Math.round((clamped - min) / step) * step + min;
        snapped = Math.max(min, Math.min(max, snapped));
        double scale = Math.pow(10, decimals);
        return Math.round(snapped * scale) / scale;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getStep() {
        return step;
    }

    public int getDecimals() {
        return decimals;
    }

    public float getFloat() {
        return value.floatValue();
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public float getNormalized() {
        if (max <= min) return 0f;
        return (float) Math.max(0.0, Math.min(1.0, (value - min) / (max - min)));
    }

    public void setNormalized(double ratio) {
        double clamped = Math.max(0.0, Math.min(1.0, ratio));
        setValue(min + clamped * (max - min));
    }

    public String getFormattedValue() {
        if (decimals == 0) {
            return Integer.toString(getInt());
        }
        return String.format(Locale.US, "%." + decimals + "f", value);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            setValue(element.getAsDouble());
        }
    }
}
