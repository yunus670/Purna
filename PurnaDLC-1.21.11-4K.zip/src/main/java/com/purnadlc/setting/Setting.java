package com.purnadlc.setting;

import com.google.gson.JsonElement;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public abstract class Setting<T> {
    private final String name;
    private final String description;
    protected T value;
    private final T defaultValue;
    private BooleanSupplier visibility = () -> true;
    private Consumer<T> onChange;

    protected Setting(String name, String description, T defaultValue) {
        this.name = name;
        this.description = description;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public T getValue() {
        return value;
    }

    public T getDefaultValue() {
        return defaultValue;
    }

    public void setValue(T newValue) {
        T validated = validate(newValue);
        if (validated != null && !validated.equals(this.value)) {
            this.value = validated;
            if (onChange != null) {
                onChange.accept(this.value);
            }
        }
    }

    public void reset() {
        setValue(defaultValue);
    }

    public Setting<T> visible(BooleanSupplier visibility) {
        this.visibility = visibility != null ? visibility : () -> true;
        return this;
    }

    public boolean isVisible() {
        return visibility.getAsBoolean();
    }

    public Setting<T> onChange(Consumer<T> onChange) {
        this.onChange = onChange;
        return this;
    }

    protected T validate(T candidate) {
        return candidate == null ? defaultValue : candidate;
    }

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement element);
}
