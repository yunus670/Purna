package com.purnadlc.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class EnumSetting<E extends Enum<E>> extends Setting<E> {
    private final E[] constants;

    public EnumSetting(String name, String description, E defaultValue) {
        super(name, description, defaultValue);
        this.constants = defaultValue.getDeclaringClass().getEnumConstants();
    }

    public E[] getConstants() {
        return constants;
    }

    public void cycleNext() {
        int idx = value.ordinal();
        setValue(constants[(idx + 1) % constants.length]);
    }

    public String getDisplayName() {
        String raw = value.name().toLowerCase().replace('_', ' ');
        if (raw.isEmpty()) return raw;
        return Character.toUpperCase(raw.charAt(0)) + raw.substring(1);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value.name());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            String target = element.getAsString();
            for (E constant : constants) {
                if (constant.name().equalsIgnoreCase(target)) {
                    setValue(constant);
                    return;
                }
            }
        }
    }
}
