package com.purnadlc.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ColorSetting extends Setting<Integer> {
    public ColorSetting(String name, String description, int defaultArgb) {
        super(name, description, defaultArgb);
    }

    public int getRed() {
        return (value >> 16) & 0xFF;
    }

    public int getGreen() {
        return (value >> 8) & 0xFF;
    }

    public int getBlue() {
        return value & 0xFF;
    }

    public int getAlpha() {
        return (value >>> 24) & 0xFF;
    }

    public void setRgb(int r, int g, int b) {
        r = clamp(r);
        g = clamp(g);
        b = clamp(b);
        setValue((getAlpha() << 24) | (r << 16) | (g << 8) | b);
    }

    public void setRgba(int r, int g, int b, int a) {
        setValue((clamp(a) << 24) | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b));
    }

    public String toHex() {
        return String.format("#%02X%02X%02X", getRed(), getGreen(), getBlue());
    }

    public boolean setFromHex(String hex) {
        if (hex == null) return false;
        String clean = hex.trim();
        if (clean.startsWith("#")) {
            clean = clean.substring(1);
        }
        if (clean.length() != 6 && clean.length() != 8) {
            return false;
        }
        try {
            long parsed = Long.parseLong(clean, 16);
            if (clean.length() == 6) {
                setValue((getAlpha() << 24) | (int) (parsed & 0xFFFFFF));
            } else {
                setValue((int) parsed);
            }
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(String.format("#%08X", value));
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            if (element.getAsJsonPrimitive().isString()) {
                setFromHex(element.getAsString());
            } else if (element.getAsJsonPrimitive().isNumber()) {
                setValue(element.getAsInt());
            }
        }
    }
}
