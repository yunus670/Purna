package com.purnadlc.config;

import com.google.gson.*;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleManager;
import com.purnadlc.setting.Setting;
import com.purnadlc.theme.PurnaTheme;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class PurnaProfileManager {
    private static final int SCHEMA_VERSION = 1;
    public static final String DEFAULT_PROFILE = "Default";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path rootDir;
    private final Path profilesDir;
    private final Path metaFile;
    private final ModuleManager moduleManager;
    private final PurnaTheme theme;

    private String activeProfile = DEFAULT_PROFILE;

    public PurnaProfileManager(ModuleManager moduleManager, PurnaTheme theme) {
        this.moduleManager = moduleManager;
        this.theme = theme;
        this.rootDir = FabricLoader.getInstance().getConfigDir().resolve("purnadlc");
        this.profilesDir = rootDir.resolve("profiles");
        this.metaFile = rootDir.resolve("client.json");
        initDirectories();
        loadMeta();
        if (!profileExists(DEFAULT_PROFILE)) {
            saveProfile(DEFAULT_PROFILE);
        }
        loadProfile(activeProfile);
    }

    private void initDirectories() {
        try {
            Files.createDirectories(profilesDir);
        } catch (IOException ignored) {
        }
    }

    public String getActiveProfile() {
        return activeProfile;
    }

    public List<String> listProfiles() {
        Set<String> names = new LinkedHashSet<>();
        names.add(DEFAULT_PROFILE);
        if (Files.isDirectory(profilesDir)) {
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(profilesDir, "*.json")) {
                List<String> extra = new ArrayList<>();
                for (Path p : stream) {
                    String fn = p.getFileName().toString();
                    if (fn.endsWith(".json")) {
                        extra.add(fn.substring(0, fn.length() - 5));
                    }
                }
                Collections.sort(extra, String.CASE_INSENSITIVE_ORDER);
                names.addAll(extra);
            } catch (IOException ignored) {
            }
        }
        return new ArrayList<>(names);
    }

    public boolean profileExists(String name) {
        String safe = sanitizeName(name);
        return !safe.isEmpty() && Files.isRegularFile(profilesDir.resolve(safe + ".json"));
    }

    public boolean saveCurrentProfile() {
        return saveProfile(activeProfile);
    }

    public boolean saveProfile(String name) {
        String safe = sanitizeName(name);
        if (safe.isEmpty()) return false;

        JsonObject root = new JsonObject();
        root.addProperty("schemaVersion", SCHEMA_VERSION);
        root.addProperty("profile", safe);

        JsonObject themeObj = new JsonObject();
        themeObj.addProperty("preset", theme.getActivePreset());
        themeObj.addProperty("primaryAccent", String.format("#%08X", theme.getPrimaryAccent()));
        themeObj.addProperty("secondaryAccent", String.format("#%08X", theme.getSecondaryAccent()));
        themeObj.addProperty("enabledToggle", String.format("#%08X", theme.getEnabledToggle()));
        themeObj.addProperty("overlayOpacity", theme.getOverlayOpacity());
        root.add("theme", themeObj);

        JsonObject modulesObj = new JsonObject();
        for (Module m : moduleManager.getAllModules()) {
            JsonObject mObj = new JsonObject();
            mObj.addProperty("enabled", m.isEnabled());
            mObj.addProperty("keybind", m.getKeybind().getKeyCode());

            JsonObject settingsObj = new JsonObject();
            for (Setting<?> s : m.getSettings()) {
                settingsObj.add(s.getName(), s.toJson());
            }
            mObj.add("settings", settingsObj);
            modulesObj.add(m.getName(), mObj);
        }
        root.add("modules", modulesObj);

        Path target = profilesDir.resolve(safe + ".json");
        Path temp = profilesDir.resolve(safe + ".json.tmp");
        String serialized = GSON.toJson(root);
        try {
            Files.createDirectories(profilesDir);
            Files.writeString(temp, serialized, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException | UnsupportedOperationException | IOException moveErr) {
                // Android FUSE / Scoped Storage often rejects ATOMIC_MOVE; perform standard replace cleanly
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
            this.activeProfile = safe;
            saveMeta();
            return true;
        } catch (IOException e) {
            try { Files.deleteIfExists(temp); } catch (IOException ignored) {}
            try {
                Files.writeString(target, serialized, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                this.activeProfile = safe;
                saveMeta();
                return true;
            } catch (IOException ignored) {
                return false;
            }
        }
    }

    public boolean createProfile(String name) {
        String safe = sanitizeName(name);
        if (safe.isEmpty() || profileExists(safe)) {
            return false;
        }
        return saveProfile(safe);
    }

    public boolean loadProfile(String name) {
        String safe = sanitizeName(name);
        if (safe.isEmpty()) return false;
        Path target = profilesDir.resolve(safe + ".json");
        if (!Files.isRegularFile(target)) {
            return false;
        }

        try {
            String content = Files.readString(target, StandardCharsets.UTF_8);
            JsonElement parsed = JsonParser.parseString(content);
            if (!parsed.isJsonObject()) return false;

            JsonObject root = parsed.getAsJsonObject();

            if (root.has("theme") && root.get("theme").isJsonObject()) {
                JsonObject themeObj = root.getAsJsonObject("theme");
                if (themeObj.has("preset")) {
                    String preset = themeObj.get("preset").getAsString();
                    if (theme.getPresets().containsKey(preset)) {
                        theme.applyPreset(preset);
                    }
                }
                if (themeObj.has("primaryAccent")) {
                    parseHex(themeObj.get("primaryAccent").getAsString()).ifPresent(theme::setPrimaryAccent);
                }
                if (themeObj.has("secondaryAccent")) {
                    parseHex(themeObj.get("secondaryAccent").getAsString()).ifPresent(theme::setSecondaryAccent);
                }
                if (themeObj.has("enabledToggle")) {
                    parseHex(themeObj.get("enabledToggle").getAsString()).ifPresent(theme::setEnabledToggle);
                }
                if (themeObj.has("overlayOpacity")) {
                    theme.setOverlayOpacity(themeObj.get("overlayOpacity").getAsFloat());
                }
            }

            if (root.has("modules") && root.get("modules").isJsonObject()) {
                JsonObject modulesObj = root.getAsJsonObject("modules");
                for (Module m : moduleManager.getAllModules()) {
                    if (!modulesObj.has(m.getName())) continue;
                    JsonElement me = modulesObj.get(m.getName());
                    if (!me.isJsonObject()) continue;
                    JsonObject mObj = me.getAsJsonObject();

                    if (mObj.has("enabled") && mObj.get("enabled").isJsonPrimitive()) {
                        m.setEnabled(mObj.get("enabled").getAsBoolean());
                    }
                    if (mObj.has("keybind") && mObj.get("keybind").isJsonPrimitive()) {
                        m.getKeybind().setValue(mObj.get("keybind").getAsInt());
                    }
                    if (mObj.has("settings") && mObj.get("settings").isJsonObject()) {
                        JsonObject sObj = mObj.getAsJsonObject("settings");
                        for (Setting<?> s : m.getSettings()) {
                            if (sObj.has(s.getName())) {
                                s.fromJson(sObj.get(s.getName()));
                            }
                        }
                    }
                }
            }

            this.activeProfile = safe;
            saveMeta();
            return true;
        } catch (Exception ignored) {
            // Malformed profile: do not corrupt existing state
            return false;
        }
    }

    public boolean renameProfile(String oldName, String newName) {
        String safeOld = sanitizeName(oldName);
        String safeNew = sanitizeName(newName);
        if (safeOld.isEmpty() || safeNew.isEmpty() || DEFAULT_PROFILE.equalsIgnoreCase(safeOld)) {
            return false;
        }
        if (safeOld.equalsIgnoreCase(safeNew) || profileExists(safeNew)) {
            return false;
        }
        Path src = profilesDir.resolve(safeOld + ".json");
        Path dst = profilesDir.resolve(safeNew + ".json");
        if (!Files.isRegularFile(src)) return false;
        try {
            Files.move(src, dst, StandardCopyOption.REPLACE_EXISTING);
            if (activeProfile.equalsIgnoreCase(safeOld)) {
                activeProfile = safeNew;
                saveMeta();
            }
            return true;
        } catch (IOException ignored) {
            return false;
        }
    }

    public boolean deleteProfile(String name) {
        String safe = sanitizeName(name);
        if (safe.isEmpty() || DEFAULT_PROFILE.equalsIgnoreCase(safe)) {
            return false;
        }
        Path target = profilesDir.resolve(safe + ".json");
        try {
            boolean deleted = Files.deleteIfExists(target);
            if (deleted && activeProfile.equalsIgnoreCase(safe)) {
                activeProfile = DEFAULT_PROFILE;
                loadProfile(DEFAULT_PROFILE);
            }
            return deleted;
        } catch (IOException ignored) {
            return false;
        }
    }

    private void loadMeta() {
        if (!Files.isRegularFile(metaFile)) return;
        try {
            JsonElement parsed = JsonParser.parseString(Files.readString(metaFile, StandardCharsets.UTF_8));
            if (parsed.isJsonObject()) {
                JsonObject obj = parsed.getAsJsonObject();
                if (obj.has("activeProfile")) {
                    String candidate = sanitizeName(obj.get("activeProfile").getAsString());
                    if (!candidate.isEmpty() && profileExists(candidate)) {
                        activeProfile = candidate;
                    }
                }
            }
        } catch (Exception ignored) {
            activeProfile = DEFAULT_PROFILE;
        }
    }

    private void saveMeta() {
        JsonObject obj = new JsonObject();
        obj.addProperty("schemaVersion", SCHEMA_VERSION);
        obj.addProperty("activeProfile", activeProfile);
        try {
            Files.createDirectories(rootDir);
            Files.writeString(metaFile, GSON.toJson(obj), StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException ignored) {
        }
    }

    public static String sanitizeName(String raw) {
        if (raw == null) return "";
        String cleaned = raw.trim().replaceAll("[^a-zA-Z0-9_\- ]", "");
        if (cleaned.length() > 24) {
            cleaned = cleaned.substring(0, 24).trim();
        }
        return cleaned;
    }

    private static Optional<Integer> parseHex(String hex) {
        if (hex == null) return Optional.empty();
        String s = hex.trim();
        if (s.startsWith("#")) s = s.substring(1);
        try {
            if (s.length() == 6) {
                return Optional.of(0xFF000000 | Integer.parseInt(s, 16));
            } else if (s.length() == 8) {
                return Optional.of((int) Long.parseLong(s, 16));
            }
        } catch (NumberFormatException ignored) {
        }
        return Optional.empty();
    }
}
