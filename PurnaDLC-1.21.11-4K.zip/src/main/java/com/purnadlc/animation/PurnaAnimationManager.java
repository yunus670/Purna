package com.purnadlc.animation;

import java.util.HashMap;
import java.util.Map;

public final class PurnaAnimationManager {
    private static final float GUI_OPEN_DURATION_SEC = 0.18f;

    private float guiProgress = 0f;
    private boolean guiClosing = false;
    private float categoryFade = 1f;
    private float settingsProgress = 0f;
    private boolean settingsOpen = false;

    private final Map<String, AnimatedValue> toggleAnimations = new HashMap<>(64);
    private final Map<String, AnimatedValue> hoverAnimations = new HashMap<>(64);
    private final Map<String, AnimatedValue> sidebarAnimations = new HashMap<>(16);

    private long lastFrameNanos = 0L;
    private float lastDeltaSeconds = 0.016f;

    public void beginFrame() {
        long now = System.nanoTime();
        if (lastFrameNanos == 0L) {
            lastDeltaSeconds = 0.016f;
        } else {
            lastDeltaSeconds = Math.max(0.001f, Math.min(0.08f, (now - lastFrameNanos) / 1_000_000_000.0f));
        }
        lastFrameNanos = now;

        float step = lastDeltaSeconds / GUI_OPEN_DURATION_SEC;
        if (guiClosing) {
            guiProgress = Math.max(0f, guiProgress - step * 1.15f);
        } else {
            guiProgress = Math.min(1f, guiProgress + step);
        }

        if (categoryFade < 1f) {
            categoryFade = Math.min(1f, categoryFade + lastDeltaSeconds * 6.5f);
        }

        float settingsStep = lastDeltaSeconds / 0.16f;
        if (settingsOpen) {
            settingsProgress = Math.min(1f, settingsProgress + settingsStep);
        } else {
            settingsProgress = Math.max(0f, settingsProgress - settingsStep * 1.2f);
        }
    }

    public float getDeltaSeconds() {
        return lastDeltaSeconds;
    }

    public void onGuiOpened() {
        lastFrameNanos = System.nanoTime();
        guiClosing = false;
        guiProgress = 0.02f;
        categoryFade = 1f;
    }

    public void requestGuiClose() {
        guiClosing = true;
    }

    public boolean isGuiClosing() {
        return guiClosing;
    }

    public boolean isCloseFinished() {
        return guiClosing && guiProgress <= 0.005f;
    }

    public float getGuiAlpha() {
        return Easing.easeOutCubic(guiProgress);
    }

    public float getGuiScale() {
        return 0.94f + 0.06f * Easing.easeOutCubic(guiProgress);
    }

    public void triggerCategoryTransition() {
        categoryFade = 0.15f;
    }

    public float getCategoryAlpha() {
        return Easing.easeOutCubic(categoryFade);
    }

    public void setSettingsOpen(boolean open) {
        this.settingsOpen = open;
    }

    public float getSettingsAlpha() {
        return Easing.easeOutCubic(settingsProgress);
    }

    public float getSettingsScale() {
        return 0.95f + 0.05f * Easing.easeOutCubic(settingsProgress);
    }

    public boolean isSettingsVisible() {
        return settingsOpen || settingsProgress > 0.01f;
    }

    public float updateToggle(String key, boolean enabled) {
        AnimatedValue anim = toggleAnimations.get(key);
        if (anim == null) {
            anim = new AnimatedValue(enabled ? 1f : 0f, 14f);
            toggleAnimations.put(key, anim);
        }
        anim.setTarget(enabled ? 1f : 0f);
        return anim.update(lastDeltaSeconds);
    }

    public float updateHover(String key, boolean hovered) {
        AnimatedValue anim = hoverAnimations.get(key);
        if (anim == null) {
            anim = new AnimatedValue(hovered ? 1f : 0f, 16f);
            hoverAnimations.put(key, anim);
        }
        anim.setTarget(hovered ? 1f : 0f);
        return anim.update(lastDeltaSeconds);
    }

    public float updateSidebar(String key, boolean active) {
        AnimatedValue anim = sidebarAnimations.get(key);
        if (anim == null) {
            anim = new AnimatedValue(active ? 1f : 0f, 15f);
            sidebarAnimations.put(key, anim);
        }
        anim.setTarget(active ? 1f : 0f);
        return anim.update(lastDeltaSeconds);
    }
}
