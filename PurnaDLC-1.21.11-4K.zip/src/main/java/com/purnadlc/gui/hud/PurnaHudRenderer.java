package com.purnadlc.gui.hud;

import com.purnadlc.PurnaDLC;
import com.purnadlc.gui.ClickGuiVideoBackground;
import com.purnadlc.gui.GuiTextureBlitter;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.gui.photo.PhotoManager;
import com.purnadlc.module.Module;
import com.purnadlc.module.impl.misc.NameProtectModule;
import com.purnadlc.module.impl.visual.HudModule;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class PurnaHudRenderer {
    private static final DateTimeFormatter CLOCK_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private double lastX = 0.0;
    private double lastZ = 0.0;
    private double smoothedBps = 0.0;

    public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        double dx = mc.player.getX() - lastX;
        double dz = mc.player.getZ() - lastZ;
        double instantBps = Math.sqrt(dx * dx + dz * dz) * 20.0;
        if (instantBps > 200.0) instantBps = 0.0;
        smoothedBps = smoothedBps * 0.75 + instantBps * 0.25;
        lastX = mc.player.getX();
        lastZ = mc.player.getZ();
    }

    public void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PurnaDLC client = PurnaDLC.getInstance();
        if (mc == null || client == null || mc.player == null || mc.options.hudHidden) return;

        HudModule hud = client.getModuleManager().getModule(HudModule.class);
        if (hud == null || !hud.isEnabled()) return;

        TextRenderer tr = mc.textRenderer;
        PurnaTheme theme = client.getTheme();
        float alpha = hud.hudOpacity.getFloat();
        boolean hiRes = hud.crisp4k.isEnabled();
        int bgColor = PurnaTheme.withAlpha(theme.getMainBackground(), alpha);
        int borderColor = PurnaTheme.withAlpha(hiRes ? theme.getPrimaryAccent() : theme.getBorderColor(), Math.min(1f, alpha * (hiRes ? 0.55f : 1.0f)));
        int accent = hud.accentColor.getValue();

        int topY = 8;
        if (hud.watermark.isEnabled()) {
            String realName = mc.getSession() != null ? mc.getSession().getUsername() : "Player";
            NameProtectModule np = client.getModuleManager().getModule(NameProtectModule.class);
            String user = np != null ? np.getDisplayUsername(realName) : realName;

            StringBuilder sb = new StringBuilder(user);
            if (hud.infoItems.isSelected("FPS")) sb.append("  |  ").append(mc.getCurrentFps()).append(" FPS");
            if (hud.infoItems.isSelected("Ping")) {
                int ping = 0;
                if (mc.getNetworkHandler() != null) {
                    PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                    if (entry != null) ping = entry.getLatency();
                }
                sb.append("  |  ").append(ping).append(" ms");
            }
            if (hud.infoItems.isSelected("Time")) sb.append("  |  ").append(LocalTime.now().format(CLOCK_FMT));
            if (hud.infoItems.isSelected("TPS")) sb.append("  |  20 TPS");

            String text = sb.toString();
            int pillW = 30 + tr.getWidth(text) + 12;
            int pillH = 22;
            if (hiRes) PurnaGuiRenderer.drawDropShadow(ctx, 8, topY, pillW, pillH, 7, alpha * 0.65f);
            PurnaGuiRenderer.drawRoundedRect(ctx, 8, topY, pillW, pillH, 7, bgColor);
            PurnaGuiRenderer.drawRoundedBorder(ctx, 8, topY, pillW, pillH, 7, borderColor);
            if (!hiRes || !ClickGuiVideoBackground.draw4kLogo(ctx, 13, topY + 3, 15, 1f)) {
                PurnaGuiRenderer.drawPurnaLogo(ctx, 13, topY + 5, 12, theme, 1f);
            }
            ctx.drawText(tr, text, 31, topY + 7, theme.getPrimaryText(), false);
            topY += pillH + 5;
        }

        if (hud.coordinates.isEnabled()) {
            int px = (int) Math.floor(mc.player.getX());
            int py = (int) Math.floor(mc.player.getY());
            int pz = (int) Math.floor(mc.player.getZ());
            String coordStr = String.format(Locale.US, "%d  %d  %d   |   %.1f b/s", px, py, pz, smoothedBps);
            int pillW = tr.getWidth(coordStr) + 18;
            int pillH = 19;
            PurnaGuiRenderer.drawRoundedRect(ctx, 8, topY, pillW, pillH, 6, bgColor);
            PurnaGuiRenderer.drawRoundedBorder(ctx, 8, topY, pillW, pillH, 6, borderColor);
            ctx.drawText(tr, coordStr, 17, topY + 5, theme.getSecondaryText(), false);
        }

        if (hud.arrayList.isEnabled()) {
            List<Module> enabled = client.getModuleManager().getEnabledModules();
            enabled.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.getName())).reversed());
            int screenW = mc.getWindow().getScaledWidth();
            int ay = 8;
            for (Module mod : enabled) {
                String label = mod.getName();
                int tw = tr.getWidth(label);
                int boxW = tw + 15;
                int boxX = screenW - boxW - 8;
                PurnaGuiRenderer.drawRoundedRect(ctx, boxX, ay, boxW, 16, 4, bgColor);
                ctx.fill(boxX + boxW - 2, ay + 2, boxX + boxW, ay + 14, accent);
                ctx.drawText(tr, label, boxX + 5, ay + 4, theme.getPrimaryText(), false);
                ay += 18;
            }
        }

        // HUD Photos widget (live on HUD whenever not rendered by PhotoGalleryScreen / ClickGUI drag overlay)
        if (hud.photos.isEnabled() && mc.currentScreen == null) {
            renderPhotoWidget(ctx, hud, false, -1, -1);
        }
    }

    public void renderPhotoWidget(DrawContext ctx, HudModule hud, boolean editOverlay, int mouseX, int mouseY) {
        if (hud == null || !hud.photos.isEnabled()) return;
        PurnaDLC client = PurnaDLC.getInstance();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (client == null || mc == null || mc.getWindow() == null) return;

        PhotoManager pm = client.getPhotoManager();
        String savedPath = hud.photoPath.getValue();
        if (!pm.hasPhoto() && savedPath != null && !savedPath.isBlank()) {
            pm.loadPhoto(savedPath);
        }

        int screenW = mc.getWindow().getScaledWidth();
        int screenH = mc.getWindow().getScaledHeight();
        int pw = Math.max(36, Math.min(screenW - 8, hud.photoWidth.getInt()));
        int ph = Math.max(36, Math.min(screenH - 8, hud.photoHeight.getInt()));
        int px = Math.max(0, Math.min(screenW - pw, hud.photoX.getInt()));
        int py = Math.max(0, Math.min(screenH - ph, hud.photoY.getInt()));
        float op = hud.photoOpacity.getFloat();
        PurnaTheme theme = client.getTheme();

        PurnaGuiRenderer.drawDropShadow(ctx, px, py, pw, ph, 7, op * 0.7f);
        if (pm.hasPhoto()) {
            int tint = (Math.round(255f * op) << 24) | 0x00FFFFFF;
            GuiTextureBlitter.drawCoverTexture(
                ctx, pm.getActiveTextureId(), px, py, pw, ph,
                pm.getTextureWidth(), pm.getTextureHeight(), tint
            );
        } else if (editOverlay || hud.photos.isEnabled()) {
            PurnaGuiRenderer.drawRoundedRect(ctx, px, py, pw, ph, 7, PurnaTheme.withAlpha(theme.getMainBackground(), 0.78f));
            TextRenderer tr = mc.textRenderer;
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, "HUD Photo", px + 8, py + ph / 2 - 9, pw - 14, theme.getPrimaryText());
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, "Tap Photos", px + 8, py + ph / 2 + 2, pw - 14, theme.getSecondaryText());
        }

        if (hud.photoRounded.isEnabled() || editOverlay) {
            boolean hovered = editOverlay && PurnaGuiRenderer.isHovered(mouseX, mouseY, px, py, pw, ph);
            int border = hovered ? 0xFFFFFFFF : theme.getPrimaryAccent();
            PurnaGuiRenderer.drawRoundedBorder(ctx, px, py, pw, ph, 6, PurnaTheme.withAlpha(border, Math.min(1f, op + 0.1f)));
        }
    }
}
