package com.purnadlc.gui.photo;

import com.purnadlc.gui.GuiTextureBlitter;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.file.*;
import java.util.*;

public final class PhotoManager {
    private static final int MAX_SCAN_FILES = 160;
    private static final int MAX_TEXTURE_DIM = 2048;

    private Identifier activeTextureId = null;
    private NativeImageBackedTexture activeTexture = null;
    private int textureWidth = 0;
    private int textureHeight = 0;
    private String loadedPath = "";
    private String lastError = "";
    private int generationCounter = 0;

    public record GalleryFolder(String label, Path path) {}

    public Path getModPhotosDir() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("purnadlc").resolve("photos");
        try { Files.createDirectories(dir); } catch (IOException ignored) {}
        return dir;
    }

    public List<GalleryFolder> getAvailableFolders() {
        List<GalleryFolder> folders = new ArrayList<>();
        addIfExists(folders, "Camera", Path.of("/storage/emulated/0/DCIM/Camera"));
        addIfExists(folders, "Screenshots", Path.of("/storage/emulated/0/Pictures/Screenshots"));
        addIfExists(folders, "DCIM Shots", Path.of("/storage/emulated/0/DCIM/Screenshots"));
        addIfExists(folders, "Pictures", Path.of("/storage/emulated/0/Pictures"));
        addIfExists(folders, "Downloads", Path.of("/storage/emulated/0/Download"));
        addIfExists(folders, "WhatsApp", Path.of("/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images"));

        String home = System.getProperty("user.home", "");
        if (!home.isBlank()) {
            addIfExists(folders, "Pictures", Path.of(home, "Pictures"));
            addIfExists(folders, "Downloads", Path.of(home, "Downloads"));
            addIfExists(folders, "Desktop", Path.of(home, "Desktop"));
        }
        folders.add(new GalleryFolder("Mod Photos", getModPhotosDir()));
        return folders;
    }

    private void addIfExists(List<GalleryFolder> list, String label, Path path) {
        try {
            if (path != null && Files.isDirectory(path)) {
                for (GalleryFolder existing : list) {
                    if (existing.path().equals(path)) return;
                }
                list.add(new GalleryFolder(label, path));
            }
        } catch (Throwable ignored) {}
    }

    public List<Path> scanImagesInFolder(Path folder) {
        List<Path> results = new ArrayList<>();
        if (folder == null || !Files.isDirectory(folder)) return results;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder)) {
            for (Path p : stream) {
                if (results.size() >= MAX_SCAN_FILES) break;
                try {
                    if (Files.isRegularFile(p) && isSupportedImage(p.getFileName().toString())) {
                        results.add(p);
                    }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        results.sort((a, b) -> {
            try {
                return Long.compare(Files.getLastModifiedTime(b).toMillis(), Files.getLastModifiedTime(a).toMillis());
            } catch (Throwable ignored) {
                return a.getFileName().toString().compareToIgnoreCase(b.getFileName().toString());
            }
        });
        return results;
    }

    public static boolean isSupportedImage(String fileName) {
        if (fileName == null) return false;
        String low = fileName.toLowerCase(Locale.ROOT);
        return low.endsWith(".png") || low.endsWith(".jpg") || low.endsWith(".jpeg")
            || low.endsWith(".bmp") || low.endsWith(".tga");
    }

    public Path openDesktopSystemPicker() {
        try {
            Class<?> tfd = Class.forName("org.lwjgl.util.tinyfd.TinyFileDialogs");
            Method m = tfd.getMethod("tinyfd_openFileDialog",
                CharSequence.class, CharSequence.class, org.lwjgl.PointerBuffer.class, CharSequence.class, boolean.class);
            Object res = m.invoke(null, "Select HUD Photo", getModPhotosDir().toString(), null, "Images (*.png, *.jpg, *.jpeg)", false);
            if (res instanceof String s && !s.isBlank()) {
                Path p = Path.of(s.trim());
                if (Files.isRegularFile(p)) return p;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public boolean loadPhoto(String pathStr) {
        if (pathStr == null || pathStr.isBlank()) {
            clearPhoto();
            return false;
        }
        if (pathStr.equals(loadedPath) && activeTextureId != null) return true;
        Path path = Path.of(pathStr);
        if (!Files.isRegularFile(path)) {
            lastError = "File not found";
            return false;
        }
        try {
            byte[] bytes = Files.readAllBytes(path);
            NativeImage image = decodeImageBytes(bytes);
            if (image == null) {
                lastError = "Unsupported image format";
                return false;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.getTextureManager() == null) {
                image.close();
                return false;
            }
            clearTextureOnly();
            generationCounter++;
            Identifier newId = Identifier.of("purnadlc", "hud_photo_" + generationCounter);
            NativeImageBackedTexture tex = GuiTextureBlitter.createTexture("purnadlc_hud_photo", image);
            if (tex == null) {
                image.close();
                lastError = "Texture upload failed";
                return false;
            }
            mc.getTextureManager().registerTexture(newId, tex);
            this.activeTextureId = newId;
            this.activeTexture = tex;
            this.textureWidth = image.getWidth();
            this.textureHeight = image.getHeight();
            this.loadedPath = pathStr;
            this.lastError = "";
            return true;
        } catch (Throwable t) {
            lastError = t.getClass().getSimpleName();
            return false;
        }
    }

    private NativeImage decodeImageBytes(byte[] bytes) {
        if (bytes == null || bytes.length < 8) return null;
        if ((bytes[0] & 0xFF) == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47) {
            try { return NativeImage.read(new ByteArrayInputStream(bytes)); } catch (Throwable ignored) {}
        }
        ByteBuffer inputBuf = null;
        ByteBuffer decoded = null;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            inputBuf = MemoryUtil.memAlloc(bytes.length);
            inputBuf.put(bytes).flip();

            IntBuffer wBuf = stack.mallocInt(1);
            IntBuffer hBuf = stack.mallocInt(1);
            IntBuffer compBuf = stack.mallocInt(1);

            decoded = STBImage.stbi_load_from_memory(inputBuf, wBuf, hBuf, compBuf, 4);
            if (decoded == null) return null;
            int w = wBuf.get(0);
            int h = hBuf.get(0);
            if (w <= 0 || h <= 0) return null;

            int step = 1;
            while ((w / step) > MAX_TEXTURE_DIM || (h / step) > MAX_TEXTURE_DIM) step++;
            int outW = Math.max(1, w / step);
            int outH = Math.max(1, h / step);

            NativeImage img = new NativeImage(outW, outH, false);
            for (int oy = 0; oy < outH; oy++) {
                int sy = Math.min(h - 1, oy * step);
                for (int ox = 0; ox < outW; ox++) {
                    int sx = Math.min(w - 1, ox * step);
                    int idx = (sy * w + sx) * 4;
                    GuiTextureBlitter.setPixelRgba(
                        img, ox, oy,
                        decoded.get(idx) & 0xFF,
                        decoded.get(idx + 1) & 0xFF,
                        decoded.get(idx + 2) & 0xFF,
                        decoded.get(idx + 3) & 0xFF
                    );
                }
            }
            return img;
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (decoded != null) STBImage.stbi_image_free(decoded);
            if (inputBuf != null) MemoryUtil.memFree(inputBuf);
        }
    }

    public void clearPhoto() {
        clearTextureOnly();
        loadedPath = "";
        lastError = "";
    }

    private void clearTextureOnly() {
        if (activeTexture != null) {
            try { activeTexture.close(); } catch (Throwable ignored) {}
            activeTexture = null;
        }
        activeTextureId = null;
        textureWidth = 0;
        textureHeight = 0;
    }

    public Identifier getActiveTextureId() { return activeTextureId; }
    public int getTextureWidth() { return textureWidth; }
    public int getTextureHeight() { return textureHeight; }
    public String getLoadedPath() { return loadedPath; }
    public String getLastError() { return lastError; }
    public boolean hasPhoto() { return activeTextureId != null && textureWidth > 0 && textureHeight > 0; }
}
