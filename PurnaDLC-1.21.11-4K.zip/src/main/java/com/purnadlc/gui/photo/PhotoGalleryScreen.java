package com.purnadlc.gui.photo;

import com.purnadlc.PurnaDLC;
import com.purnadlc.gui.ClickGuiVideoBackground;
import com.purnadlc.gui.GuiTextureBlitter;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.gui.ScrollController;
import com.purnadlc.module.impl.visual.HudModule;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class PhotoGalleryScreen extends Screen {
    private final PurnaDLC purna;
    private final Screen parent;
    private final ScrollController fileScroll = new ScrollController();

    private List<PhotoManager.GalleryFolder> folders = new ArrayList<>();
    private int selectedFolderIdx = 0;
    private List<Path> currentFiles = new ArrayList<>();
    private boolean moveMode = false;
    private boolean draggingPhoto = false;
    private double dragOffsetX = 0.0;
    private double dragOffsetY = 0.0;

    private int winX, winY, winW, winH;
    private int listX, listY, listW, listH;
    private record RectBtn(int x, int y, int w, int h, int index) {}
    private final List<RectBtn> folderBtns = new ArrayList<>();
    private final List<RectBtn> fileRows = new ArrayList<>();
    private int moveToggleX, moveToggleY, moveToggleW, moveToggleH;
    private int sysPickerX, sysPickerY, sysPickerW, sysPickerH;
    private int clearBtnX, clearBtnY, clearBtnW, clearBtnH;
    private int closeBtnX, closeBtnY, closeBtnW, closeBtnH;
    private String statusMsg = "";

    public PhotoGalleryScreen(PurnaDLC purna, Screen parent) {
        super(Text.literal("PurnaDLC HUD Photos"));
        this.purna = purna;
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();
        refreshFolders();
    }

    private void refreshFolders() {
        folders = purna.getPhotoManager().getAvailableFolders();
        if (selectedFolderIdx >= folders.size()) selectedFolderIdx = 0;
        refreshFiles();
    }

    private void refreshFiles() {
        fileScroll.reset();
        if (folders.isEmpty()) {
            currentFiles = new ArrayList<>();
            return;
        }
        currentFiles = purna.getPhotoManager().scanImagesInFolder(folders.get(selectedFolderIdx).path());
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {}

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float deltaTicks) {
        PurnaTheme theme = purna.getTheme();
        HudModule hud = purna.getModuleManager().getModule(HudModule.class);
        PhotoManager pm = purna.getPhotoManager();

        if (hud != null) {
            hud.photos.setValue(true);
            purna.getHudRenderer().renderPhotoWidget(ctx, hud, true, mouseX, mouseY);
        }

        if (moveMode) {
            int barW = 290, barH = 30;
            int barX = (this.width - barW) / 2;
            int barY = 10;
            PurnaGuiRenderer.drawRoundedRect(ctx, barX, barY, barW, barH, 8, PurnaTheme.withAlpha(theme.getMainBackground(), 0.92f));
            PurnaGuiRenderer.drawRoundedBorder(ctx, barX, barY, barW, barH, 8, theme.getPrimaryAccent());
            PurnaGuiRenderer.drawTrimmedText(ctx, this.textRenderer, "Drag photo anywhere on screen",
                barX + 12, barY + 11, 190, theme.getPrimaryText());

            moveToggleW = 72; moveToggleH = 22;
            moveToggleX = barX + barW - moveToggleW - 5;
            moveToggleY = barY + 4;
            PurnaGuiRenderer.drawRoundedRect(ctx, moveToggleX, moveToggleY, moveToggleW, moveToggleH, 5, theme.getPrimaryAccent());
            int dw = this.textRenderer.getWidth("Gallery");
            ctx.drawText(this.textRenderer, "Gallery", moveToggleX + (moveToggleW - dw) / 2, moveToggleY + 7, 0xFFFFFFFF, false);
            return;
        }

        ctx.fill(0, 0, this.width, this.height, PurnaTheme.overrideAlpha(0x000000, 120));

        winW = Math.min(540, Math.max(260, this.width - 28));
        winH = Math.min(370, Math.max(220, this.height - 28));
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        PurnaGuiRenderer.drawDropShadow(ctx, winX, winY, winW, winH, 12, 1f);
        PurnaGuiRenderer.drawRoundedRect(ctx, winX, winY, winW, winH, 12, theme.getMainBackground());
        ClickGuiVideoBackground.render(ctx, winX + 1, winY + 1, winW - 2, winH - 2, 0.95f, 0.55f);
        PurnaGuiRenderer.drawRoundedBorder(ctx, winX, winY, winW, winH, 12, theme.getBorderColor());

        ctx.drawText(this.textRenderer, "HUD Photos — Gallery", winX + 14, winY + 13, theme.getPrimaryText(), false);

        closeBtnW = 24; closeBtnH = 22;
        closeBtnX = winX + winW - closeBtnW - 10;
        closeBtnY = winY + 9;
        PurnaGuiRenderer.drawRoundedRect(ctx, closeBtnX, closeBtnY, closeBtnW, closeBtnH, 5, PurnaTheme.withAlpha(theme.getCardBackground(), 0.85f));
        ctx.drawText(this.textRenderer, "x", closeBtnX + 9, closeBtnY + 7, theme.getPrimaryText(), false);

        moveToggleW = 80; moveToggleH = 22;
        moveToggleX = closeBtnX - moveToggleW - 6;
        moveToggleY = winY + 9;
        PurnaGuiRenderer.drawRoundedRect(ctx, moveToggleX, moveToggleY, moveToggleW, moveToggleH, 5, theme.getPrimaryAccent());
        int mw = this.textRenderer.getWidth("Move Photo");
        ctx.drawText(this.textRenderer, "Move Photo", moveToggleX + (moveToggleW - mw) / 2, moveToggleY + 7, 0xFFFFFFFF, false);

        clearBtnW = 50; clearBtnH = 22;
        clearBtnX = moveToggleX - clearBtnW - 6;
        clearBtnY = winY + 9;
        PurnaGuiRenderer.drawRoundedRect(ctx, clearBtnX, clearBtnY, clearBtnW, clearBtnH, 5, PurnaTheme.withAlpha(theme.getCardBackground(), 0.85f));
        int cw = this.textRenderer.getWidth("Clear");
        ctx.drawText(this.textRenderer, "Clear", clearBtnX + (clearBtnW - cw) / 2, clearBtnY + 7, theme.getSecondaryText(), false);

        folderBtns.clear();
        int fx = winX + 12, fy = winY + 40;
        for (int i = 0; i < folders.size(); i++) {
            String lbl = folders.get(i).label();
            int fw = this.textRenderer.getWidth(lbl) + 14;
            if (fx + fw > winX + winW - 95) break;
            boolean sel = (i == selectedFolderIdx);
            PurnaGuiRenderer.drawRoundedRect(ctx, fx, fy, fw, 20, 5,
                PurnaTheme.withAlpha(sel ? theme.getSelectedCategory() : theme.getCardBackground(), 0.88f));
            PurnaGuiRenderer.drawRoundedBorder(ctx, fx, fy, fw, 20, 5,
                sel ? theme.getPrimaryAccent() : theme.getBorderColor());
            ctx.drawText(this.textRenderer, lbl, fx + 7, fy + 6,
                sel ? theme.getPrimaryText() : theme.getSecondaryText(), false);
            folderBtns.add(new RectBtn(fx, fy, fw, 20, i));
            fx += fw + 5;
        }

        sysPickerW = 78; sysPickerH = 20;
        sysPickerX = winX + winW - sysPickerW - 12;
        sysPickerY = fy;
        PurnaGuiRenderer.drawRoundedRect(ctx, sysPickerX, sysPickerY, sysPickerW, sysPickerH, 5, PurnaTheme.withAlpha(theme.getCardBackground(), 0.88f));
        PurnaGuiRenderer.drawRoundedBorder(ctx, sysPickerX, sysPickerY, sysPickerW, sysPickerH, 5, theme.getBorderColor());
        int bw = this.textRenderer.getWidth("Browse...");
        ctx.drawText(this.textRenderer, "Browse...", sysPickerX + (sysPickerW - bw) / 2, sysPickerY + 6, theme.getPrimaryText(), false);

        int previewW = Math.min(160, Math.max(100, winW / 3));
        listX = winX + 12;
        listY = winY + 68;
        listW = Math.max(120, winW - previewW - 34);
        listH = Math.max(80, winH - 94);

        fileScroll.update(0.016f);
        int rowH = MobilePlatform.isMobileMode() ? 28 : 24;
        fileScroll.setBounds(currentFiles.size() * (rowH + 4), listH);

        PurnaGuiRenderer.drawRoundedRect(ctx, listX, listY, listW, listH, 7, PurnaTheme.withAlpha(theme.getMainBackground(), 0.72f));
        fileRows.clear();

        if (currentFiles.isEmpty()) {
            PurnaGuiRenderer.drawTrimmedText(ctx, this.textRenderer, "No PNG/JPG photos found here.",
                listX + 10, listY + 14, listW - 20, theme.getSecondaryText());
            PurnaGuiRenderer.drawTrimmedText(ctx, this.textRenderer, "Put images in config/purnadlc/photos/",
                listX + 10, listY + 28, listW - 20, theme.getDisabledText());
        } else {
            boolean sc = PurnaGuiRenderer.safeEnableScissor(ctx, listX + 2, listY + 2, listX + listW - 2, listY + listH - 2);
            int cy = listY + 4 - fileScroll.getScrollInt();
            for (int i = 0; i < currentFiles.size(); i++) {
                Path p = currentFiles.get(i);
                if (cy + rowH >= listY && cy <= listY + listH) {
                    boolean active = p.toString().equals(pm.getLoadedPath());
                    boolean hov = PurnaGuiRenderer.isHovered(mouseX, mouseY, listX + 4, cy, listW - 8, rowH);
                    int bg = active ? theme.getSelectedCategory() : (hov ? theme.getCardHover() : theme.getCardBackground());
                    PurnaGuiRenderer.drawRoundedRect(ctx, listX + 4, cy, listW - 8, rowH, 5, PurnaTheme.withAlpha(bg, 0.82f));
                    PurnaGuiRenderer.drawTrimmedText(ctx, this.textRenderer, p.getFileName().toString(),
                        listX + 10, cy + (rowH - this.textRenderer.fontHeight) / 2, listW - 22,
                        active ? 0xFFFFFFFF : theme.getPrimaryText());
                    fileRows.add(new RectBtn(listX + 4, cy, listW - 8, rowH, i));
                }
                cy += rowH + 4;
            }
            if (sc) ctx.disableScissor();
        }

        int px = listX + listW + 10, py = listY, ph = listH;
        PurnaGuiRenderer.drawRoundedRect(ctx, px, py, previewW, ph, 7, PurnaTheme.withAlpha(theme.getMainBackground(), 0.78f));
        PurnaGuiRenderer.drawRoundedBorder(ctx, px, py, previewW, ph, 7, theme.getBorderColor());
        ctx.drawText(this.textRenderer, "Preview", px + 8, py + 7, theme.getSecondaryText(), false);

        int boxSize = Math.min(previewW - 16, ph - 36);
        int bx = px + (previewW - boxSize) / 2;
        int by = py + 24;
        if (pm.hasPhoto()) {
            GuiTextureBlitter.drawCoverTexture(ctx, pm.getActiveTextureId(), bx, by, boxSize, boxSize,
                pm.getTextureWidth(), pm.getTextureHeight(), 0xFFFFFFFF);
            PurnaGuiRenderer.drawRoundedBorder(ctx, bx, by, boxSize, boxSize, 4, theme.getPrimaryAccent());
        } else {
            PurnaGuiRenderer.drawRoundedRect(ctx, bx, by, boxSize, boxSize, 6, PurnaTheme.withAlpha(theme.getCardBackground(), 0.85f));
            PurnaGuiRenderer.drawTrimmedText(ctx, this.textRenderer, "No photo", bx + 12, by + boxSize / 2 - 4,
                boxSize - 16, theme.getDisabledText());
        }

        String footer = !statusMsg.isEmpty() ? statusMsg : (pm.hasPhoto() ? "Selected: " + Path.of(pm.getLoadedPath()).getFileName() : "Tap any photo to set on HUD");
        PurnaGuiRenderer.drawTrimmedText(ctx, this.textRenderer, footer, winX + 14, winY + winH - 18, winW - 28, theme.getSecondaryText());
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        HudModule hud = purna.getModuleManager().getModule(HudModule.class);

        if (moveMode) {
            if (PurnaGuiRenderer.isHovered(mx, my, moveToggleX, moveToggleY, moveToggleW, moveToggleH)) {
                moveMode = false;
                return true;
            }
            if (hud != null) {
                int px = hud.photoX.getInt(), py = hud.photoY.getInt();
                int pw = hud.photoWidth.getInt(), ph = hud.photoHeight.getInt();
                if (PurnaGuiRenderer.isHovered(mx, my, px - 6, py - 6, pw + 12, ph + 12)) {
                    draggingPhoto = true;
                    dragOffsetX = mx - px;
                    dragOffsetY = my - py;
                    return true;
                }
            }
            return true;
        }

        if (PurnaGuiRenderer.isHovered(mx, my, closeBtnX, closeBtnY, closeBtnW, closeBtnH)) { close(); return true; }
        if (PurnaGuiRenderer.isHovered(mx, my, moveToggleX, moveToggleY, moveToggleW, moveToggleH)) { moveMode = true; return true; }
        if (PurnaGuiRenderer.isHovered(mx, my, clearBtnX, clearBtnY, clearBtnW, clearBtnH)) {
            purna.getPhotoManager().clearPhoto();
            if (hud != null) hud.photoPath.setValue("");
            statusMsg = "Photo cleared";
            return true;
        }
        if (PurnaGuiRenderer.isHovered(mx, my, sysPickerX, sysPickerY, sysPickerW, sysPickerH)) {
            Path picked = purna.getPhotoManager().openDesktopSystemPicker();
            if (picked != null) applyPickedPhoto(picked, hud);
            else statusMsg = "Use folder tabs above on mobile";
            return true;
        }

        for (RectBtn fb : folderBtns) {
            if (PurnaGuiRenderer.isHovered(mx, my, fb.x, fb.y, fb.w, fb.h)) {
                selectedFolderIdx = fb.index;
                refreshFiles();
                return true;
            }
        }

        if (PurnaGuiRenderer.isHovered(mx, my, listX, listY, listW, listH)) {
            for (RectBtn row : fileRows) {
                if (PurnaGuiRenderer.isHovered(mx, my, row.x, row.y, row.w, row.h)) {
                    applyPickedPhoto(currentFiles.get(row.index), hud);
                    return true;
                }
            }
            fileScroll.beginTouchDrag(my);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    private void applyPickedPhoto(Path path, HudModule hud) {
        if (path == null) return;
        boolean ok = purna.getPhotoManager().loadPhoto(path.toString());
        if (ok && hud != null) {
            hud.photos.setValue(true);
            hud.photoPath.setValue(path.toString());
            purna.getProfileManager().saveCurrentProfile();
            statusMsg = "Loaded: " + path.getFileName();
        } else {
            statusMsg = "Load failed: " + purna.getPhotoManager().getLastError();
        }
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        double mx = click.x(), my = click.y();
        if (draggingPhoto) {
            HudModule hud = purna.getModuleManager().getModule(HudModule.class);
            if (hud != null) {
                int pw = hud.photoWidth.getInt(), ph = hud.photoHeight.getInt();
                int nx = (int) Math.max(0, Math.min(this.width - pw, Math.round(mx - dragOffsetX)));
                int ny = (int) Math.max(0, Math.min(this.height - ph, Math.round(my - dragOffsetY)));
                hud.photoX.setValue((double) nx);
                hud.photoY.setValue((double) ny);
            }
            return true;
        }
        if (fileScroll.updateTouchDrag(my)) return true;
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (draggingPhoto) {
            draggingPhoto = false;
            purna.getProfileManager().saveCurrentProfile();
        }
        fileScroll.endTouchDrag();
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!moveMode && PurnaGuiRenderer.isHovered(mouseX, mouseY, listX, listY, listW, listH)) {
            fileScroll.onWheel(verticalAmount);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
            if (moveMode) { moveMode = false; return true; }
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        purna.getProfileManager().saveCurrentProfile();
        MinecraftClient.getInstance().setScreen(parent);
    }
}
