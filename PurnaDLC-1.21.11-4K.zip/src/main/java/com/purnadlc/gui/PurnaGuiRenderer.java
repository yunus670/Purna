package com.purnadlc.gui;

import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class PurnaGuiRenderer {
    private PurnaGuiRenderer() {}

    /**
     * Clamps scissor rectangle to current scaled screen bounds so Android GL4ES / Zink
     * never receives invalid or inverted scissor coordinates during resize or animation.
     *
     * @return true if scissor was enabled (caller MUST call ctx.disableScissor() only when true)
     */
    public static boolean safeEnableScissor(DrawContext ctx, int x1, int y1, int x2, int y2) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int maxW = (mc != null && mc.getWindow() != null) ? mc.getWindow().getScaledWidth() : 4096;
        int maxH = (mc != null && mc.getWindow() != null) ? mc.getWindow().getScaledHeight() : 4096;

        int cx1 = Math.max(0, Math.min(maxW, x1));
        int cy1 = Math.max(0, Math.min(maxH, y1));
        int cx2 = Math.max(0, Math.min(maxW, x2));
        int cy2 = Math.max(0, Math.min(maxH, y2));

        if (cx2 <= cx1 || cy2 <= cy1) {
            return false;
        }
        ctx.enableScissor(cx1, cy1, cx2, cy2);
        return true;
    }

    public static void drawDropShadow(DrawContext ctx, int x, int y, int w, int h, int radius, float alphaMul) {
        if (w <= 0 || h <= 0 || alphaMul <= 0.01f) return;
        // Fewer shadow passes on Android GL4ES / Zink to preserve high FPS
        int layers = MobilePlatform.isMobileMode() ? 2 : 5;
        for (int i = layers; i >= 1; i--) {
            int spread = MobilePlatform.isMobileMode() ? i * 2 : i;
            int alpha = Math.round((24f / i) * alphaMul);
            int color = (alpha << 24);
            drawRoundedRect(ctx, x - spread, y - spread + 2, w + spread * 2, h + spread * 2, radius + spread, color);
        }
    }

    public static void drawRoundedRect(DrawContext ctx, int x, int y, int w, int h, int radius, int color) {
        if (w <= 0 || h <= 0 || ((color >>> 24) & 0xFF) == 0) return;
        int r = Math.max(0, Math.min(radius, Math.min(w / 2, h / 2)));
        if (r == 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }

        if (h > r * 2) {
            ctx.fill(x, y + r, x + w, y + h - r, color);
        }

        for (int row = 0; row < r; row++) {
            double dy = r - row - 0.5;
            int inset = (int) Math.ceil(r - Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            int x1 = x + inset;
            int x2 = x + w - inset;
            if (x2 > x1) {
                ctx.fill(x1, y + row, x2, y + row + 1, color);
                ctx.fill(x1, y + h - 1 - row, x2, y + h - row, color);
            }
        }
    }

    public static void drawRoundedBorder(DrawContext ctx, int x, int y, int w, int h, int radius, int color) {
        if (w <= 2 || h <= 2 || ((color >>> 24) & 0xFF) == 0) return;
        int r = Math.max(0, Math.min(radius, Math.min(w / 2, h / 2)));
        if (r == 0) {
            ctx.fill(x, y, x + w, y + 1, color);
            ctx.fill(x, y + h - 1, x + w, y + h, color);
            ctx.fill(x, y, x + 1, y + h, color);
            ctx.fill(x + w - 1, y, x + w, y + h, color);
            return;
        }

        ctx.fill(x + r, y, x + w - r, y + 1, color);
        ctx.fill(x + r, y + h - 1, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + 1, y + h - r, color);
        ctx.fill(x + w - 1, y + r, x + w, y + h - r, color);

        int prevInset = r;
        for (int row = 0; row < r; row++) {
            double dy = r - row - 0.5;
            int inset = (int) Math.ceil(r - Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            int spanEnd = Math.max(inset + 1, prevInset);
            ctx.fill(x + inset, y + row, x + spanEnd, y + row + 1, color);
            ctx.fill(x + w - spanEnd, y + row, x + w - inset, y + row + 1, color);
            ctx.fill(x + inset, y + h - 1 - row, x + spanEnd, y + h - row, color);
            ctx.fill(x + w - spanEnd, y + h - 1 - row, x + w - inset, y + h - row, color);
            prevInset = inset;
        }
    }

    public static void drawCircle(DrawContext ctx, int cx, int cy, int radius, int color) {
        if (radius <= 0 || ((color >>> 24) & 0xFF) == 0) return;
        int rSq = radius * radius;
        for (int dy = -radius; dy <= radius; dy++) {
            int dx = (int) Math.floor(Math.sqrt(Math.max(0, rSq - dy * dy)));
            ctx.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
        }
    }

    public static void drawToggle(DrawContext ctx, int x, int y, int w, int h, float progress, PurnaTheme theme, float alphaMul) {
        int bgColor = PurnaTheme.lerpColor(theme.getDisabledToggle(), theme.getEnabledToggle(), progress);
        bgColor = PurnaTheme.withAlpha(bgColor, alphaMul);
        drawRoundedRect(ctx, x, y, w, h, h / 2, bgColor);

        int knobRadius = Math.max(3, (h - 4) / 2);
        int minCx = x + 2 + knobRadius;
        int maxCx = x + w - 2 - knobRadius;
        int cx = Math.round(minCx + (maxCx - minCx) * progress);
        int cy = y + h / 2;

        int knobColor = PurnaTheme.lerpColor(0xFF9EA0AC, 0xFFF5F6FA, progress);
        drawCircle(ctx, cx, cy, knobRadius, PurnaTheme.withAlpha(knobColor, alphaMul));
    }

    public static void drawPurnaLogo(DrawContext ctx, int x, int y, int size, PurnaTheme theme, float alphaMul) {
        int primary = PurnaTheme.withAlpha(theme.getPrimaryAccent(), alphaMul);
        int secondary = PurnaTheme.withAlpha(theme.getSecondaryAccent(), alphaMul);
        int highlight = PurnaTheme.withAlpha(PurnaTheme.lerpColor(theme.getPrimaryAccent(), 0xFFFFFFFF, 0.30f), alphaMul);

        int stemW = Math.max(3, size / 4);
        int barH = Math.max(2, size / 5);
        int loopBottom = y + (size * 58) / 100;

        for (int row = 0; row < size; row++) {
            int slant = Math.round((size - row) * 0.16f);
            int sx = x + slant;
            ctx.fill(sx, y + row, sx + stemW, y + row + 1, row < barH ? highlight : primary);
            if (row < barH) {
                ctx.fill(sx + stemW, y + row, sx + size - 2, y + row + 1, secondary);
            }
            if (y + row >= loopBottom - barH && y + row < loopBottom) {
                ctx.fill(sx + stemW, y + row, sx + size - 3, y + row + 1, secondary);
            }
            if (row >= barH && y + row < loopBottom - barH) {
                ctx.fill(sx + size - stemW - 1, y + row, sx + size - 1, y + row + 1, secondary);
            }
        }
    }

    public static void drawGearIcon(DrawContext ctx, int cx, int cy, int color) {
        if (((color >>> 24) & 0xFF) == 0) return;
        ctx.fill(cx - 1, cy - 4, cx + 2, cy - 3, color);
        ctx.fill(cx - 1, cy + 4, cx + 2, cy + 5, color);
        ctx.fill(cx - 4, cy - 1, cx - 3, cy + 2, color);
        ctx.fill(cx + 4, cy - 1, cx + 5, cy + 2, color);
        ctx.fill(cx - 3, cy - 3, cx + 4, cy - 2, color);
        ctx.fill(cx - 3, cy + 3, cx + 4, cy + 4, color);
        ctx.fill(cx - 3, cy - 2, cx - 2, cy + 3, color);
        ctx.fill(cx + 3, cy - 2, cx + 4, cy + 3, color);
        ctx.fill(cx - 2, cy - 2, cx - 1, cy - 1, color);
        ctx.fill(cx + 2, cy - 2, cx + 3, cy - 1, color);
        ctx.fill(cx - 2, cy + 2, cx - 1, cy + 3, color);
        ctx.fill(cx + 2, cy + 2, cx + 3, cy + 3, color);
    }

    public static void drawSearchIcon(DrawContext ctx, int cx, int cy, int color) {
        if (((color >>> 24) & 0xFF) == 0) return;
        ctx.fill(cx - 2, cy - 4, cx + 2, cy - 3, color);
        ctx.fill(cx - 2, cy + 1, cx + 2, cy + 2, color);
        ctx.fill(cx - 4, cy - 2, cx - 3, cy + 1, color);
        ctx.fill(cx + 2, cy - 2, cx + 3, cy + 1, color);
        ctx.fill(cx - 3, cy - 3, cx - 2, cy - 2, color);
        ctx.fill(cx + 1, cy - 3, cx + 2, cy - 2, color);
        ctx.fill(cx - 3, cy, cx - 2, cy + 1, color);
        ctx.fill(cx + 1, cy, cx + 2, cy + 1, color);
        ctx.fill(cx + 2, cy + 2, cx + 3, cy + 3, color);
        ctx.fill(cx + 3, cy + 3, cx + 4, cy + 4, color);
        ctx.fill(cx + 4, cy + 4, cx + 5, cy + 5, color);
    }

    public static void drawProfileIcon(DrawContext ctx, int cx, int cy, int color) {
        if (((color >>> 24) & 0xFF) == 0) return;
        ctx.fill(cx - 3, cy, cx + 4, cy + 2, color);
        ctx.fill(cx - 2, cy - 2, cx + 3, cy, color);
        ctx.fill(cx - 1, cy - 3, cx + 2, cy - 2, color);
    }

    public static void drawCategoryIcon(DrawContext ctx, String iconId, int x, int y, int color) {
        if (((color >>> 24) & 0xFF) == 0) return;
        int cx = x + 4;
        int cy = y + 4;
        switch (iconId) {
            case "combat" -> {
                for (int i = -3; i <= 2; i++) {
                    ctx.fill(cx + i, cy - i, cx + i + 2, cy - i + 1, color);
                }
                ctx.fill(cx - 3, cy + 1, cx, cy + 2, color);
                ctx.fill(cx - 2, cy + 2, cx - 1, cy + 4, color);
            }
            case "movement" -> {
                ctx.fill(cx, cy - 4, cx + 3, cy - 3, color);
                ctx.fill(cx - 1, cy - 3, cx + 2, cy - 1, color);
                ctx.fill(cx - 3, cy - 1, cx + 3, cy + 1, color);
                ctx.fill(cx - 1, cy + 1, cx + 2, cy + 3, color);
                ctx.fill(cx - 2, cy + 3, cx + 1, cy + 4, color);
            }
            case "player" -> {
                ctx.fill(cx - 1, cy - 4, cx + 2, cy - 1, color);
                ctx.fill(cx - 3, cy + 1, cx + 4, cy + 3, color);
                ctx.fill(cx - 2, cy, cx + 3, cy + 1, color);
            }
            case "visuals" -> {
                ctx.fill(cx - 2, cy - 3, cx + 3, cy - 2, color);
                ctx.fill(cx - 4, cy - 1, cx - 2, cy + 1, color);
                ctx.fill(cx + 3, cy - 1, cx + 5, cy + 1, color);
                ctx.fill(cx - 2, cy + 2, cx + 3, cy + 3, color);
                ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, color);
            }
            case "misc" -> {
                ctx.fill(cx - 3, cy - 3, cx - 1, cy - 1, color);
                ctx.fill(cx + 1, cy - 3, cx + 3, cy - 1, color);
                ctx.fill(cx - 3, cy + 1, cx - 1, cy + 3, color);
                ctx.fill(cx + 1, cy + 1, cx + 3, cy + 3, color);
            }
            case "theme" -> {
                ctx.fill(cx - 2, cy - 3, cx + 3, cy - 2, color);
                ctx.fill(cx - 2, cy + 2, cx + 3, cy + 3, color);
                ctx.fill(cx - 3, cy - 2, cx - 2, cy + 2, color);
                ctx.fill(cx + 2, cy - 2, cx + 3, cy + 2, color);
                ctx.fill(cx, cy - 1, cx + 2, cy + 1, color);
            }
            default -> {
                ctx.fill(cx - 3, cy - 3, cx + 4, cy + 2, color);
                ctx.fill(cx - 2, cy + 2, cx, cy + 4, color);
            }
        }
    }

    public static void drawTrimmedText(DrawContext ctx, TextRenderer tr, String text, int x, int y, int maxWidth, int color) {
        if (text == null || text.isEmpty() || maxWidth <= 4 || ((color >>> 24) & 0xFF) == 0) return;
        String clipped = tr.trimToWidth(text, maxWidth);
        if (clipped.length() < text.length() && maxWidth > 14) {
            clipped = tr.trimToWidth(text, maxWidth - tr.getWidth("...")) + "...";
        }
        ctx.drawText(tr, clipped, x, y, color, false);
    }

    public static boolean isHovered(double mouseX, double mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }
}
