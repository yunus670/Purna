package com.purnadlc.gui.component;

import com.purnadlc.animation.PurnaAnimationManager;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.gui.ScrollController;
import com.purnadlc.module.Module;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.setting.*;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class ModuleSettingsPanel {
    private static final double TOUCH_DRAG_SLOP = 7.0;

    private Module activeModule = null;
    private final ScrollController scroll = new ScrollController();

    private NumberSetting draggingSlider = null;
    private int dragSliderX = 0;
    private int dragSliderW = 1;

    private ColorSetting draggingColor = null;
    private int draggingColorChannel = -1;
    private int dragColorX = 0;
    private int dragColorW = 1;

    private BindSetting listeningBind = null;
    private StringSetting focusedString = null;
    private ColorSetting focusedHexColor = null;
    private String hexBuffer = "";

    private int panelX, panelY, panelW, panelH;
    private int closeBtnX, closeBtnY, closeBtnW, closeBtnH;
    private int listX, listY, listW, listH;

    // Touch scroll vs tap disambiguation for non-slider rows
    private boolean touchScrollCandidate = false;
    private double pressStartX = 0.0;
    private double pressStartY = 0.0;
    private boolean scrolledSincePress = false;
    private SettingRowLayout pendingTapRow = null;
    private double pendingTapX = 0.0;
    private double pendingTapY = 0.0;

    private record SettingRowLayout(Setting<?> setting, int x, int y, int w, int h) {}
    private final List<SettingRowLayout> rowLayouts = new ArrayList<>();

    public void open(Module module, PurnaAnimationManager anim) {
        this.activeModule = module;
        this.scroll.reset();
        clearInputFocus();
        anim.setSettingsOpen(true);
    }

    public void close(PurnaAnimationManager anim) {
        clearInputFocus();
        anim.setSettingsOpen(false);
    }

    public Module getActiveModule() { return activeModule; }
    public boolean isOpen() { return activeModule != null; }

    public boolean hasKeyboardCapture() {
        return listeningBind != null || focusedString != null || focusedHexColor != null;
    }

    public void clearInputFocus() {
        draggingSlider = null;
        draggingColor = null;
        draggingColorChannel = -1;
        listeningBind = null;
        focusedString = null;
        focusedHexColor = null;
        hexBuffer = "";
        touchScrollCandidate = false;
        scrolledSincePress = false;
        pendingTapRow = null;
    }

    public void render(DrawContext ctx, TextRenderer tr, int winX, int winY, int winW, int winH,
                       int mouseX, int mouseY, float parentAlpha, PurnaTheme theme, PurnaAnimationManager anim) {
        if (activeModule == null) return;
        if (!anim.isSettingsVisible()) {
            activeModule = null;
            return;
        }

        float alpha = parentAlpha * anim.getSettingsAlpha();
        float scale = anim.getSettingsScale();
        scroll.update(anim.getDeltaSeconds());

        PurnaGuiRenderer.drawRoundedRect(ctx, winX, winY, winW, winH, PurnaTheme.WINDOW_RADIUS,
            PurnaTheme.overrideAlpha(0x000000, Math.round(115 * alpha)));

        int baseW = Math.min(350, Math.max(220, winW - 32));
        int baseH = Math.min(370, Math.max(200, winH - 32));
        panelW = Math.round(baseW * scale);
        panelH = Math.round(baseH * scale);
        panelX = winX + (winW - panelW) / 2;
        panelY = winY + (winH - panelH) / 2;

        PurnaGuiRenderer.drawDropShadow(ctx, panelX, panelY, panelW, panelH, 10, alpha);
        PurnaGuiRenderer.drawRoundedRect(ctx, panelX, panelY, panelW, panelH, 10,
            PurnaTheme.withAlpha(theme.getSecondaryBackground(), alpha));
        PurnaGuiRenderer.drawRoundedBorder(ctx, panelX, panelY, panelW, panelH, 10,
            PurnaTheme.withAlpha(theme.getBorderColor(), alpha));

        int headerH = 44;
        PurnaGuiRenderer.drawTrimmedText(ctx, tr, activeModule.getName() + " Settings",
            panelX + 14, panelY + 11, panelW - 56, PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));
        PurnaGuiRenderer.drawTrimmedText(ctx, tr, activeModule.getDescription(),
            panelX + 14, panelY + 24, panelW - 56, PurnaTheme.withAlpha(theme.getSecondaryText(), alpha));

        boolean mobile = MobilePlatform.isMobileMode();
        closeBtnW = mobile ? 26 : 20;
        closeBtnH = mobile ? 26 : 20;
        closeBtnX = panelX + panelW - closeBtnW - 10;
        closeBtnY = panelY + 9;
        boolean closeHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, closeBtnX, closeBtnY, closeBtnW, closeBtnH);
        PurnaGuiRenderer.drawRoundedRect(ctx, closeBtnX, closeBtnY, closeBtnW, closeBtnH, 5,
            PurnaTheme.withAlpha(closeHover ? theme.getCardHover() : theme.getCardBackground(), alpha));
        int xw = tr.getWidth("x");
        ctx.drawText(tr, "x", closeBtnX + (closeBtnW - xw) / 2, closeBtnY + (closeBtnH - tr.fontHeight) / 2,
            PurnaTheme.withAlpha(theme.getPrimaryText(), alpha), false);

        ctx.fill(panelX + 10, panelY + headerH, panelX + panelW - 10, panelY + headerH + 1,
            PurnaTheme.withAlpha(theme.getBorderColor(), alpha));

        listX = panelX + 12;
        listY = panelY + headerH + 8;
        listW = Math.max(40, panelW - 24);
        listH = Math.max(40, panelH - headerH - 18);

        List<Setting<?>> allSettings = new ArrayList<>();
        allSettings.add(activeModule.getKeybind());
        for (Setting<?> s : activeModule.getSettings()) {
            if (s.isVisible()) allSettings.add(s);
        }

        rowLayouts.clear();
        int totalH = 0;
        for (Setting<?> s : allSettings) {
            totalH += measureSettingHeight(s, mobile) + 6;
        }
        if (!activeModule.hasConfigurableSettings()) totalH += 36;
        scroll.setBounds(totalH, listH);

        boolean scissored = PurnaGuiRenderer.safeEnableScissor(ctx, listX - 2, listY, listX + listW + 2, listY + listH);
        int cursorY = listY - scroll.getScrollInt();

        for (Setting<?> s : allSettings) {
            int rowH = measureSettingHeight(s, mobile);
            rowLayouts.add(new SettingRowLayout(s, listX, cursorY, listW, rowH));
            if (cursorY + rowH >= listY - 4 && cursorY <= listY + listH + 4) {
                renderSettingRow(ctx, tr, s, listX, cursorY, listW, rowH, mouseX, mouseY, alpha, theme, anim, mobile);
            }
            cursorY += rowH + 6;
        }

        if (!activeModule.hasConfigurableSettings()) {
            PurnaGuiRenderer.drawRoundedRect(ctx, listX, cursorY, listW, 30, 6,
                PurnaTheme.withAlpha(theme.getCardBackground(), alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, "No additional settings available for this module.",
                listX + 10, cursorY + 11, listW - 20, PurnaTheme.withAlpha(theme.getSecondaryText(), alpha));
        }

        if (scissored) ctx.disableScissor();

        if (scroll.canScroll()) {
            int trackH = listH - 4;
            int thumbH = Math.max(22, Math.round(trackH * ((float) listH / Math.max(1, totalH))));
            int thumbY = listY + 2 + Math.round((trackH - thumbH) * scroll.getScrollRatio());
            PurnaGuiRenderer.drawRoundedRect(ctx, panelX + panelW - 6, thumbY, 3, thumbH, 1,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha * 0.75f));
        }
    }

    private int measureSettingHeight(Setting<?> setting, boolean mobile) {
        if (setting instanceof NumberSetting) return mobile ? 46 : 40;
        if (setting instanceof MultiModeSetting) return mobile ? 54 : 48;
        if (setting instanceof ColorSetting) return mobile ? 92 : 84;
        if (setting instanceof StringSetting) return mobile ? 48 : 44;
        return mobile ? 36 : 30;
    }

    private void renderSettingRow(DrawContext ctx, TextRenderer tr, Setting<?> setting,
                                  int x, int y, int w, int h, int mouseX, int mouseY,
                                  float alpha, PurnaTheme theme, PurnaAnimationManager anim, boolean mobile) {
        boolean hov = PurnaGuiRenderer.isHovered(mouseX, mouseY, x, y, w, h);
        PurnaGuiRenderer.drawRoundedRect(ctx, x, y, w, h, 6,
            PurnaTheme.withAlpha(hov ? theme.getCardHover() : theme.getCardBackground(), alpha));

        int pad = 10;
        int labelColor = PurnaTheme.withAlpha(theme.getPrimaryText(), alpha);
        int subColor = PurnaTheme.withAlpha(theme.getSecondaryText(), alpha);
        int midY = y + (h - tr.fontHeight) / 2;

        if (setting instanceof BooleanSetting bool) {
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, bool.getName(), x + pad, midY, w - 62, labelColor);
            float p = anim.updateToggle("set_bool_" + activeModule.getName() + "_" + bool.getName(), bool.isEnabled());
            int tw = mobile ? 32 : 28;
            int th = mobile ? 16 : 14;
            PurnaGuiRenderer.drawToggle(ctx, x + w - pad - tw, y + (h - th) / 2, tw, th, p, theme, alpha);
        } else if (setting instanceof NumberSetting num) {
            String valStr = num.getFormattedValue();
            int valW = tr.getWidth(valStr);
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, num.getName(), x + pad, y + 7, w - valW - 28, labelColor);
            ctx.drawText(tr, valStr, x + w - pad - valW, y + 7,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha), false);

            int sx = x + pad;
            int sy = y + (mobile ? 29 : 25);
            int sw = Math.max(20, w - pad * 2);
            int sh = mobile ? 6 : 5;
            PurnaGuiRenderer.drawRoundedRect(ctx, sx, sy, sw, sh, 3,
                PurnaTheme.withAlpha(theme.getDisabledToggle(), alpha));
            int fillW = Math.max(4, Math.round(sw * num.getNormalized()));
            PurnaGuiRenderer.drawRoundedRect(ctx, sx, sy, fillW, sh, 3,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha));
            PurnaGuiRenderer.drawCircle(ctx, sx + fillW, sy + sh / 2, mobile ? 5 : 4,
                PurnaTheme.withAlpha(0xFFF5F6FA, alpha));
        } else if (setting instanceof ModeSetting mode) {
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, mode.getName(), x + pad, midY, w / 2 - 12, labelColor);
            String cur = mode.getValue();
            int pillW = Math.min(w / 2, tr.getWidth(cur) + 18);
            int pillH = mobile ? 22 : 18;
            int pillX = x + w - pad - pillW;
            int pillY = y + (h - pillH) / 2;
            PurnaGuiRenderer.drawRoundedRect(ctx, pillX, pillY, pillW, pillH, 5,
                PurnaTheme.withAlpha(theme.getSelectedCategory(), alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, cur, pillX + 8, pillY + (pillH - tr.fontHeight) / 2, pillW - 12,
                PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));
        } else if (setting instanceof EnumSetting<?> en) {
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, en.getName(), x + pad, midY, w / 2 - 12, labelColor);
            String cur = en.getDisplayName();
            int pillW = Math.min(w / 2, tr.getWidth(cur) + 18);
            int pillH = mobile ? 22 : 18;
            int pillX = x + w - pad - pillW;
            int pillY = y + (h - pillH) / 2;
            PurnaGuiRenderer.drawRoundedRect(ctx, pillX, pillY, pillW, pillH, 5,
                PurnaTheme.withAlpha(theme.getSelectedCategory(), alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, cur, pillX + 8, pillY + (pillH - tr.fontHeight) / 2, pillW - 12,
                PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));
        } else if (setting instanceof MultiModeSetting multi) {
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, multi.getName(), x + pad, y + 6, w - 70, labelColor);
            String sum = multi.getSummaryText();
            int sw = tr.getWidth(sum);
            ctx.drawText(tr, sum, x + w - pad - sw, y + 6, subColor, false);

            int cx = x + pad;
            int cy = y + (mobile ? 24 : 22);
            int chipH = mobile ? 22 : 18;
            for (String opt : multi.getOptions()) {
                int chipW = tr.getWidth(opt) + 12;
                if (cx + chipW > x + w - pad) break;
                boolean active = multi.isSelected(opt);
                int chipBg = active ? theme.getPrimaryAccent() : theme.getSecondaryBackground();
                PurnaGuiRenderer.drawRoundedRect(ctx, cx, cy, chipW, chipH, 5, PurnaTheme.withAlpha(chipBg, alpha));
                ctx.drawText(tr, opt, cx + 6, cy + (chipH - tr.fontHeight) / 2,
                    PurnaTheme.withAlpha(active ? 0xFFFFFFFF : theme.getSecondaryText(), alpha), false);
                cx += chipW + 4;
            }
        } else if (setting instanceof BindSetting bind) {
            boolean showClear = bind.isBound();
            int clearW = showClear ? 22 : 0;
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, bind.getName(), x + pad, midY, w - 104 - clearW, labelColor);

            boolean listening = (bind == listeningBind);
            String keyLabel = listening ? "Press key..." : bind.getKeyName();
            int pillH = mobile ? 22 : 18;
            int pillY = y + (h - pillH) / 2;
            int bw = Math.max(54, tr.getWidth(keyLabel) + 14);
            int bx = x + w - pad - bw - (showClear ? (clearW + 4) : 0);
            int bg = listening ? theme.getPrimaryAccent() : theme.getSecondaryBackground();
            PurnaGuiRenderer.drawRoundedRect(ctx, bx, pillY, bw, pillH, 5, PurnaTheme.withAlpha(bg, alpha));
            int tw = tr.getWidth(keyLabel);
            ctx.drawText(tr, keyLabel, bx + (bw - tw) / 2, pillY + (pillH - tr.fontHeight) / 2,
                PurnaTheme.withAlpha(theme.getPrimaryText(), alpha), false);

            if (showClear) {
                int clx = x + w - pad - clearW;
                PurnaGuiRenderer.drawRoundedRect(ctx, clx, pillY, clearW, pillH, 5,
                    PurnaTheme.withAlpha(theme.getSecondaryBackground(), alpha));
                int xw = tr.getWidth("x");
                ctx.drawText(tr, "x", clx + (clearW - xw) / 2, pillY + (pillH - tr.fontHeight) / 2,
                    PurnaTheme.withAlpha(theme.getSecondaryText(), alpha), false);
            }
        } else if (setting instanceof StringSetting str) {
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, str.getName(), x + pad, y + 6, w - pad * 2, labelColor);
            boolean focused = (str == focusedString);
            int bx = x + pad;
            int by = y + 20;
            int bw = w - pad * 2;
            int bh = mobile ? 22 : 18;
            PurnaGuiRenderer.drawRoundedRect(ctx, bx, by, bw, bh, 5,
                PurnaTheme.withAlpha(theme.getMainBackground(), alpha));
            PurnaGuiRenderer.drawRoundedBorder(ctx, bx, by, bw, bh, 5,
                PurnaTheme.withAlpha(focused ? theme.getPrimaryAccent() : theme.getBorderColor(), alpha));
            String display = str.getValue() + (focused && ((System.currentTimeMillis() / 500) % 2 == 0) ? "|" : "");
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, display, bx + 6, by + (bh - tr.fontHeight) / 2, bw - 12, labelColor);
        } else if (setting instanceof ColorSetting col) {
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, col.getName(), x + pad, y + 7, w - 105, labelColor);
            int swX = x + w - pad - 18;
            PurnaGuiRenderer.drawRoundedRect(ctx, swX, y + 5, 18, 14, 4, PurnaTheme.withAlpha(col.getValue(), alpha));
            PurnaGuiRenderer.drawRoundedBorder(ctx, swX, y + 5, 18, 14, 4, PurnaTheme.withAlpha(theme.getBorderColor(), alpha));

            boolean hexFocused = (col == focusedHexColor);
            int hx = swX - 66;
            PurnaGuiRenderer.drawRoundedRect(ctx, hx, y + 5, 60, 14, 4, PurnaTheme.withAlpha(theme.getMainBackground(), alpha));
            PurnaGuiRenderer.drawRoundedBorder(ctx, hx, y + 5, 60, 14, 4,
                PurnaTheme.withAlpha(hexFocused ? theme.getPrimaryAccent() : theme.getBorderColor(), alpha));
            String hexText = hexFocused ? hexBuffer : col.toHex();
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, hexText, hx + 4, y + 8, 52, labelColor);

            int sliderX = x + pad + 14;
            int sliderW = Math.max(20, w - pad * 2 - 38);
            int stepY = mobile ? 21 : 18;
            drawColorChannel(ctx, tr, "R", col.getRed(),   0xFFE85A7C, x + pad, y + 26, sliderX, sliderW, alpha, theme);
            drawColorChannel(ctx, tr, "G", col.getGreen(), 0xFF47C992, x + pad, y + 26 + stepY, sliderX, sliderW, alpha, theme);
            drawColorChannel(ctx, tr, "B", col.getBlue(),  0xFF56A8E8, x + pad, y + 26 + stepY * 2, sliderX, sliderW, alpha, theme);
        }
    }

    private void drawColorChannel(DrawContext ctx, TextRenderer tr, String label, int val, int barColor,
                                  int lx, int ly, int sx, int sw, float alpha, PurnaTheme theme) {
        ctx.drawText(tr, label, lx, ly, PurnaTheme.withAlpha(theme.getSecondaryText(), alpha), false);
        PurnaGuiRenderer.drawRoundedRect(ctx, sx, ly + 2, sw, 5, 2, PurnaTheme.withAlpha(theme.getDisabledToggle(), alpha));
        int fill = Math.max(3, Math.round(sw * (val / 255f)));
        PurnaGuiRenderer.drawRoundedRect(ctx, sx, ly + 2, fill, 5, 2, PurnaTheme.withAlpha(barColor, alpha));
        ctx.drawText(tr, Integer.toString(val), sx + sw + 5, ly, PurnaTheme.withAlpha(theme.getSecondaryText(), alpha), false);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, PurnaAnimationManager anim) {
        if (activeModule == null) return false;

        if (PurnaGuiRenderer.isHovered(mouseX, mouseY, closeBtnX, closeBtnY, closeBtnW, closeBtnH)
            || !PurnaGuiRenderer.isHovered(mouseX, mouseY, panelX, panelY, panelW, panelH)) {
            close(anim);
            return true;
        }
        if (button != 0) return true;

        clearInputFocus();
        if (!PurnaGuiRenderer.isHovered(mouseX, mouseY, listX, listY, listW, listH)) return true;

        boolean mobile = MobilePlatform.isMobileMode();
        int pad = 10;

        for (SettingRowLayout row : rowLayouts) {
            if (!PurnaGuiRenderer.isHovered(mouseX, mouseY, row.x, row.y, row.w, row.h)) continue;
            Setting<?> s = row.setting;

            // Sliders capture drag immediately so finger dragging adjusts value cleanly without scrolling
            if (s instanceof NumberSetting num) {
                int sx = row.x + pad;
                int sw = Math.max(1, row.w - pad * 2);
                int sy = row.y + (mobile ? 29 : 25);
                if (mouseY >= sy - 10 && mouseY <= sy + 16) {
                    draggingSlider = num;
                    dragSliderX = sx;
                    dragSliderW = sw;
                    num.setNormalized((mouseX - sx) / dragSliderW);
                    return true;
                }
            } else if (s instanceof ColorSetting col) {
                int swX = row.x + row.w - pad - 18;
                int hx = swX - 66;
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, hx, row.y + 4, 60, 16)) {
                    focusedHexColor = col;
                    hexBuffer = col.toHex();
                    return true;
                }
                int stepY = mobile ? 21 : 18;
                int sliderX = row.x + pad + 14;
                int sliderW = Math.max(1, row.w - pad * 2 - 38);
                int channel = -1;
                if (mouseY >= row.y + 22 && mouseY < row.y + 26 + stepY - 2) channel = 0;
                else if (mouseY >= row.y + 26 + stepY - 2 && mouseY < row.y + 26 + stepY * 2 - 2) channel = 1;
                else if (mouseY >= row.y + 26 + stepY * 2 - 2 && mouseY <= row.y + row.h) channel = 2;
                if (channel >= 0) {
                    draggingColor = col;
                    draggingColorChannel = channel;
                    dragColorX = sliderX;
                    dragColorW = sliderW;
                    applyColorDrag(mouseX);
                    return true;
                }
            }

            // All other setting rows defer activation to mouseReleased if user didn't drag-scroll
            pendingTapRow = row;
            pendingTapX = mouseX;
            pendingTapY = mouseY;
            break;
        }

        touchScrollCandidate = true;
        pressStartX = mouseX;
        pressStartY = mouseY;
        scrolledSincePress = false;
        scroll.beginTouchDrag(mouseY);
        return true;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button) {
        if (activeModule == null) return false;
        if (draggingSlider != null) {
            draggingSlider.setNormalized((mouseX - dragSliderX) / dragSliderW);
            return true;
        }
        if (draggingColor != null && draggingColorChannel >= 0) {
            applyColorDrag(mouseX);
            return true;
        }
        if (touchScrollCandidate) {
            if (Math.hypot(mouseX - pressStartX, mouseY - pressStartY) >= TOUCH_DRAG_SLOP) {
                scrolledSincePress = true;
                pendingTapRow = null;
            }
            if (scrolledSincePress) {
                return scroll.updateTouchDrag(mouseY);
            }
            return true;
        }
        return false;
    }

    public void mouseReleased() {
        draggingSlider = null;
        draggingColor = null;
        draggingColorChannel = -1;
        scroll.endTouchDrag();

        if (!scrolledSincePress && pendingTapRow != null) {
            activateSettingRow(pendingTapRow, pendingTapX, pendingTapY);
        }
        touchScrollCandidate = false;
        scrolledSincePress = false;
        pendingTapRow = null;
    }

    private void activateSettingRow(SettingRowLayout row, double mouseX, double mouseY) {
        Setting<?> s = row.setting;
        int pad = 10;
        boolean mobile = MobilePlatform.isMobileMode();

        if (s instanceof BooleanSetting bool) {
            bool.toggle();
        } else if (s instanceof ModeSetting mode) {
            mode.cycleNext();
        } else if (s instanceof EnumSetting<?> en) {
            en.cycleNext();
        } else if (s instanceof MultiModeSetting multi) {
            int cx = row.x + pad;
            int cy = row.y + (mobile ? 24 : 22);
            int chipH = mobile ? 22 : 18;
            for (String opt : multi.getOptions()) {
                int chipW = MinecraftClient.getInstance().textRenderer.getWidth(opt) + 12;
                if (cx + chipW > row.x + row.w - pad) break;
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, cx, cy, chipW, chipH)) {
                    multi.toggleOption(opt);
                    break;
                }
                cx += chipW + 4;
            }
        } else if (s instanceof BindSetting bind) {
            if (bind.isBound()) {
                int clx = row.x + row.w - pad - 22;
                if (mouseX >= clx - 2) {
                    bind.setValue(BindSetting.UNBOUND);
                    return;
                }
            }
            listeningBind = bind;
        } else if (s instanceof StringSetting str) {
            focusedString = str;
        }
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double verticalAmount) {
        if (activeModule == null) return false;
        if (PurnaGuiRenderer.isHovered(mouseX, mouseY, panelX, panelY, panelW, panelH)) {
            scroll.onWheel(verticalAmount);
            return true;
        }
        return false;
    }

    public boolean keyPressed(int keyCode, PurnaAnimationManager anim) {
        if (activeModule == null) return false;
        if (listeningBind != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                listeningBind.setValue(BindSetting.UNBOUND);
            } else {
                listeningBind.setValue(keyCode);
            }
            listeningBind = null;
            return true;
        }
        if (focusedHexColor != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                focusedHexColor = null;
                hexBuffer = "";
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !hexBuffer.isEmpty()) {
                hexBuffer = hexBuffer.substring(0, hexBuffer.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                focusedHexColor.setFromHex(hexBuffer);
                focusedHexColor = null;
                hexBuffer = "";
                return true;
            }
            return true;
        }
        if (focusedString != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                focusedString = null;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                String cur = focusedString.getValue();
                if (!cur.isEmpty()) focusedString.setValue(cur.substring(0, cur.length() - 1));
                return true;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close(anim);
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr) {
        if (activeModule == null || Character.isISOControl(chr)) return false;
        if (focusedHexColor != null) {
            if (hexBuffer.length() < 7 && (chr == '#' || Character.digit(chr, 16) >= 0)) {
                hexBuffer += Character.toUpperCase(chr);
                if (hexBuffer.length() == 7 || (hexBuffer.length() == 6 && !hexBuffer.startsWith("#"))) {
                    focusedHexColor.setFromHex(hexBuffer);
                }
            }
            return true;
        }
        if (focusedString != null) {
            if (focusedString.getValue().length() < focusedString.getMaxLength()) {
                focusedString.setValue(focusedString.getValue() + chr);
            }
            return true;
        }
        return false;
    }

    private void applyColorDrag(double mouseX) {
        int val = (int) Math.round(Math.max(0.0, Math.min(1.0, (mouseX - dragColorX) / dragColorW)) * 255.0);
        int r = draggingColorChannel == 0 ? val : draggingColor.getRed();
        int g = draggingColorChannel == 1 ? val : draggingColor.getGreen();
        int b = draggingColorChannel == 2 ? val : draggingColor.getBlue();
        draggingColor.setRgb(r, g, b);
    }
}
