package com.purnadlc.gui;

import com.purnadlc.PurnaDLC;
import com.purnadlc.animation.PurnaAnimationManager;
import com.purnadlc.gui.component.CategorySidebar;
import com.purnadlc.gui.component.ModulePanel;
import com.purnadlc.gui.component.ModuleSettingsPanel;
import com.purnadlc.gui.component.PurnaToolbar;
import com.purnadlc.module.impl.misc.ClickGuiModule;
import com.purnadlc.module.impl.visual.HudModule;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class PurnaClickGuiScreen extends Screen {
    private final PurnaDLC purna;
    private final PurnaAnimationManager anim = new PurnaAnimationManager();
    private final CategorySidebar sidebar = new CategorySidebar();
    private final PurnaToolbar toolbar = new PurnaToolbar();
    private final ModulePanel modulePanel = new ModulePanel();
    private final ModuleSettingsPanel settingsPanel = new ModuleSettingsPanel();

    private int winX, winY, winW, winH;

    // Live mouse/touch dragging of HUD Photo frame while ClickGUI is open
    private boolean draggingHudPhoto = false;
    private double photoDragOffX = 0.0;
    private double photoDragOffY = 0.0;

    public PurnaClickGuiScreen(PurnaDLC purna) {
        super(Text.literal("PurnaDLC Click GUI"));
        this.purna = purna;
    }

    @Override
    protected void init() {
        super.init();
        anim.onGuiOpened();
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {}

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        anim.beginFrame();

        if (anim.isCloseFinished()) {
            super.close();
            return;
        }

        PurnaTheme theme = purna.getTheme();
        ClickGuiModule guiMod = purna.getModuleManager().getModule(ClickGuiModule.class);
        boolean useAnim = guiMod == null || guiMod.animations.isEnabled();
        boolean forceCompact = guiMod != null && guiMod.mobileCompact.isEnabled();
        boolean useVideoBg = guiMod == null || guiMod.videoBackground.isEnabled();
        float videoOpacity = guiMod != null ? guiMod.videoOpacity.getFloat() : 0.85f;

        float alpha = useAnim ? anim.getGuiAlpha() : 1f;
        float scale = useAnim ? anim.getGuiScale() : 1f;

        int overlayAlpha = Math.round(255f * theme.getOverlayOpacity() * alpha);
        context.fill(0, 0, this.width, this.height, PurnaTheme.overrideAlpha(0x000000, overlayAlpha));

        // Render draggable HUD Photo widget live so user can move it with mouse while ClickGUI is open
        HudModule hud = purna.getModuleManager().getModule(HudModule.class);
        if (hud != null && hud.isEnabled() && hud.photos.isEnabled()) {
            purna.getHudRenderer().renderPhotoWidget(context, hud, true, mouseX, mouseY);
        }

        int margin = MobilePlatform.isMobileMode() ? 12 : 28;
        int availW = Math.max(220, this.width - margin);
        int availH = Math.max(190, this.height - margin);
        int targetW = Math.min(PurnaTheme.BASE_WINDOW_WIDTH, availW);
        int targetH = Math.min(PurnaTheme.BASE_WINDOW_HEIGHT, availH);

        winW = Math.max(200, Math.round(targetW * scale));
        winH = Math.max(180, Math.round(targetH * scale));
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        // Window shadow + dark base + looping purple samurai video covering all dark ClickGUI areas
        PurnaGuiRenderer.drawDropShadow(context, winX, winY, winW, winH, PurnaTheme.WINDOW_RADIUS, alpha);
        PurnaGuiRenderer.drawRoundedRect(context, winX, winY, winW, winH, PurnaTheme.WINDOW_RADIUS,
            PurnaTheme.withAlpha(theme.getMainBackground(), alpha));
        if (useVideoBg) {
            ClickGuiVideoBackground.render(context, winX + 1, winY + 1, winW - 2, winH - 2, alpha, videoOpacity);
        } else {
            PurnaGuiRenderer.drawRoundedRect(context, winX, winY, winW, winH, PurnaTheme.WINDOW_RADIUS,
                PurnaTheme.withAlpha(theme.getSecondaryBackground(), alpha));
        }
        PurnaGuiRenderer.drawRoundedBorder(context, winX, winY, winW, winH, PurnaTheme.WINDOW_RADIUS,
            PurnaTheme.withAlpha(theme.getBorderColor(), alpha));

        int sidebarW = Math.min(PurnaTheme.SIDEBAR_WIDTH, Math.max(78, winW / 4));
        int toolbarH = PurnaTheme.TOOLBAR_HEIGHT;
        int contentX = winX + sidebarW;
        int contentW = Math.max(100, winW - sidebarW);
        int contentY = winY + toolbarH;
        int contentH = Math.max(80, winH - toolbarH);

        boolean allowMainHover = !settingsPanel.isOpen() && !toolbar.isProfileMenuOpen() && !draggingHudPhoto;

        sidebar.render(context, this.textRenderer, winX, winY, sidebarW, winH,
            allowMainHover ? mouseX : -1, allowMainHover ? mouseY : -1, alpha, theme, anim);

        toolbar.render(context, this.textRenderer, contentX, winY, contentW, toolbarH,
            !settingsPanel.isOpen() ? mouseX : -1, !settingsPanel.isOpen() ? mouseY : -1,
            alpha, theme, purna.getProfileManager());

        modulePanel.render(context, this.textRenderer, contentX, contentY, contentW, contentH,
            allowMainHover ? mouseX : -1, allowMainHover ? mouseY : -1, allowMainHover, alpha,
            sidebar.getSelectedCategory(), toolbar.getSearchQuery(), forceCompact,
            purna.getModuleManager(), theme, anim);

        toolbar.renderDropdownOverlay(context, this.textRenderer, mouseX, mouseY, alpha, theme, purna.getProfileManager());

        if (settingsPanel.isOpen() || anim.isSettingsVisible()) {
            settingsPanel.render(context, this.textRenderer, winX, winY, winW, winH,
                mouseX, mouseY, alpha, theme, anim);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        if (settingsPanel.isOpen()) {
            return settingsPanel.mouseClicked(mouseX, mouseY, button, anim);
        }

        // Allow dragging the HUD Photo frame directly when clicking on it outside the ClickGUI window
        boolean insideWindow = PurnaGuiRenderer.isHovered(mouseX, mouseY, winX, winY, winW, winH);
        if (button == 0 && !insideWindow) {
            HudModule hud = purna.getModuleManager().getModule(HudModule.class);
            if (hud != null && hud.isEnabled() && hud.photos.isEnabled()) {
                int px = hud.photoX.getInt(), py = hud.photoY.getInt();
                int pw = hud.photoWidth.getInt(), ph = hud.photoHeight.getInt();
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, px - 4, py - 4, pw + 8, ph + 8)) {
                    draggingHudPhoto = true;
                    photoDragOffX = mouseX - px;
                    photoDragOffY = mouseY - py;
                    return true;
                }
            }
        }

        if (toolbar.mouseClicked(mouseX, mouseY, button, purna.getProfileManager(),
            this::beginClose,
            () -> purna.openPhotoGallery(MinecraftClient.getInstance(), this))) {
            return true;
        }

        if (sidebar.mouseClicked(mouseX, mouseY, button, newCat -> {
            toolbar.clearSearch();
            toolbar.closePopups();
            modulePanel.onCategoryChanged();
            anim.triggerCategoryTransition();
        })) {
            return true;
        }

        if (modulePanel.mouseClicked(mouseX, mouseY, button, sidebar.getSelectedCategory(), purna.getTheme(),
            mod -> settingsPanel.open(mod, anim),
            this::jumpToModule)) {
            return true;
        }

        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        if (draggingHudPhoto) {
            HudModule hud = purna.getModuleManager().getModule(HudModule.class);
            if (hud != null) {
                int pw = hud.photoWidth.getInt(), ph = hud.photoHeight.getInt();
                int nx = (int) Math.max(0, Math.min(this.width - pw, Math.round(mouseX - photoDragOffX)));
                int ny = (int) Math.max(0, Math.min(this.height - ph, Math.round(mouseY - photoDragOffY)));
                hud.photoX.setValue((double) nx);
                hud.photoY.setValue((double) ny);
            }
            return true;
        }

        if (settingsPanel.isOpen()) {
            return settingsPanel.mouseDragged(mouseX, mouseY, button);
        }
        if (modulePanel.mouseDragged(mouseX, mouseY, purna.getTheme())) {
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (draggingHudPhoto) {
            draggingHudPhoto = false;
            purna.getProfileManager().saveCurrentProfile();
        }
        settingsPanel.mouseReleased();
        modulePanel.mouseReleased(
            mod -> settingsPanel.open(mod, anim),
            this::jumpToModule
        );
        return super.mouseReleased(click);
    }

    private void jumpToModule(com.purnadlc.module.Module mod) {
        sidebar.setSelectedCategory(mod.getCategory());
        toolbar.clearSearch();
        modulePanel.onCategoryChanged();
        settingsPanel.open(mod, anim);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (settingsPanel.isOpen()) return settingsPanel.mouseScrolled(mouseX, mouseY, verticalAmount);
        if (modulePanel.mouseScrolled(mouseX, mouseY, verticalAmount)) return true;
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int keyCode = input.key();
        if (settingsPanel.isOpen() && settingsPanel.keyPressed(keyCode, anim)) return true;
        if (toolbar.keyPressed(keyCode, purna.getProfileManager())) return true;
        if (modulePanel.keyPressed(keyCode)) return true;
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { beginClose(); return true; }

        ClickGuiModule guiMod = purna.getModuleManager().getModule(ClickGuiModule.class);
        if (guiMod != null && guiMod.openKey.isBound() && keyCode == guiMod.openKey.getKeyCode()
            && !toolbar.hasTextFocus() && !modulePanel.hasTextFocus() && !settingsPanel.hasKeyboardCapture()) {
            beginClose();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        char chr = (char) input.codepoint();
        if (settingsPanel.isOpen() && settingsPanel.charTyped(chr)) return true;
        if (toolbar.charTyped(chr)) return true;
        if (modulePanel.charTyped(chr)) return true;
        return super.charTyped(input);
    }

    private void beginClose() {
        purna.getProfileManager().saveCurrentProfile();
        ClickGuiModule guiMod = purna.getModuleManager().getModule(ClickGuiModule.class);
        if (guiMod == null || guiMod.animations.isEnabled()) {
            anim.requestGuiClose();
        } else {
            super.close();
        }
    }

    @Override
    public void close() { beginClose(); }
}
