package com.purnadlc.mixin;

import com.purnadlc.PurnaDLC;
import com.purnadlc.module.impl.visual.NoRenderModule;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void purnadlc$cancelFireOverlay(CallbackInfo ci) {
        PurnaDLC client = PurnaDLC.getInstance();
        if (client == null) return;
        NoRenderModule nr = client.getModuleManager().getModule(NoRenderModule.class);
        if (nr != null && nr.isEnabled() && nr.elements.isSelected("Fire")) {
            ci.cancel();
        }
    }
}
