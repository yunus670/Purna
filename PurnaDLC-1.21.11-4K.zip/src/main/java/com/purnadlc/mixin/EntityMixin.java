package com.purnadlc.mixin;

import com.purnadlc.PurnaDLC;
import com.purnadlc.combat.aura.AttackAura;
import com.purnadlc.combat.aura.AttackAuraSettings;
import com.purnadlc.combat.aura.movefix.MoveFixController;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Redirect(
        method = "updateVelocity",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getYaw()F"),
        require = 0
    )
    private float purnadlc$redirectStrafeYaw(Entity instance) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && instance == mc.player) {
            PurnaDLC client = PurnaDLC.getInstance();
            if (client != null) {
                AttackAura aura = client.getModuleManager().getModule(AttackAura.class);
                if (aura != null && aura.isEnabled()) {
                    AttackAuraSettings settings = aura.getSettingsBundle();
                    MoveFixController moveFix = aura.getMoveFixController();
                    if (moveFix.shouldFixStrafe(settings)) {
                        return moveFix.getMovementYaw(instance.getYaw(), settings);
                    }
                }
            }
        }
        return instance.getYaw();
    }
}
