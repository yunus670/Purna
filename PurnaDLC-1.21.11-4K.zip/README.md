# PurnaDLC — Minecraft 1.21.11 Fabric Client (4K Visuals + Video BG + HUD Photos + Mobile Edition)

Premium 4K HiDPI Click GUI & Visuals client for Minecraft Java Edition 1.21.11 (Fabric), optimized for both **Zalith Launcher / PojavLauncher** and Desktop Java 21.

## Highlights (v5)
- **Looping ClickGUI Video Background**: 24 seamless crossfaded frames (`assets/purnadlc/textures/gui/bg/frame_00.png`..`frame_23.png`) covering all dark surfaces of the ClickGUI window with translucent glass cards.
- **4K HiDPI Branding & HUD**: Oversampled 512x512 geometric PurnaDLC logo (`logo_4k.png`) with crisp drop-shadowed watermark, coordinates/BPS pill, and active module ArrayList.
- **HUD Photos (Gallery Picker + Mouse/Touch Drag)**: Enable `Visuals -> Hud -> Photos`, click **`Photos`** in the ClickGUI toolbar (or `/purna photo` / Pause Menu -> `HUD Photos`) to pick any PNG/JPG image directly from your Android gallery (`Camera`, `Screenshots`, `Download`, `WhatsApp`) or desktop folders, and drag the photo frame anywhere on screen.
- **All Visuals Wired & Functional**: `ShaderSky`, `Ambience`, `ChinaHat`, `Wings`, `Rools`, `Custom Models`, `Particles`, `BlockOverlay`, `HitPoint`, `Prediction`, `Item Renderer`, `Box`, `Chams`, `TargetESP`, `Tags`, `Arrows`, `ShaderHands`, `AspectRatio`, `ViewModel`, `SwingAnimation`, `NoRender`, and `ShulkerPreview`.

## Building `.jar` via GitHub Actions (Zero PC Required)
Extract this `.zip` and push its contents to the root of a GitHub repository. `.github/workflows/build.yml` compiles with Java 21 + Gradle and uploads the ready-to-use Fabric `.jar` under **Actions -> Artifacts**.
